# Initial code audit

This audit describes the four original scripts supplied for repository preparation. The scripts have been preserved unchanged.

## GSE201588_discovery_visualisation.R
- Lines: 5936
- Packages referenced via `library()`: EnhancedVolcano, FactoMineR, RColorBrewer, clusterProfiler, corrplot, dendextend, dplyr, factoextra, ggplot2, ggrepel, gprofiler2, limma, multiMiR, patchwork, pheatmap, tidyr, tidyverse, viridisLite
- File inputs detected: No literal file input detected
- Hard-coded Windows path text present: Yes
- Saves `.RData` workspace or R history: Yes

## GSE149856_validation_visualisation.R
- Lines: 2096
- Packages referenced via `library()`: RColorBrewer, VennDiagram, dplyr, futile.logger, ggplot2, ggrepel, grid, patchwork, pheatmap, readxl, stringr, tidyr
- File inputs detected: GSE149856_processedfile_edgeR_Saenz-de-Juano.xlsx
- Hard-coded Windows path text present: Yes
- Saves `.RData` workspace or R history: Yes

## GSE227559_healthy_conservation.R
- Lines: 2838
- Packages referenced via `library()`: GEOquery, VennDiagram, corrplot, dplyr, futile.logger, ggplot2, ggrepel, grid, igraph, openxlsx, patchwork, pheatmap, readxl, tidyr, tidytext
- File inputs detected: GSE227559_Processed_data.xlsx
- Hard-coded Windows path text present: Yes
- Saves `.RData` workspace or R history: Yes

## GSE254484_milk_powder_profile.R
- Lines: 1337
- Packages referenced via `library()`: corrplot, dplyr, ggplot2, ggrepel, gridExtra, pheatmap, readxl, tibble, tidyr
- File inputs detected: GSE254484_dataset.xlsx
- Hard-coded Windows path text present: Yes
- Saves `.RData` workspace or R history: Yes

## Reproducibility items to address

- Replace machine-specific paths with project-relative paths (for example, using `here::here()`).
- Make every required input file explicit and document where it is obtained.
- Ensure each script creates the objects it uses rather than relying on an interactive RStudio workspace.
- Avoid `install.packages()` inside analysis scripts; document package dependencies separately.
- Record R and package versions (for example, with `renv`).
- Remove or justify workspace/history saves such as `save.image()` and `savehistory()` before public release.
- Check that each analysis and figure-generation section corresponds to the final manuscript methods and figures.

This is an initial packaging audit, not a validation that the scripts execute successfully from a clean R session.