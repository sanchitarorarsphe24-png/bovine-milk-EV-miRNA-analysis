# script to visualisze gene expression data (GSE201588)
# script "D:/SANCHIT ARORA/IIT BHU/Sanchit_PhD/Sanchit_PhD research work/In silico studies/Scripts"

# load libraries
library(tidyverse)
library(ggplot2)
library(pheatmap)
library(dplyr)
library(viridisLite)
library(RColorBrewer)

colnames(data.merged)

# expression distribution analysis
# goal: check tTPM distribution and normalization quality

library(ggplot2)

ggplot(data.merged,
       aes(x = log2(TPM + 1),
           fill = group.y)) +
  geom_histogram(bins = 50,
                 alpha = 0.6) +
  facet_wrap(~group.y) +
  theme_minimal() +
  labs(title = "Distribution of miRNA TPM")

#boxplot for global miRNA expression
# compare overall miRNA abundance among groups

ggplot(data.merged,
       aes(x = group.y,
           y = log2(TPM + 1),
           fill = group.y)) +
  geom_boxplot() +
  theme_classic() +
  labs(title = "Global miRNA Expression")


#PCA analysis
# see whether mastitis conditions alter EV-miRNA cargo.

# step 1 create expression matrix
library(dplyr)
library(tidyr)

expr <- data.merged %>%
  select(miRNA, samples, TPM) %>%
  distinct() %>%
  pivot_wider(
    names_from = samples,
    values_from = TPM
  )

#step 2 prepare matrix
expr_mat <- as.data.frame(expr)

rownames(expr_mat) <- expr_mat$miRNA

expr_mat$miRNA <- NULL

expr_mat <- as.matrix(expr_mat)

expr_mat <- log2(expr_mat + 1)

#step 3 check sample names
colnames(expr_mat)

#step 4 create correct group annotation
sample_group <- data.merged %>%
  select(samples, group.y) %>%
  distinct()

sample_group

#step 5 match order perfectly
sample_group <- sample_group[
  match(colnames(expr_mat),
        sample_group$samples),
]

sample_group

colnames(expr_mat)

#step 6 run PCA
library(FactoMineR)
library(factoextra)

pca <- PCA(
  t(expr_mat),
  graph = FALSE
)

#step 7 PCA plot
fviz_pca_ind(
  pca,
  habillage = sample_group$group.y,
  addEllipses = TRUE,
  repel = TRUE
)

# complete working PCA pipeline
#step 1 create clean dataset

unique(data.clean$samples)
table(data.clean$samples)
data.clean <- data.clean %>%
  filter(!is.na(samples))

data.clean <- data.clean %>%
  filter(
    !samples %in% c("H", "M", "SM"),
    !is.na(samples),
    !is.na(group)
  )
length(unique(data.clean$samples))

rownames(expr_t)
sample_group$samples

expr_mat <- expr_mat[, !colnames(expr_mat) %in% "group"]
library(dplyr)

data.clean <- data.merged %>%
  select(
    miRNA,
    samples,
    TPM,
    group = group.y
  )

filter(!is.na(group))

# step 2 remove duplicate entries
data.clean <- data.clean %>%
  distinct(miRNA, samples, .keep_all = TRUE)

#step 3 convert log to wide matrix
library(tidyr)

expr <- data.clean %>%
  pivot_wider(
    names_from = samples,
    values_from = TPM
  )

#step 4 create matrix
expr_mat <- as.data.frame(expr)

rownames(expr_mat) <- expr_mat$miRNA

expr_mat$miRNA <- NULL

# REMOVE accidental group column
expr_mat <- expr_mat[, !colnames(expr_mat) %in% "group"]

#step 5 convert to numeric
expr_mat <- data.frame(
  lapply(expr_mat, as.numeric),
  row.names = rownames(expr_mat)
)

#step 6 replace NA values
expr_mat[is.na(expr_mat)] <- 0

#step 7 log transform log2(TPM+1)
expr_mat <- log2(expr_mat + 1)

#step 8 check dimensions
dim(expr_mat)

#step 9 transpose matrix
expr_t <- t(expr_mat)

rownames(expr_t)
dim(expr_t)
#step 10 remove zero varince miRNAs
expr_t <- expr_t[, apply(expr_t, 2, var) != 0]

#step 11 run PCA
pca <- prcomp(
  expr_t,
  scale. = TRUE
)

#step 12 create group annotation
sample_group <- data.clean %>%
  distinct(samples, group)

sample_group <- sample_group[
  match(rownames(expr_t),
        sample_group$samples),
]

#step 13 PCA plot
library(factoextra)

fviz_pca_ind(
  pca,
  geom.ind = "point",
  col.ind = sample_group$group,
  addEllipses = TRUE,
  repel = TRUE,
  pointsize = 4
)

# heatmap of miRNA expression
#idnetify expression signatures


library(pheatmap)

top_var <- apply(expr_mat, 1, var)

top_miRNAs <- names(sort(top_var,
                         decreasing = TRUE))[1:30]

pheatmap(expr_mat[top_miRNAs, ],
         scale = "row",
         clustering_distance_rows = "euclidean",
         clustering_distance_cols = "euclidean")

# correct expr/mat
library(dplyr)
library(tidyr)

# Clean dataset
data.clean <- data.merged %>%
  select(
    miRNA,
    samples,
    TPM
  ) %>%
  
  # remove NA samples
  filter(!is.na(samples)) %>%
  
  # remove summary samples
  filter(!samples %in% c("H", "M", "SM"))

length(unique(data.clean$miRNA))

expr <- data.clean %>%
  pivot_wider(
    names_from = samples,
    values_from = TPM
  )

expr_mat <- as.data.frame(expr)

rownames(expr_mat) <- expr_mat$miRNA

expr_mat$miRNA <- NULL

expr_mat[] <- lapply(expr_mat, as.numeric)

expr_mat[is.na(expr_mat)] <- 0

expr_mat <- log2(expr_mat + 1)

dim(expr_mat)

# correlation heatmap
# undestand sample relationships

library(corrplot)

cor_matrix <- cor(expr_mat)

corrplot(cor_matrix,
         method = "color")

# volcano plot
# identify significantly altered miRNAs

colnames(design)
makeContrasts()

library(limma)
library(EnhancedVolcano)

# Create group vector
group <- factor(c(
  rep("Healthy", 7),
  rep("Clinical", 7),
  rep("Subclinical", 7)
))

# Create design matrix
design <- model.matrix(~0 + group)

# Check column names
colnames(design)

# Run limma
fit <- lmFit(as.matrix(expr_mat), design)

# Correct contrast matrix
contrast.matrix <- makeContrasts(
  groupClinical - groupHealthy,
  levels = design
)

# Apply contrasts
fit2 <- contrasts.fit(fit, contrast.matrix)

# Empirical Bayes moderation
fit2 <- eBayes(fit2)

# Get differential expression results
results <- topTable(
  fit2,
  number = Inf
)

# View top results
head(results)

# Volcano plot
EnhancedVolcano(
  results,
  lab = rownames(results),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Clinical vs Healthy EV miRNAs",
  subtitle = "Differentially expressed bovine milk EV miRNAs"
)

# sublcincal vs healthy

contrast.matrix <- makeContrasts(
  groupSubclinical - groupHealthy,
  levels = design
)

fit2 <- contrasts.fit(fit, contrast.matrix)

fit2 <- eBayes(fit2)

results_sub_vs_healthy <- topTable(
  fit2,
  number = Inf
)

EnhancedVolcano(
  results_sub_vs_healthy,
  lab = rownames(results_sub_vs_healthy),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Subclinical vs Healthy EV miRNAs"
)

# clinical vs subclinical

contrast.matrix <- makeContrasts(
  groupClinical - groupSubclinical,
  levels = design
)

fit2 <- contrasts.fit(fit, contrast.matrix)

fit2 <- eBayes(fit2)

results_clinical_vs_sub <- topTable(
  fit2,
  number = Inf
)

EnhancedVolcano(
  results_clinical_vs_sub,
  lab = rownames(results_clinical_vs_sub),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Clinical vs Subclinical EV miRNAs"
)

# cluster analysis
# see whether disease groups cluster separately

dist_mat <- dist(t(expr_mat))

hc <- hclust(dist_mat)

plot(hc)

#known vs novel miRNA visulaization
# novel miRNA discovery 

# 1. unique known vs novel miRNAs
#known vs novel miRNA visulaization
# novel miRNA discovery 

library(dplyr)
library(ggplot2)

unique_miRNAs <- data.merged %>%
  distinct(miRNA)

# Correct classification
unique_miRNAs$miRNA_type <- ifelse(
  grepl("^bta|^hsa|^mmu|^ssc",
        unique_miRNAs$miRNA),
  "Known",
  "Novel"
)

# Plot
ggplot(unique_miRNAs,
       aes(x = miRNA_type,
           fill = miRNA_type)) +
  geom_bar() +
  theme_minimal() +
  labs(
    title = "Known vs Novel miRNAs",
    y = "Unique miRNA Count"
  )
# number of unique miRNAs per group

library(dplyr)
library(ggplot2)

group_miRNAs <- data.merged %>%
  distinct(group.y, miRNA)


group_miRNAs$miRNA_type <- ifelse(
  grepl("^bta|^hsa|^mmu|^ssc",
        group_miRNAs$miRNA),
  "Known",
  "Novel"
)


ggplot(group_miRNAs,
       aes(x = group.y,
           fill = miRNA_type)) +
  
  geom_bar(position = "dodge") +
  
  theme_minimal() +
  
  labs(
    title = "Known vs Novel miRNAs Across Groups",
    x = "Group",
    y = "Unique miRNA Count"
  )


#mean expression of known vs novel miRNAs
library(ggplot2)

data.merged$miRNA_type <- ifelse(
  grepl("^bta|^hsa|^mmu|^ssc",
        data.merged$miRNA),
  "Known",
  "Novel"
)

ggplot(data.merged,
       aes(x = miRNA_type,
           y = log2(TPM + 1),
           fill = group.y)) +
  
  geom_boxplot() +
  
  theme_minimal() +
  
  labs(
    title = "Expression of Known vs Novel EV miRNAs",
    x = "miRNA Type",
    y = "log2(TPM + 1)"
  )

# alternative to get better graph
# violin + boxplot

library(ggplot2)

data.merged$miRNA_type <- ifelse(
  grepl("^bta|^hsa|^mmu|^ssc",
        data.merged$miRNA),
  "Known",
  "Novel"
)

ggplot(data.merged,
       aes(x = miRNA_type,
           y = log2(TPM + 1),
           fill = group.y)) +
  
  geom_violin(trim = FALSE,
              alpha = 0.5,
              position = position_dodge(0.9)) +
  
  geom_boxplot(width = 0.15,
               position = position_dodge(0.9),
               outlier.shape = NA) +
  
  theme_minimal() +
  
  labs(
    title = "Expression Distribution of Known vs Novel miRNAs",
    x = "miRNA Type",
    y = "log2(TPM + 1)"
  )

# plot top novel miRNAs only

novel_data <- data.merged %>%
  filter(!grepl("^bta|^hsa|^mmu|^ssc",
                miRNA))

top_novel <- novel_data %>%
  group_by(miRNA) %>%
  summarise(meanTPM = mean(TPM)) %>%
  arrange(desc(meanTPM)) %>%
  slice(1:10)

ggplot(
  novel_data %>%
    filter(miRNA %in% top_novel$miRNA),
  
  aes(x = miRNA,
      y = log2(TPM + 1),
      fill = group.y)
) +
  
  geom_boxplot() +
  
  theme_minimal() +
  
  theme(axis.text.x = element_text(angle = 45,
                                   hjust = 1)) +
  
  labs(
    title = "Top Novel EV miRNAs Across Groups",
    y = "log2(TPM + 1)"
  )

# top expressed miRNAs
#identify dominnat EV miRNAs

library(dplyr)

top_expr <- data.merged %>%
  group_by(miRNA) %>%
  summarise(meanTPM = mean(TPM)) %>%
  arrange(desc(meanTPM)) %>%
  head(20)

ggplot(top_expr,
       aes(x = reorder(miRNA, meanTPM),
           y = meanTPM)) +
  geom_bar(stat = "identity") +
  coord_flip()

# therapeutic miRNA candidate discovery for HR+BC

# a. differentially expressed miRNAs

colnames(results)


sig_miRNAs <- results[
  results$adj.P.Val < 0.05 &
    abs(results$logFC) > 1,
]


#b higly expressed miRNAs

top_exp <- data.merged %>%
  group_by(miRNA) %>%
  summarise(meanTPM = mean(TPM)) %>%
  arrange(desc(meanTPM))

#c literature relevant miRNAs
# acrquired and written in my lab notebook dated 28.05.26

#d Novel miRNAs
# can get from top-exp table/excel
# helpful if they are higly expressed, significantly altered, specific to mastitis/healthy EVs

#e target gene analysis

# final analysis of therapeutic miRNA candidate discorvery fr HR+BC on the basis of above a-e step analysis

BiocManager::install("multiMiR")


library(multiMiR)

targets <- get_multimir(
  mirna = "mmu-miR-7116-5p",
  table = "validated"
)

head(targets@data)

#HRBC genes

HRBC_genes <- c(
  "ESR1","PGR","FOXA1","GATA3",
  "PIK3CA","AKT1","MTOR","PTEN",
  "CCND1","CDK4","CDK6","RB1",
  "ERBB2","EGFR","IGF1R","FGFR1",
  "BCL2","TP53","MYC",
  "STAT3","NFKB1","IL6",
  "ZEB1","TWIST1","SNAI1"
)

miRNA_list <- unique(data.merged$miRNA)

miRNA_list_hsa <- gsub("^bta-", "hsa-", miRNA_list)

library(multiMiR)

valid_miRNAs <- list()

for(m in miRNA_list_hsa){
  
  cat("Checking:", m, "\n")
  
  res <- tryCatch(
    get_multimir(
      mirna = m,
      table = "validated"
    ),
    error = function(e) NULL
  )
  
  if(!is.null(res) &&
     nrow(res@data) > 0){
    
    valid_miRNAs[[m]] <- res@data
  }
}

all_targets <- do.call(rbind, valid_miRNAs)

head(all_targets)

write.csv(
  all_targets,
  "Validated_miRNA_targets.csv",
  row.names = FALSE
)
colnames(all_targets)

HRBC_genes <- c(
  "ESR1","ESR2","PGR","GREB1","FOXA1","GATA3",
  "PIK3CA","PIK3R1","AKT2","AKT1","TSC1","TSC2","E2F1","MTOR","PTEN",
  "CCND1","CDK4","CDK6","RB1",
  "ERBB2","EGFR","IGF1R","FGFR2","VEGFA","FGFR1",
  "BCL2","BAX","CASP3","CASP8","MDM2","SNAI2","ZEB2","VIM","CDH1","TP53","MYC",
  "STAT3","NFKB1","LIN28A", "LIN28B","SOX2", "NANOG","OCT4","TNF","RELA","IL6",
  "CXCL8", "ZEB1","TWIST1","SNAI1"
)

HRBC_genes

cat(HRBC_genes, sep = "\n")

bc_targets <- all_targets[
  all_targets$target_symbol %in% HRBC_genes,
]

unique(bc_targets$mature_mirna_id)

bc_targets[, c("mature_mirna_id",
               "target_symbol")]
table(bc_targets$mature_mirna_id)

write.csv(
  bc_targets,
  "HRBC_miRNA_Targets.csv",
  row.names = FALSE
)

final_table <- bc_targets[, c("mature_mirna_id", "target_symbol")]

write.csv(
  final_table,
  "Final_HRBC_miRNA_Targets.csv",
  row.names = FALSE
)

write.csv(
  bc_targets,
  "all_targets.csv",
  row.names = FALSE
)

library(dplyr)

bc_targets_unique <- bc_targets %>%
  distinct(
    mature_mirna_id,
    target_symbol,
    .keep_all = TRUE
  )

subset(
  bc_targets_unique,
  mature_mirna_id == "hsa-miR-21-5p"
)

target_counts <- bc_targets_unique %>%
  group_by(mature_mirna_id) %>%
  summarise(
    Unique_Targets = n()
  ) %>%
  arrange(desc(Unique_Targets))

target_counts

miRNA_targets <- bc_targets_unique %>%
  group_by(mature_mirna_id) %>%
  summarise(
    Targets = paste(
      sort(unique(target_symbol)),
      collapse = ", "
    )
  )

write.csv(
  miRNA_targets,
  "HRBC_miRNA_Unique_Targets.csv",
  row.names = FALSE
)

#ranked list of therapeutic miRNA candidates for HR+ breast cancer
#step 1 Calculate Mean TPM of Each miRNA

library(dplyr)

mean_TPM <- data.merged %>%
  group_by(miRNA) %>%
  summarise(
    Mean_TPM = mean(TPM, na.rm = TRUE)
  )

#Step 2 Count Unique HR+BC Targets per miRNA
target_counts <- bc_targets_unique %>%
  group_by(mature_mirna_id) %>%
  summarise(
    HRBC_Targets = n_distinct(target_symbol)
  )

#Step 3 Match Human miRNA Names to Your Bovine miRNAs

rownames(sig_miRNAs)[1:10]
dim(expr_mat)

head(rownames(expr_mat))

head(colnames(expr_mat))

library(limma)
fit <- lmFit(expr_mat, design)

dim(expr_mat)

dim(expr_t)

expr_mat <- data.frame(
  lapply(expr_mat, as.numeric)
)
head(rownames(expr_mat))

head(data.clean)

library(dplyr)
library(tidyr)

expr <- data.clean %>%
  select(miRNA, samples, TPM) %>%
  pivot_wider(
    names_from = samples,
    values_from = TPM
  )
head(expr)

expr_mat <- as.data.frame(expr)

rownames(expr_mat) <- expr_mat$miRNA

expr_mat$miRNA <- NULL

head(rownames(expr_mat))

expr_mat[] <- lapply(expr_mat, as.numeric)

library(limma)

fit <- lmFit(as.matrix(expr_mat), design)

contrast.matrix <- makeContrasts(
  groupClinical - groupHealthy,
  levels = design
)

fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)

results <- topTable(
  fit2,
  number = Inf
)

head(rownames(results))

sig_miRNAs <- results[
  results$adj.P.Val < 0.05 &
    abs(results$logFC) > 1,
]

sig_miRNAs$miRNA <- rownames(sig_miRNAs)

n_distinct(data.clean$miRNA)

dim(sig_miRNAs)
head(results)

summary(results$adj.P.Val)

summary(results$logFC)

sum(results$adj.P.Val < 0.05)

sum(abs(results$logFC) > 1)

results_sorted <- results[
  order(abs(results$logFC),
        decreasing = TRUE),
]

head(results_sorted, 20)
ls()
results
dim(results)

results_sorted <- results[
  order(abs(results$logFC),
        decreasing = TRUE),
]

head(results_sorted, 20)

nrow(results)

sum(results$adj.P.Val < 0.05)

summary(results$adj.P.Val)

head(results)

sig_miRNAs$human_miRNA <- gsub(
  "^bta-",
  "hsa-",
  sig_miRNAs$miRNA
)

dim(sig_miRNAs)

nrow(sig_miRNAs)

head(sig_miRNAs)

results_sorted <- results[
  order(abs(results$logFC),
        decreasing = TRUE),
]


head(results_sorted, 20)

results_sorted$miRNA <- rownames(expr_mat)[
  match(
    rownames(results_sorted),
    rownames(expr_mat)
  )
]

head(rownames(expr_mat))
head(rownames(results_sorted))

results_sorted$human_miRNA <- gsub(
  "^bta-",
  "hsa-",
  results_sorted$miRNA
)

# step 4 calculate mean TPM
library(dplyr)

mean_TPM <- data.merged %>%
  group_by(miRNA) %>%
  summarise(
    Mean_TPM = mean(TPM, na.rm = TRUE)
  )

#Step 5 Count Unique HR+BC Targets
target_counts <- bc_targets_unique %>%
  group_by(mature_mirna_id) %>%
  summarise(
    HRBC_Targets = n_distinct(target_symbol)
  )

# step 6 combine everyting
candidate_table <- results_sorted %>%
  
  left_join(
    mean_TPM,
    by = "miRNA"
  ) %>%
  
  left_join(
    target_counts,
    by = c(
      "human_miRNA" =
        "mature_mirna_id"
    )
  )


#Step7 Replace Missing Target Counts
candidate_table$HRBC_Targets[
  is.na(candidate_table$HRBC_Targets)
] <- 0

#Step8 Create Candidate Score
candidate_table$Score <-
  
  abs(candidate_table$logFC) *
  
  log10(
    candidate_table$Mean_TPM + 1
  ) *
  
  (
    candidate_table$HRBC_Targets + 1
  )

#Step 9 Rank Candidates

candidate_table <- candidate_table[
  order(
    candidate_table$Score,
    decreasing = TRUE
  ),
]

#Step 10 View Top 20 Therapeutic Candidates

head(
  candidate_table[
    ,
    c(
      "miRNA",
      "logFC",
      "Mean_TPM",
      "HRBC_Targets",
      "Score"
    )
  ],
  20
)

#Step 11 Extract Top 10
top10_miRNAs <- head(
  candidate_table,
  10
)

top10_miRNAs


#Step 12 Save CSV
write.csv(
  candidate_table,
  "Ranked_HRBC_miRNA_Candidates.csv",
  row.names = FALSE
)

#Step 13 Plot Top Candidates
library(ggplot2)

ggplot(
  top10_miRNAs,
  aes(
    x = reorder(
      miRNA,
      Score
    ),
    y = Score
  )
) +
  
  geom_col() +
  
  coord_flip() +
  
  theme_minimal() +
  
  labs(
    title =
      "Top HR+BC Candidate EV miRNAs",
    x = "miRNA",
    y = "Candidate Score"
  )

#Step 14 Extract Target Genes for Top Candidates
top_targets <- unique(
  bc_targets_unique$target_symbol[
    
    bc_targets_unique$mature_mirna_id %in%
      
      top10_miRNAs$human_miRNA
  ]
)

length(top_targets)

head(top_targets)

write.csv(
  data.frame(
    Gene = top_targets
  ),
  "Top10_HRBC_Target_Genes.csv",
  row.names = FALSE
)


# pathway enrichment of top known miRNAs
# step 1. select top known miRNAs on the basis of HRBC targets
top_known_miRNAs <- c(
  "hsa-miR-21-5p",
  "hsa-miR-21-5p", 
  "hsa-miR-17-5p",
  "hsa-let-7a-5p",     
  "hsa-miR-30a-5p",    
  "hsa-miR-107",     
  "hsa-miR-203a-3p",   
  "hsa-miR-27a-3p",    
  "hsa-miR-24-3p",     
  "hsa-miR-126-3p",  
  "hsa-miR-22-3p"
)

#step 2. extract unique target genes
library(dplyr)

genes <- bc_targets_unique %>%
  filter(mature_mirna_id %in% top_known_miRNAs) %>%
  pull(target_symbol) %>%
  unique()

length(genes)

head(genes)

#step 3. install required packages

install.packages("BiocManager")

BiocManager::install("clusterProfiler")
install.packages("gprofiler2")

library(clusterProfiler)
library(gprofiler2)

#step 4 Run pathway enrichment

library(gprofiler2)

gost_res <- gost(
  query = genes,
  organism = "hsapiens",
  correction_method = "fdr"
)

head(gost_res$result)

# step 5. save complete results
write.csv(
  gost_res$result,
  "HRBC_Pathway_Enrichment.csv",
  row.names = FALSE
)



sapply(gost_res$result, class)
gost_df <- gost_res$result

gost_df <- gost_df[
  ,
  sapply(gost_df, function(x)
    !is.list(x))
]

write.csv(
  gost_df,
  "HRBC_Pathway_Enrichment.csv",
  row.names = FALSE
)

exists("gost_res")
names(gost_res)
head(gost_res$result)

gost_df <- gost_res$result
dim(gost_df)
gost_df2 <- gost_df[
  ,
  !sapply(gost_df, is.list)
]

write.csv(
  gost_df2,
  "HRBC_Pathway_Enrichment.csv",
  row.names = FALSE
)

exists("gost_res")

head(gost_res$result)

colnames(gost_res$result)

dim(gost_res$result)

# step 6 extract KEGG pathways

kegg_results <- subset(
  gost_df2,
  source == "KEGG"
)

head(kegg_results)

write.csv(
  kegg_results,
  "KEGG_Pathways.csv",
  row.names = FALSE
)

nrow(kegg_results)

# step 7 extract reactome pathways

unique(gost_df2$source)

table(gost_df2$source)


reactome_results <- gost_df2[gost_df2$source == "REAC", ]

dim(reactome_results)

head(reactome_results)

write.csv(
  reactome_results,
  "Reactome_Pathways.csv",
  row.names = FALSE
)

kegg_results <- gost_df2[gost_df2$source == "KEGG", ]

dim(kegg_results)

head(kegg_results)

write.csv(
  kegg_results,
  "KEGG_Pathways.csv",
  row.names = FALSE
)


reactome_results <- subset(
  gost_df2,
  source == "REAC"
)

head(reactome_results)

write.csv(
  reactome_results,
  "Reactome_Pathways.csv",
  row.names = FALSE
)

nrow(reactome_results)

# step 8. extract GO biological processes
go_bp <- subset(
  gost_df2,
  source == "GO:BP"
)

head(go_bp)

write.csv(
  go_bp,
  "GO_Biological_Process.csv",
  row.names = FALSE
)

nrow(go_bp)

#step 9 search specially for HR+BC breast cancer pathways

hrbc_pathways <- gost_df2[
  grepl(
    "PI3K|AKT|mTOR|Estrogen|Breast|Cell cycle|Apoptosis|MAPK|FOXO|JAK|STAT|p53|ERBB2|EGFR",
    gost_df2$term_name,
    ignore.case = TRUE
  ),
]

hrbc_pathways[
  ,
  c(
    "term_name",
    "source",
    "p_value",
    "intersection_size"
  )
]

write.csv(
  hrbc_pathways,
  "HRBC_Related_Pathways.csv",
  row.names = FALSE
)

write.csv(
  hrbc_pathways,
  "HRBC_Related_Pathways.csv",
  row.names = FALSE
)


nrow(hrbc_pathways)

#step 10. top 20 enriched pathways

top20 <- gost_df2[
  order(gost_df2$p_value),
][1:20, ]

top20[, c(
  "term_name",
  "source",
  "p_value",
  "intersection_size"
)]

write.csv(
  top20,
  "Top20_Enriched_Pathways.csv",
  row.names = FALSE
)


# step 11. publication quality dot plot

colnames(top20)

library(ggplot2)

ggplot(
  top20,
  aes(
    x = reorder(term_name, -log10(p_value)),
    y = -log10(p_value)
  )
) +
  geom_point(
    aes(size = intersection_size)
  ) +
  coord_flip() +
  theme_minimal() +
  labs(
    title = "Top Enriched Pathways",
    x = "Pathway",
    y = "-log10(FDR)"
  )

#step 12 Determine which miRNAs target key HR+BC genes

library(dplyr)

key_targets <- bc_targets_unique %>%
  filter(
    target_symbol %in%
      c(
        "ESR1",
        "PGR",
        "PIK3CA",
        "AKT1",
        "MTOR",
        "PTEN",
        "CCND1",
        "BCL2",
        "STAT3",
        "MYC"
      )
  ) %>%
  arrange(target_symbol)

key_targets

write.csv(
  key_targets,
  "Key_HRBC_Targets.csv",
  row.names = FALSE
)

head(top20,20)


# Differentially expressed miRNAs

#Step 1  creation of expression matrix
expr_mat

#step 2 creation of group information
group <- factor(c(
  rep("Healthy",7),
  rep("Subclinical",7),
  rep("Clinical",7)
))

#step 3 load limma
library(limma)

#step 4 design matrix
design <- model.matrix(~0 + group)

colnames(design) <- levels(group)

design

#step 5 fit the model
#If using log2(TPM+1) values
fit <- lmFit(expr_mat, design)

#step 6 create contrasts
contrast.matrix <- makeContrasts(
  
  H_vs_SM = Healthy - Subclinical,
  
  H_vs_M  = Healthy - Clinical,
  
  SM_vs_M = Subclinical - Clinical,
  
  levels = design
)

#step 7 apply contrasts
fit2 <- contrasts.fit(fit, contrast.matrix)

fit2 <- eBayes(fit2)

#step 8 Healthy vs subclinical
results_H_SM <- topTable(
  fit2,
  coef = "H_vs_SM",
  number = Inf,
  adjust.method = "BH"
)

head(results_H_SM)

write.csv(
  results_H_SM,
  "Healthy_vs_Subclinical.csv"
)

#step 9 healty vs clinical
results_H_M <- topTable(
  fit2,
  coef = "H_vs_M",
  number = Inf,
  adjust.method = "BH"
)

write.csv(
  results_H_M,
  "Healthy_vs_Clinical.csv"
)

#step 10 subclinical vs clinical
results_SM_M <- topTable(
  fit2,
  coef = "SM_vs_M",
  number = Inf,
  adjust.method = "BH"
)

write.csv(
  results_SM_M,
  "Subclinical_vs_Clinical.csv"
)

#step 11 significant miRNAs
#strict criteria
sig_H_SM <- subset(
  results_H_SM,
  adj.P.Val < 0.05 &
    abs(logFC) > 1
)

nrow(sig_H_SM)
#if less miRNAs 
sig_H_SM <- subset(
  results_H_SM,
  P.Value < 0.05 &
    abs(logFC) > 1
)

nrow(sig_H_SM)

head(sig_H_SM)

#step 12 check the reported miRNAs by authors
#The original paper reported, bta-miR-21-5p,bta-miR-30a-5p,miR-6-1096

results_H_SM[
  grep("miR-21", rownames(results_H_SM)),
]

results_H_SM[
  grep("miR-30a", rownames(results_H_SM)),
]

results_H_SM[
  grep("miR-6-1096", rownames(results_H_SM)),
]

#step 13 create a known miRNA expresion matrix
head(rownames(expr_mat))

expr_mat_known <- expr_mat[
  grepl("^bta-", rownames(expr_mat)),
]

dim(expr_mat_known)

head(rownames(expr_mat_known))

#step 14 fit the limma using only known miRNAs
fit_known <- lmFit(
  expr_mat_known,
  design
)

fit_known <- contrasts.fit(
  fit_known,
  contrast.matrix
)

fit_known <- eBayes(fit_known)

#step 15 healthy vs subclinical (known miRNAs)
results_H_SM_known <- topTable(
  fit_known,
  coef = "H_vs_SM",
  number = Inf,
  adjust.method = "BH"
)

head(results_H_SM_known)

write.csv(
  results_H_SM_known,
  "Healthy_vs_Subclinical_Known_miRNAs.csv"
)

#step 16 healthy vs clinical (known miRNAs)
results_H_M_known <- topTable(
  fit_known,
  coef = "H_vs_M",
  number = Inf,
  adjust.method = "BH"
)

write.csv(
  results_H_M_known,
  "Healthy_vs_Clinical_Known_miRNAs.csv"
)

#step 17 subclinical vs clinical (known miRNAs)
results_SM_M_known <- topTable(
  fit_known,
  coef = "SM_vs_M",
  number = Inf,
  adjust.method = "BH"
)

write.csv(
  results_SM_M_known,
  "Subclinical_vs_Clinical_Known_miRNAs.csv"
)

#step 18 significant known miRNAs
#strict criteria
sig_H_SM_known <- subset(
  results_H_SM_known,
  adj.P.Val < 0.05 &
    abs(logFC) > 1
)

nrow(sig_H_SM_known)

#if gives zero then this
sig_H_SM_known <- subset(
  results_H_SM_known,
  P.Value < 0.05 &
    abs(logFC) > 1
)

nrow(sig_H_SM_known)

head(sig_H_SM_known)

# removing row numbers from heatmap of miRN expression
head(rownames(expr_mat))

#step 1 regenerate the heatmap
library(pheatmap)

# step 2 Calculate variance of each miRNA
top_var <- apply(expr_mat, 1, var)

# step 3 Select top 20 most variable miRNAs
top_miRNAs <- names(sort(top_var, decreasing = TRUE))[1:20]

# step 4 Generate heatmap
pheatmap(
  expr_mat[top_miRNAs, ],
  scale = "row",
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  show_rownames = TRUE,
  show_colnames = TRUE,
  fontsize_row = 8,
  main = "Top 20 Most Variable miRNAs"
)


# hetmap for Top 20 known miRNAs only
library(pheatmap)

# step 1 Keep only known bovine miRNAs
expr_mat_known <- expr_mat[
  grepl("^bta-", rownames(expr_mat)),
]

# Check dimensions
dim(expr_mat_known)

# Check first few miRNAs
head(rownames(expr_mat_known))

#step 2 calculate variance
top_var <- apply(
  expr_mat_known,
  1,
  var
)

#step 3 Select Top 20 most variable known miRNAs
top_miRNAs <- names(
  sort(
    top_var,
    decreasing = TRUE
  )
)[1:20]

top_miRNAs

# step 4 generate publication-heatmap
pheatmap(
  expr_mat_known[top_miRNAs, ],
  scale = "row",
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  show_rownames = TRUE,
  show_colnames = TRUE,
  fontsize_row = 9,
  fontsize_col = 10,
  border_color = NA,
  main = "Top 20 Most Variable Known Bovine Milk EV miRNAs"
)

# Top 20 Highest TPM Known miRNAs Heatmap
#Step 1: Keep only known bovine miRNAs
library(dplyr)
library(pheatmap)

expr_mat_known <- expr_mat[
  grepl("^bta-", rownames(expr_mat)),
]

dim(expr_mat_known)

head(rownames(expr_mat_known))

#Step 2: Calculate Mean TPM of each known miRNA
#Since your expr_mat is log2(TPM+1), calculate the mean on the original TPM values (data.clean).
mean_TPM <- data.clean %>%
  filter(grepl("^bta-", miRNA)) %>%
  group_by(miRNA) %>%
  summarise(
    Mean_TPM = mean(TPM)
  )

#Step 3: Select Top 20 Highest TPM miRNAs
top20_TPM <- mean_TPM %>%
  arrange(desc(Mean_TPM)) %>%
  slice(1:20)

top20_TPM


#Step 4: Extract expression matrix of Top 20 miRNAs
heatmap_data <- expr_mat_known[
  top20_TPM$miRNA,
]

rownames(heatmap_data)

#Step 5: Create sample annotation
annotation_col <- data.frame(
  Group = factor(c(
    rep("Healthy",7),
    rep("Subclinical",7),
    rep("Clinical",7)
  ))
)

rownames(annotation_col) <- colnames(heatmap_data)

#Step 6: Generate publication-quality heatmap
pheatmap(
  heatmap_data,
  scale = "row",
  annotation_col = annotation_col,
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  show_rownames = TRUE,
  show_colnames = TRUE,
  fontsize_row = 9,
  fontsize_col = 10,
  border_color = NA,
  main = "Top 20 Highest TPM Known Bovine Milk EV miRNAs"
)

# Cluster dendogram

#Option 1. Cluster dendogram of all known bovine miRNAs
# Cluster analysis of known bovine miRNAs

library(dplyr)

# Keep only known miRNAs
expr_mat_known <- expr_mat[
  grepl("^bta-", rownames(expr_mat)),
]

# Calculate distance between miRNAs
dist_miRNA <- dist(expr_mat_known)

# Hierarchical clustering
hc_miRNA <- hclust(
  dist_miRNA,
  method = "complete"
)

# Plot dendrogram
plot(
  hc_miRNA,
  hang = -1,
  cex = 0.5,
  main = "Hierarchical Clustering of Known Bovine Milk EV miRNAs",
  xlab = "",
  sub = ""
)

#Option 2. (Much better for publication): Cluster only the Top 20 Highest TPM known miRNAs
# Extract Top 20 Highest TPM known miRNAs

expr_top20 <- expr_mat[
  top20_TPM$miRNA,
]

# Distance matrix
dist_top20 <- dist(expr_top20)

# Hierarchical clustering
hc_top20 <- hclust(
  dist_top20,
  method = "complete"
)

# Plot dendrogram
plot(
  hc_top20,
  hang = -1,
  cex = 0.8,
  main = "Hierarchical Clustering of Top 20 Highest TPM Known miRNAs",
  xlab = "",
  sub = ""
)

#Option 3 (Best for a high-impact paper): Colored dendrogram
install.packages("dendextend")

library(dendextend)

# Top 20 known miRNAs
expr_top20 <- expr_mat[
  top20_TPM$miRNA,
]

# Distance
dist_top20 <- dist(expr_top20)

# Clustering
hc_top20 <- hclust(
  dist_top20,
  method = "complete"
)

# Convert to dendrogram
dend <- as.dendrogram(hc_top20)

# Color branches
dend <- color_branches(
  dend,
  k = 4
)

# Plot
plot(
  dend,
  main = "Hierarchical Clustering of Top 20 Highest TPM Known miRNAs",
  ylab = "Euclidean Distance"
)




# Point no 8. known vs novel miRNAs
#Option 1 (Recommended): Top 20 Highest TPM Known miRNAs Across Groups
library(dplyr)
library(ggplot2)

# Keep only known miRNAs
known_data <- data.merged %>%
  filter(grepl("^bta|^hsa|^mmu|^ssc", miRNA))

# Calculate mean TPM
top_known <- known_data %>%
  group_by(miRNA) %>%
  summarise(meanTPM = mean(TPM, na.rm = TRUE)) %>%
  arrange(desc(meanTPM)) %>%
  slice(1:20)

# Plot
ggplot(
  known_data %>%
    filter(miRNA %in% top_known$miRNA),
  aes(
    x = reorder(miRNA, TPM, median),
    y = log2(TPM + 1),
    fill = group.y
  )
) +
  geom_boxplot() +
  theme_minimal(base_size = 14) +
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    )
  ) +
  labs(
    title = "Top 20 Highest TPM Known EV miRNAs Across Groups",
    x = "Known miRNA",
    y = "log2(TPM + 1)",
    fill = "Group"
  )

#Option 2 (Better visualization): Violin + Boxplot
library(dplyr)
library(ggplot2)

known_data <- data.merged %>%
  filter(grepl("^bta|^hsa|^mmu|^ssc", miRNA))

top_known <- known_data %>%
  group_by(miRNA) %>%
  summarise(meanTPM = mean(TPM, na.rm = TRUE)) %>%
  arrange(desc(meanTPM)) %>%
  slice(1:20)

ggplot(
  known_data %>%
    filter(miRNA %in% top_known$miRNA),
  aes(
    x = reorder(miRNA, TPM, median),
    y = log2(TPM + 1),
    fill = group.y
  )
) +
  geom_violin(
    trim = FALSE,
    alpha = 0.5,
    position = position_dodge(0.9)
  ) +
  geom_boxplot(
    width = 0.15,
    outlier.shape = NA,
    position = position_dodge(0.9)
  ) +
  theme_classic(base_size = 14) +
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    )
  ) +
  labs(
    title = "Expression of Top 20 Highest TPM Known EV miRNAs",
    x = "Known miRNA",
    y = "log2(TPM + 1)",
    fill = "Group"
  )

#Option 3 (Best for your HR+BC paper)
top_candidates <- candidate_table %>%
  slice(1:20)

ggplot(
  known_data %>%
    filter(miRNA %in% top_candidates$miRNA),
  aes(
    x = reorder(miRNA, TPM, median),
    y = log2(TPM + 1),
    fill = group.y
  )
) +
  geom_boxplot() +
  theme_classic(base_size = 14) +
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    )
  ) +
  labs(
    title = "Top Candidate Therapeutic Known miRNAs Across Groups",
    x = "Known miRNA",
    y = "log2(TPM + 1)"
  )

#9th point TOP expressed miRNAs
#Top 20 expressed known bovine miRNAs
library(dplyr)
library(ggplot2)

# Keep only known bovine miRNAs
known_expr <- data.merged %>%
  filter(grepl("^bta-", miRNA))

# Calculate mean TPM
top_expr_known <- known_expr %>%
  group_by(miRNA) %>%
  summarise(
    Mean_TPM = mean(TPM, na.rm = TRUE)
  ) %>%
  arrange(desc(Mean_TPM)) %>%
  slice(1:20)

top_expr_known

write.csv(
  top_expr_known,
  "Top20_Known_Bovine_miRNAs.csv",
  row.names = FALSE
)


#Publication-quality bar plot
ggplot(
  top_expr_known,
  aes(
    x = reorder(miRNA, Mean_TPM),
    y = Mean_TPM
  )
) +
  geom_col(fill = "steelblue") +
  coord_flip() +
  theme_classic(base_size = 14) +
  labs(
    title = "Top 20 Highest Expressed Known Bovine Milk EV miRNAs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#Better publication-quality plot (recommended)
#Add the TPM values on the bars
ggplot(
  top_expr_known,
  aes(
    x = reorder(miRNA, Mean_TPM),
    y = Mean_TPM
  )
) +
  geom_col(fill = "steelblue") +
  geom_text(
    aes(label = round(Mean_TPM,1)),
    hjust = -0.15,
    size = 3
  ) +
  coord_flip() +
  theme_classic(base_size = 14) +
  expand_limits(y = max(top_expr_known$Mean_TPM)*1.1) +
  labs(
    title = "Top 20 Highest Expressed Known Bovine Milk EV miRNAs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#Even better for your paper (my recommendation)
top20_names <- top_expr_known$miRNA

known_data <- data.merged %>%
  filter(miRNA %in% top20_names)

ggplot(
  known_data,
  aes(
    x = reorder(miRNA, TPM, median),
    y = log2(TPM + 1),
    fill = group.y
  )
) +
  geom_boxplot() +
  theme_classic(base_size = 14) +
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    )
  ) +
  labs(
    title = "Expression of Top 20 Highest Expressed Known Bovine Milk EV miRNAs",
    x = "Known miRNA",
    y = "log2(TPM + 1)",
    fill = "Group"
  )


# S. NO 10 therpeutic miRNA candidate discovery for HR+BC (known miRNAs)
#Step 1: Keep only known bovine miRNAs
library(dplyr)

results_known <- results_sorted %>%
  filter(grepl("^bta-", miRNA))

head(results_known)

dim(results_known)

#Step 2: Calculate Mean TPM for known miRNAs only
mean_TPM_known <- data.merged %>%
  filter(grepl("^bta-", miRNA)) %>%
  group_by(miRNA) %>%
  summarise(
    Mean_TPM = mean(TPM, na.rm = TRUE)
  )

#Step 3: Keep only known miRNAs in target counts
target_counts_known <- target_counts %>%
  filter(grepl("^hsa-", mature_mirna_id))

#Step 4: Create candidate table
candidate_table_known <- results_known %>%
  
  left_join(
    mean_TPM_known,
    by = "miRNA"
  ) %>%
  
  left_join(
    target_counts_known,
    by = c(
      "human_miRNA" = "mature_mirna_id"
    )
  )

#Step 5: Replace missing target counts
candidate_table_known$HRBC_Targets[
  is.na(candidate_table_known$HRBC_Targets)
] <- 0

#Step 6: Candidate Score
candidate_table_known$Score <-
  
  abs(candidate_table_known$logFC) *
  
  log10(
    candidate_table_known$Mean_TPM + 1
  ) *
  
  (
    candidate_table_known$HRBC_Targets + 1
  )

#Step 7: Rank candidates
candidate_table_known <- candidate_table_known[
  order(
    candidate_table_known$Score,
    decreasing = TRUE
  ),
]

#Step 8: View top 20
head(
  candidate_table_known[
    ,
    c(
      "miRNA",
      "logFC",
      "Mean_TPM",
      "HRBC_Targets",
      "Score"
    )
  ],
  20
)

#Step 9: Extract Top 10
top10_known <- head(
  candidate_table_known,
  10
)

top10_known

#Step 10: Save CSV
write.csv(
  candidate_table_known,
  "Ranked_HRBC_Known_miRNA_Candidates.csv",
  row.names = FALSE
)

#Step 11: Publication-quality plot
library(ggplot2)

ggplot(
  top10_known,
  aes(
    x = reorder(miRNA, Score),
    y = Score
  )
) +
  geom_col(fill = "steelblue") +
  coord_flip() +
  theme_classic(base_size = 14) +
  labs(
    title = "Top Known Bovine Milk EV miRNA Candidates for HR+ Breast Cancer",
    x = "Known bovine miRNA",
    y = "Candidate Score"
  )

#Step 12: Extract target genes
top10_known$human_miRNA

top_targets_known <- unique(
  
  bc_targets_unique$target_symbol[
    
    bc_targets_unique$mature_mirna_id %in%
      
      top10_known$human_miRNA
  ]
)

write.csv(
  data.frame(
    Gene = top_targets_known
  ),
  "Top10_Known_HRBC_Target_Genes.csv",
  row.names = FALSE
)


#S. NO 11 Pathway enrichment
#Step 1: Select the Top 10 Known Therapeutic miRNAs Automatically
library(dplyr)

top_known_miRNAs <- candidate_table_known %>%
  filter(grepl("^bta-", miRNA)) %>%
  slice(1:10) %>%
  pull(human_miRNA)

top_known_miRNAs

#Step 2: Extract Unique Target Genes
genes <- bc_targets_unique %>%
  filter(
    mature_mirna_id %in% top_known_miRNAs
  ) %>%
  pull(target_symbol) %>%
  unique()

length(genes)

head(genes)

#Step 3: Run g:Profiler
library(gprofiler2)

gost_res <- gost(
  query = genes,
  organism = "hsapiens",
  correction_method = "fdr"
)

#Step 4: Remove list columns
gost_df <- gost_res$result

gost_df2 <- gost_df[
  ,
  !sapply(gost_df, is.list)
]

#Step 5: Save Complete Results
write.csv(
  gost_df2,
  "Known_HRBC_Pathway_Enrichment.csv",
  row.names = FALSE
)

#KEGG
kegg_results <- subset(
  gost_df2,
  source == "KEGG"
)

write.csv(
  kegg_results,
  "Known_KEGG_Pathways.csv",
  row.names = FALSE
)

head(kegg_results)

#Reactome
reactome_results <- subset(
  gost_df2,
  source == "REAC"
)

write.csv(
  reactome_results,
  "Known_Reactome_Pathways.csv",
  row.names = FALSE
)

head(reactome_results)

#GO Biological Process
go_bp <- subset(
  gost_df2,
  source == "GO:BP"
)

write.csv(
  go_bp,
  "Known_GO_Biological_Process.csv",
  row.names = FALSE
)

head(go_bp)

#HR+ Breast Cancer Related Pathways
hrbc_pathways <- gost_df2[
  grepl(
    "PI3K|AKT|mTOR|Estrogen|Breast|Cell cycle|Apoptosis|MAPK|FOXO|JAK|STAT|p53|ERBB2|EGFR",
    gost_df2$term_name,
    ignore.case = TRUE
  ),
]

hrbc_pathways[
  ,
  c(
    "term_name",
    "source",
    "p_value",
    "intersection_size"
  )
]

write.csv(
  hrbc_pathways,
  "Known_HRBC_Pathways.csv",
  row.names = FALSE
)

#Top 20 Enriched Pathways
top20 <- gost_df2[
  order(gost_df2$p_value),
][1:20, ]

write.csv(
  top20,
  "Known_Top20_Pathways.csv",
  row.names = FALSE
)

top20[
  ,
  c(
    "term_name",
    "source",
    "p_value",
    "intersection_size"
  )
]

#Publication-quality Dot Plot
library(ggplot2)

ggplot(
  top20,
  aes(
    x = reorder(term_name, -log10(p_value)),
    y = -log10(p_value)
  )
) +
  geom_point(
    aes(
      size = intersection_size,
      color = source
    )
  ) +
  coord_flip() +
  theme_classic(base_size = 14) +
  labs(
    title = "Top Enriched Pathways of Known Therapeutic Bovine Milk EV miRNAs",
    x = "Pathway",
    y = "-log10(FDR)",
    color = "Database",
    size = "Gene Count"
  )

#Determine Which Known miRNAs Target Key HR+BC Genes
key_targets <- bc_targets_unique %>%
  filter(
    mature_mirna_id %in% top_known_miRNAs
  ) %>%
  filter(
    target_symbol %in%
      c(
        "ESR1",
        "PGR",
        "PIK3CA",
        "AKT1",
        "MTOR",
        "PTEN",
        "CCND1",
        "BCL2",
        "STAT3",
        "MYC"
      )
  ) %>%
  arrange(
    mature_mirna_id,
    target_symbol
  )

key_targets

write.csv(
  key_targets,
  "Known_Key_HRBC_Targets.csv",
  row.names = FALSE
)

#Network Table for Cytoscape
network_table <- bc_targets_unique %>%
  filter(
    mature_mirna_id %in% top_known_miRNAs
  ) %>%
  select(
    mature_mirna_id,
    target_symbol
  )

write.csv(
  network_table,
  "Known_miRNA_Gene_Network.csv",
  row.names = FALSE
)


#21.07.2026 Corrected limma pipeline

#let's inspect your current workspace
ls(pattern = "expr|design|group|meta|matrix|contrast|sample")

dim(expr_mat)
head(expr_mat[,1:5])

head(group)

#Step 1 Log2 transform the expression matrix
expr_mat_log <- log2(expr_mat + 1)

summary(as.numeric(as.matrix(expr_mat_log)))

range(as.numeric(as.matrix(expr_mat_log)))

#Step 2 Verify sample order
colnames(expr_mat_log)

#Step 3: Create the group vector
group <- factor(c(
  rep("H", 7),
  rep("M", 7),
  rep("SM", 7)
))

table(group)

#Step 4: Design matrix
library(limma)

design <- model.matrix(~0 + group)
colnames(design) <- levels(group)

design


#Step 5: Contrast matrix
contrast.matrix <- makeContrasts(
  H_vs_SM = H - SM,
  H_vs_M  = H - M,
  SM_vs_M = SM - M,
  levels = design
)

contrast.matrix


#Step 6: Fit the model
fit <- lmFit(expr_mat_log, design)

fit2 <- contrasts.fit(fit, contrast.matrix)

fit2 <- eBayes(fit2)

#Step 7: Extract differential expression results
results_H_SM <- topTable(
  fit2,
  coef = "H_vs_SM",
  number = Inf,
  sort.by = "P"
)

results_H_M <- topTable(
  fit2,
  coef = "H_vs_M",
  number = Inf,
  sort.by = "P"
)

results_SM_M <- topTable(
  fit2,
  coef = "SM_vs_M",
  number = Inf,
  sort.by = "P"
)


#Step 8: Check the logFC distribution
summary(results_H_SM$logFC)
summary(results_H_M$logFC)
summary(results_SM_M$logFC)

#Step 9: Save the results

write.csv(results_H_SM, "Results_H_vs_SM.csv", row.names = TRUE)
write.csv(results_H_M,  "Results_H_vs_M.csv",  row.names = TRUE)
write.csv(results_SM_M, "Results_SM_vs_M.csv", row.names = TRUE)

head(results_H_SM)

#Load packages
library(limma)
library(dplyr)
library(tidyr)
library(ggplot2)
library(pheatmap)
library(EnhancedVolcano)
library(RColorBrewer)
library(ggrepel)


#Step 10. Filter significant miRNAs
#Healthy vs Subclinical Mastitis
sig_H_SM <- results_H_SM %>%
  dplyr::filter(adj.P.Val < 0.05 & abs(logFC) > 1)

nrow(sig_H_SM)

sig_H_SM

#Healthy vs Clinical Mastitis
sig_H_M <- results_H_M %>%
  dplyr::filter(adj.P.Val < 0.05 & abs(logFC) > 1)

nrow(sig_H_M)

sig_H_M

#Subclinical vs Clinical Mastitis
sig_SM_M <- results_SM_M %>%
  dplyr::filter(adj.P.Val < 0.05 & abs(logFC) > 1)

nrow(sig_SM_M)

sig_SM_M

write.csv(sig_H_SM,"Significant_H_vs_SM.csv")
write.csv(sig_H_M,"Significant_H_vs_M.csv")
write.csv(sig_SM_M,"Significant_SM_vs_M.csv")


#Step 11. Volcano plots
#Healthy vs SM
EnhancedVolcano(
  results_H_SM,
  lab=rownames(results_H_SM),
  x="logFC",
  y="adj.P.Val",
  pCutoff=0.05,
  FCcutoff=1,
  title="Healthy vs Subclinical Mastitis"
)

#Healthy vs M
EnhancedVolcano(
  results_H_M,
  lab=rownames(results_H_M),
  x="logFC",
  y="adj.P.Val",
  pCutoff=0.05,
  FCcutoff=1,
  title="Healthy vs Clinical Mastitis"
)

#SM vs M
EnhancedVolcano(
  results_SM_M,
  lab=rownames(results_SM_M),
  x="logFC",
  y="adj.P.Val",
  pCutoff=0.05,
  FCcutoff=1,
  title="Subclinical vs Clinical Mastitis"
)

#Step 12. Heatmap
top30 <- rownames(results_H_SM)[1:30]

heatmap_matrix <- expr_mat_log[top30, ]

annotation_col <- data.frame(Group = group)
rownames(annotation_col) <- colnames(heatmap_matrix)

pheatmap(
  heatmap_matrix,
  scale="row",
  annotation_col=annotation_col,
  cluster_rows=TRUE,
  cluster_cols=TRUE,
  show_rownames=TRUE,
  fontsize_row=8,
  fontsize_col=10
)


top20 <- rownames(results_H_SM)[1:20]

heatmap_matrix <- expr_mat_log[top20, ]

annotation_col <- data.frame(Group = group)
rownames(annotation_col) <- colnames(heatmap_matrix)

pheatmap(
  heatmap_matrix,
  scale="row",
  annotation_col=annotation_col,
  cluster_rows=TRUE,
  cluster_cols=TRUE,
  show_rownames=TRUE,
  fontsize_row=8,
  fontsize_col=10
)

#Step 13. Candidate miRNAs
candidate_miRNAs <- c(
  "bta-let-7a-5p",
  "bta-let-7b",
  "bta-let-7f",
  "bta-let-7g",
  "bta-let-7i",
  "bta-miR-182",
  "bta-miR-186",
  "bta-miR-21-5p",
  "bta-miR-23a",
  "bta-miR-24-3p",
  "bta-miR-26a",
  "bta-miR-27a-3p",
  "bta-miR-27b",
  "bta-miR-30a-5p",
  "bta-miR-30d",
  "bta-miR-30e-5p",
  "bta-miR-574",
  "bta-miR-7",
  "bta-miR-92a"
)

candidate_results <- results_H_SM[candidate_miRNAs, ]

candidate_results

write.csv(candidate_results,
          "Candidate_miRNAs.csv")

write.csv(candidate_validation_table,
          "Candidate_Validation_Final.csv",
          row.names=FALSE)



#Distribution expression analysis image_revised

library(dplyr)
library(ggplot2)

# Check structure
str(data.clean)

# Check number of miRNAs and samples
length(unique(data.clean$miRNA))
length(unique(data.clean$samples))

# Check groups
table(data.clean$group)


data.clean <- data.clean %>%
  mutate(
    group = case_when(
      grepl("^H[0-9]+$", samples) ~ "Healthy",
      grepl("^SM[0-9]+$", samples) ~ "Subclinical",
      grepl("^M[0-9]+$", samples) ~ "Clinical",
      TRUE ~ NA_character_
    )
  )

table(data.clean$group)


table(data.clean$group)

data.clean %>%
  distinct(samples, group) %>%
  arrange(group, samples)


data.clean %>%
  count(group, samples)


data.clean$group <- factor(
  data.clean$group,
  levels = c("Healthy", "Subclinical", "Clinical")
)

levels(data.clean$group)

data.dist <- data.clean %>%
  mutate(
    log2_TPM = log2(TPM + 1)
  )

summary(data.dist$log2_TPM)

sample_summary <- data.dist %>%
  group_by(samples, group) %>%
  summarise(
    median_log2_TPM = median(log2_TPM, na.rm = TRUE),
    mean_log2_TPM = mean(log2_TPM, na.rm = TRUE),
    detected_miRNAs = sum(TPM > 0),
    .groups = "drop"
  )

sample_summary


sample_summary %>%
  arrange(median_log2_TPM)

sample_summary %>%
  arrange(detected_miRNAs)


library(ggplot2)

ggplot(
  data.dist,
  aes(
    x = samples,
    y = log2_TPM,
    fill = group
  )
) +
  
  geom_boxplot(
    width = 0.65,
    outlier.shape = NA,
    alpha = 0.75
  ) +
  
  geom_jitter(
    aes(color = group),
    width = 0.12,
    size = 0.35,
    alpha = 0.20
  ) +
  
  facet_grid(
    . ~ group,
    scales = "free_x",
    space = "free_x"
  ) +
  
  labs(
    title = "Global miRNA abundance distribution across bovine milk EV samples",
    x = "Individual samples",
    y = expression(log[2]~"(TPM + 1)")
  ) +
  
  theme_classic(base_size = 13) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 15
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1,
      size = 9
    ),
    axis.title = element_text(
      face = "bold",
      size = 12
    ),
    strip.text = element_text(
      face = "bold",
      size = 12
    ),
    strip.background = element_blank(),
    legend.position = "none"
  )

#sample correlation heatmap

library(tidyr)

expr_mat <- data.clean %>%
  select(miRNA, samples, TPM) %>%
  pivot_wider(
    names_from = samples,
    values_from = TPM,
    values_fill = 0
  )

expr_mat <- as.data.frame(expr_mat)

rownames(expr_mat) <- expr_mat$miRNA

expr_mat$miRNA <- NULL

expr_mat <- as.matrix(expr_mat)

dim(expr_mat)



log_expr <- log2(expr_mat + 1)

cor_mat <- cor(
  log_expr,
  method = "spearman"
)


library(pheatmap)

pheatmap(
  cor_mat,
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  border_color = NA,
  main = "Spearman correlation of bovine milk EV miRNA profiles"
)

#PCA
pca <- prcomp(
  t(log_expr),
  center = TRUE,
  scale. = TRUE
)

pca_df <- data.frame(
  Sample = rownames(pca$x),
  PC1 = pca$x[, 1],
  PC2 = pca$x[, 2]
)

pca_df$Group <- case_when(
  grepl("^H[0-9]+$", pca_df$Sample) ~ "Healthy",
  grepl("^SM[0-9]+$", pca_df$Sample) ~ "Subclinical",
  grepl("^M[0-9]+$", pca_df$Sample) ~ "Clinical"
)

pca_df$Group <- factor(
  pca_df$Group,
  levels = c("Healthy", "Subclinical", "Clinical")
)

table(pca_df$Group)

# PCA variance explained
round(var_explained[1:5], 2)


library(ggplot2)
library(ggrepel)

# Calculate variance explained
var_explained <- (pca$sdev^2) / sum(pca$sdev^2) * 100

# Publication-quality PCA
# Publication-quality PCA
p_pca <- ggplot(
  pca_df,
  aes(
    x = PC1,
    y = PC2,
    shape = Group,
    fill = Group
  )
) +
  
  geom_point(
    size = 4,
    color = "black",
    stroke = 0.8
  ) +
  
  geom_text_repel(
    aes(label = Sample),
    size = 3.5,
    max.overlaps = Inf,
    box.padding = 0.5,
    point.padding = 0.3,
    show.legend = FALSE
  ) +
  
  scale_shape_manual(
    values = c(
      "Healthy" = 21,
      "Subclinical" = 22,
      "Clinical" = 24
    )
  ) +
  
  scale_fill_manual(
    values = c(
      "Healthy" = "#2E7D32",       # Green
      "Subclinical" = "#1976D2",   # Blue
      "Clinical" = "#D32F2F"       # Red
    )
  ) +
  
  labs(
    title = "Principal Component Analysis of bovine milk EV miRNA profiles",
    x = paste0("PC1 (", round(var_explained[1], 1), "%)"),
    y = paste0("PC2 (", round(var_explained[2], 1), "%)"),
    shape = "Group",
    fill = "Group"
  ) +
  
  theme_classic(base_size = 14) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 16
    ),
    axis.title = element_text(face = "bold"),
    axis.text = element_text(color = "black"),
    legend.title = element_text(face = "bold"),
    legend.text = element_text(size = 12),
    legend.position = "right"
  )

p_pca

#pca

# Set the desired biological order
pca_df$Group <- factor(
  pca_df$Group,
  levels = c("Healthy", "Subclinical", "Clinical")
)

# Check
table(pca_df$Group)
levels(pca_df$Group)

library(factoextra)

fviz_pca_ind(
  pca,
  geom.ind = "point",
  habillage = pca_df$Group,
  addEllipses = TRUE,
  repel = TRUE,
  pointsize = 4,
  palette = c(
    "Healthy" = "green3",
    "Subclinical" = "blue3",
    "Clinical" = "red3"
  )
)

#better pca plot

library(ggplot2)
library(ggrepel)

# Ensure correct group order
pca_df$Group <- factor(
  pca_df$Group,
  levels = c("Healthy", "Subclinical", "Clinical")
)

# Publication-quality PCA
p_pca <- ggplot(
  pca_df,
  aes(
    x = PC1,
    y = PC2,
    shape = Group,
    fill = Group
  )
) +
  
  geom_point(
    size = 4,
    color = "black",
    stroke = 0.8
  ) +
  
  geom_text_repel(
    aes(label = Sample),
    size = 3.5,
    max.overlaps = Inf,
    box.padding = 0.5,
    point.padding = 0.3,
    show.legend = FALSE
  ) +
  
  scale_shape_manual(
    values = c(
      "Healthy" = 21,
      "Subclinical" = 22,
      "Clinical" = 24
    ),
    breaks = c(
      "Healthy",
      "Subclinical",
      "Clinical"
    )
  ) +
  
  scale_fill_manual(
    values = c(
      "Healthy" = "green3",
      "Subclinical" = "blue3",
      "Clinical" = "red3"
    ),
    breaks = c(
      "Healthy",
      "Subclinical",
      "Clinical"
    )
  ) +
  
  labs(
    title = "PCA of bovine milk EV miRNA profiles",
    x = paste0(
      "PC1 (",
      round(var_explained[1], 1),
      "%)"
    ),
    y = paste0(
      "PC2 (",
      round(var_explained[2], 1),
      "%)"
    ),
    shape = "Group",
    fill = "Group"
  ) +
  
  theme_classic(base_size = 14) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 16
    ),
    axis.title = element_text(
      face = "bold"
    ),
    axis.text = element_text(
      color = "black"
    ),
    legend.title = element_text(
      face = "bold"
    ),
    legend.text = element_text(
      size = 12
    ),
    legend.position = "right"
  )

p_pca


#revsied volcano plots
#Step 1 — Verify your expression matrix

dim(expr_mat)
colnames(expr_mat)
rownames(expr_mat)[1:10]

#Step 2 — Create the group variable directly from sample names


library(dplyr)

group <- case_when(
  grepl("^H[0-9]+$", sample_names)  ~ "Healthy",
  grepl("^SM[0-9]+$", sample_names) ~ "Subclinical",
  grepl("^M[0-9]+$", sample_names)  ~ "Clinical",
  TRUE ~ NA_character_
)

table(group, useNA = "ifany")

levels(group)

group <- factor(
  group,
  levels = c("Healthy", "Subclinical", "Clinical")
)

levels(group)

table(group, useNA = "ifany")

data.frame(
  Sample = sample_names,
  Group = group
)

design <- model.matrix(~ 0 + group)

colnames(design) <- c(
  "Healthy",
  "Subclinical",
  "Clinical"
)

design

dim(design)

colSums(design)

contrast.matrix <- makeContrasts(
  Clinical_vs_Healthy = Clinical - Healthy,
  Subclinical_vs_Healthy = Subclinical - Healthy,
  Clinical_vs_Subclinical = Clinical - Subclinical,
  levels = design
)

contrast.matrix

library(limma)

makeContrasts

contrast.matrix <- makeContrasts(
  Clinical_vs_Healthy = Clinical - Healthy,
  Subclinical_vs_Healthy = Subclinical - Healthy,
  Clinical_vs_Subclinical = Clinical - Subclinical,
  levels = design
)

contrast.matrix

fit <- lmFit(
  expr_mat,
  design
)

fit2 <- contrasts.fit(
  fit,
  contrast.matrix
)

fit2 <- eBayes(fit2)

res_clinical_vs_healthy <- topTable(
  fit2,
  coef = "Clinical_vs_Healthy",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

res_subclinical_vs_healthy <- topTable(
  fit2,
  coef = "Subclinical_vs_Healthy",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

res_clinical_vs_subclinical <- topTable(
  fit2,
  coef = "Clinical_vs_Subclinical",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

library(limma)
library(EnhancedVolcano)

# Apply all three contrasts
fit2 <- contrasts.fit(fit, contrast.matrix)

# Empirical Bayes moderation
fit2 <- eBayes(fit2)

# Extract complete results for each comparison
results_clinical_vs_healthy <- topTable(
  fit2,
  coef = "Clinical_vs_Healthy",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

results_subclinical_vs_healthy <- topTable(
  fit2,
  coef = "Subclinical_vs_Healthy",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

results_clinical_vs_subclinical <- topTable(
  fit2,
  coef = "Clinical_vs_Subclinical",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

head(results_clinical_vs_healthy)
head(results_subclinical_vs_healthy)
head(results_clinical_vs_subclinical)

sum(results_clinical_vs_healthy$adj.P.Val < 0.05)
sum(results_subclinical_vs_healthy$adj.P.Val < 0.05)
sum(results_clinical_vs_subclinical$adj.P.Val < 0.05)


p_clinical_healthy <- EnhancedVolcano(
  results_clinical_vs_healthy,
  lab = rownames(results_clinical_vs_healthy),
  
  x = "logFC",
  y = "adj.P.Val",
  
  title = "Clinical mastitis vs Healthy",
  subtitle = "Bovine milk EV miRNAs | GSE201588",
  
  pCutoff = 0.05,
  FCcutoff = 1,
  
  pointSize = 2.5,
  labSize = 3.5,
  
  colAlpha = 0.8,
  
  drawConnectors = TRUE,
  widthConnectors = 0.5,
  
  max.overlaps = 15,
  
  boxedLabels = FALSE,
  
  gridlines.major = FALSE,
  gridlines.minor = FALSE,
  
  legendPosition = "right",
  
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"(adjusted P-value)")
)

p_clinical_healthy


p_subclinical_healthy <- EnhancedVolcano(
  results_subclinical_vs_healthy,
  lab = rownames(results_subclinical_vs_healthy),
  
  x = "logFC",
  y = "adj.P.Val",
  
  title = "Subclinical mastitis vs Healthy",
  subtitle = "Bovine milk EV miRNAs | GSE201588",
  
  pCutoff = 0.05,
  FCcutoff = 1,
  
  pointSize = 2.5,
  labSize = 3.5,
  
  colAlpha = 0.8,
  
  drawConnectors = TRUE,
  widthConnectors = 0.5,
  
  max.overlaps = 15,
  
  boxedLabels = FALSE,
  
  gridlines.major = FALSE,
  gridlines.minor = FALSE,
  
  legendPosition = "right",
  
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"(adjusted P-value)")
)

p_subclinical_healthy

p_clinical_subclinical <- EnhancedVolcano(
  results_clinical_vs_subclinical,
  lab = rownames(results_clinical_vs_subclinical),
  
  x = "logFC",
  y = "adj.P.Val",
  
  title = "Clinical mastitis vs Subclinical mastitis",
  subtitle = "Bovine milk EV miRNAs | GSE201588",
  
  pCutoff = 0.05,
  FCcutoff = 1,
  
  pointSize = 2.5,
  labSize = 3.5,
  
  colAlpha = 0.8,
  
  drawConnectors = TRUE,
  widthConnectors = 0.5,
  
  max.overlaps = 15,
  
  boxedLabels = FALSE,
  
  gridlines.major = FALSE,
  gridlines.minor = FALSE,
  
  legendPosition = "right",
  
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"(adjusted P-value)")
)

p_clinical_subclinical

results_clinical_vs_healthy$Significance <- "Not significant"

results_clinical_vs_healthy$Significance[
  results_clinical_vs_healthy$adj.P.Val < 0.05 &
    results_clinical_vs_healthy$logFC >= 1
] <- "Upregulated"

results_clinical_vs_healthy$Significance[
  results_clinical_vs_healthy$adj.P.Val < 0.05 &
    results_clinical_vs_healthy$logFC <= -1
] <- "Downregulated"

table(results_clinical_vs_healthy$Significance)


results_clinical_vs_healthy$Significance <- "Not significant"

results_clinical_vs_healthy$Significance[
  results_clinical_vs_healthy$adj.P.Val < 0.05 &
    results_clinical_vs_healthy$logFC >= 1
] <- "Upregulated"

results_clinical_vs_healthy$Significance[
  results_clinical_vs_healthy$adj.P.Val < 0.05 &
    results_clinical_vs_healthy$logFC <= -1
] <- "Downregulated"

table(results_clinical_vs_healthy$Significance)



results_subclinical_vs_healthy$Significance <- "Not significant"

results_subclinical_vs_healthy$Significance[
  results_subclinical_vs_healthy$adj.P.Val < 0.05 &
    results_subclinical_vs_healthy$logFC >= 1
] <- "Upregulated"

results_subclinical_vs_healthy$Significance[
  results_subclinical_vs_healthy$adj.P.Val < 0.05 &
    results_subclinical_vs_healthy$logFC <= -1
] <- "Downregulated"


results_clinical_vs_subclinical$Significance <- "Not significant"

results_clinical_vs_subclinical$Significance[
  results_clinical_vs_subclinical$adj.P.Val < 0.05 &
    results_clinical_vs_subclinical$logFC >= 1
] <- "Upregulated"

results_clinical_vs_subclinical$Significance[
  results_clinical_vs_subclinical$adj.P.Val < 0.05 &
    results_clinical_vs_subclinical$logFC <= -1
] <- "Downregulated"


sig_ch <- subset(
  results_clinical_vs_healthy,
  adj.P.Val < 0.05 & abs(logFC) >= 1
)

sig_ch <- sig_ch[
  order(sig_ch$adj.P.Val),
]

top_labels_ch <- rownames(sig_ch)[1:min(10, nrow(sig_ch))]


p_clinical_healthy <- EnhancedVolcano(
  results_clinical_vs_healthy,
  
  lab = ifelse(
    rownames(results_clinical_vs_healthy) %in% top_labels_ch,
    rownames(results_clinical_vs_healthy),
    ""
  ),
  
  x = "logFC",
  y = "adj.P.Val",
  
  title = "Clinical mastitis vs Healthy",
  subtitle = "GSE201588 | bovine milk EV miRNAs",
  
  pCutoff = 0.05,
  FCcutoff = 1,
  
  pointSize = 2.5,
  labSize = 3.5,
  
  drawConnectors = TRUE,
  widthConnectors = 0.4,
  
  boxedLabels = FALSE,
  
  gridlines.major = FALSE,
  gridlines.minor = FALSE,
  
  max.overlaps = Inf,
  
  legendPosition = "right",
  
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"(adjusted P-value)")
)

p_clinical_healthy


table(data.clean$miRNA_type)

colnames(data.clean)

ls()

dim(expr_mat_known)

head(rownames(expr_mat_known), 20)

tail(rownames(expr_mat_known), 20)

length(known_miRNA)

head(known_miRNA, 20)

results_H_M_known
results_H_SM_known
results_SM_M_known

dim(results_H_M_known)
dim(results_H_SM_known)
dim(results_SM_M_known)

head(results_H_M_known)
head(results_H_SM_known)
head(results_SM_M_known)

sum(results_H_M_known$adj.P.Val < 0.05, na.rm = TRUE)

sum(results_H_SM_known$adj.P.Val < 0.05, na.rm = TRUE)

sum(results_SM_M_known$adj.P.Val < 0.05, na.rm = TRUE)

sum(
  results_H_M_known$adj.P.Val < 0.05 &
    abs(results_H_M_known$logFC) >= 1,
  na.rm = TRUE
)

sum(
  results_H_SM_known$adj.P.Val < 0.05 &
    abs(results_H_SM_known$logFC) >= 1,
  na.rm = TRUE
)

sum(
  results_SM_M_known$adj.P.Val < 0.05 &
    abs(results_SM_M_known$logFC) >= 1,
  na.rm = TRUE
)

results_H_M_known
results_H_SM_known
results_SM_M_known

library(EnhancedVolcano)

make_volcano <- function(
    res,
    title,
    subtitle = "Known bovine milk EV miRNAs"
) {
  
  EnhancedVolcano(
    res,
    lab = rownames(res),
    x = "logFC",
    y = "adj.P.Val",
    
    pCutoff = 0.05,
    FCcutoff = 1,
    
    title = title,
    subtitle = subtitle,
    
    xlab = expression(Log[2]~"fold change"),
    ylab = expression(-Log[10]~"adjusted P-value"),
    
    pointSize = 2.8,
    labSize = 3.5,
    
    drawConnectors = TRUE,
    widthConnectors = 0.5,
    colConnectors = "grey40",
    
    max.overlaps = 15,
    
    boxedLabels = FALSE,
    
    legendPosition = "right",
    legendLabSize = 10,
    legendIconSize = 3,
    
    gridlines.major = FALSE,
    gridlines.minor = FALSE,
    
    border = "full",
    borderWidth = 0.8
  )
}

p_H_SM <- make_volcano(
  results_H_SM_known,
  "Subclinical vs Healthy"
)

p_H_SM


library(ggplot2)
library(dplyr)
library(ggrepel)
library(patchwork)

# Clinical vs Healthy
vol_H_M <- results_H_M_known %>%
  mutate(
    miRNA = rownames(.),
    FDR = adj.P.Val,
    neg_log10_FDR = -log10(pmax(FDR, 1e-300))
  )

# Subclinical vs Healthy
vol_H_SM <- results_H_SM_known %>%
  mutate(
    miRNA = rownames(.),
    FDR = adj.P.Val,
    neg_log10_FDR = -log10(pmax(FDR, 1e-300))
  )

# Clinical vs Subclinical
vol_SM_M <- results_SM_M_known %>%
  mutate(
    miRNA = rownames(.),
    FDR = adj.P.Val,
    neg_log10_FDR = -log10(pmax(FDR, 1e-300))
  )

classify_miRNA <- function(df) {
  
  df %>%
    mutate(
      Status = case_when(
        FDR < 0.05 & abs(logFC) >= 1 ~ "FDR significant",
        abs(logFC) >= 1 ~ "Large fold change",
        TRUE ~ "Not significant"
      )
    )
}

vol_H_M  <- classify_miRNA(vol_H_M)
vol_H_SM <- classify_miRNA(vol_H_SM)
vol_SM_M <- classify_miRNA(vol_SM_M)

table(vol_H_M$Status)
table(vol_H_SM$Status)
table(vol_SM_M$Status)

get_top_labels <- function(df, n = 3) {
  
  df %>%
    arrange(desc(abs(logFC))) %>%
    slice_head(n = n)
}

labels_H_M  <- get_top_labels(vol_H_M, 3)
labels_H_SM <- get_top_labels(vol_H_SM, 3)
labels_SM_M <- get_top_labels(vol_SM_M, 3)

labels_H_M$miRNA
labels_H_SM$miRNA
labels_SM_M$miRNA

make_volcano <- function(df, labels, title) {
  
  ggplot(df, aes(x = logFC, y = neg_log10_FDR)) +
    
    # All miRNAs
    geom_point(
      aes(fill = Status),
      shape = 21,
      size = 3,
      color = "black",
      stroke = 0.25,
      alpha = 0.85
    ) +
    
    # Fold-change thresholds
    geom_vline(
      xintercept = c(-1, 1),
      linetype = "dashed",
      linewidth = 0.5
    ) +
    
    # FDR threshold
    geom_hline(
      yintercept = -log10(0.05),
      linetype = "dashed",
      linewidth = 0.5
    ) +
    
    # Labels
    geom_text_repel(
      data = labels,
      aes(label = miRNA),
      size = 3.5,
      fontface = "italic",
      box.padding = 0.5,
      point.padding = 0.25,
      max.overlaps = Inf,
      min.segment.length = 0,
      show.legend = FALSE
    ) +
    
    scale_fill_manual(
      values = c(
        "Not significant" = "grey70",
        "Large fold change" = "steelblue",
        "FDR significant" = "firebrick"
      )
    ) +
    
    labs(
      title = title,
      x = expression(log[2]~"fold change"),
      y = expression(-log[10]~"(FDR)"),
      fill = NULL
    ) +
    
    theme_classic(base_size = 14) +
    
    theme(
      plot.title = element_text(
        face = "bold",
        size = 15,
        hjust = 0.5
      ),
      
      axis.title = element_text(
        face = "bold",
        size = 13
      ),
      
      axis.text = element_text(
        color = "black",
        size = 11
      ),
      
      legend.position = "top",
      legend.text = element_text(size = 11),
      
      panel.border = element_rect(
        color = "black",
        fill = NA,
        linewidth = 0.5
      )
    )
}


p_H_M <- make_volcano(
  vol_H_M,
  labels_H_M,
  "Clinical vs Healthy"
)

p_H_SM <- make_volcano(
  vol_H_SM,
  labels_H_SM,
  "Subclinical vs Healthy"
)

p_SM_M <- make_volcano(
  vol_SM_M,
  labels_SM_M,
  "Clinical vs Subclinical"
)

p_H_M
p_H_SM
p_SM_M

volcano_combined <- 
  p_H_M + p_H_SM + p_SM_M +
  plot_layout(ncol = 3)


volcano_combined

all_volcano <- bind_rows(
  vol_H_M,
  vol_H_SM,
  vol_SM_M
)

x_limit <- max(abs(all_volcano$logFC), na.rm = TRUE)

y_limit <- max(all_volcano$neg_log10_FDR, na.rm = TRUE)



make_volcano_common <- function(df, labels, title) {
  
  ggplot(df, aes(x = logFC, y = neg_log10_FDR)) +
    
    geom_point(
      aes(fill = Status),
      shape = 21,
      size = 3,
      color = "black",
      stroke = 0.25,
      alpha = 0.85
    ) +
    
    geom_vline(
      xintercept = c(-1, 1),
      linetype = "dashed",
      linewidth = 0.5
    ) +
    
    geom_hline(
      yintercept = -log10(0.05),
      linetype = "dashed",
      linewidth = 0.5
    ) +
    
    geom_text_repel(
      data = labels,
      aes(label = miRNA),
      size = 3.2,
      fontface = "italic",
      box.padding = 0.5,
      point.padding = 0.25,
      max.overlaps = Inf,
      min.segment.length = 0,
      show.legend = FALSE
    ) +
    
    scale_fill_manual(
      values = c(
        "Not significant" = "grey70",
        "Large fold change" = "steelblue",
        "FDR significant" = "firebrick"
      )
    ) +
    
    scale_x_continuous(
      limits = c(-x_limit, x_limit)
    ) +
    
    scale_y_continuous(
      limits = c(0, y_limit * 1.05)
    ) +
    
    labs(
      title = title,
      x = expression(log[2]~"fold change"),
      y = expression(-log[10]~"(FDR)"),
      fill = NULL
    ) +
    
    theme_classic(base_size = 14) +
    
    theme(
      plot.title = element_text(
        face = "bold",
        size = 15,
        hjust = 0.5
      ),
      
      axis.title = element_text(
        face = "bold",
        size = 13
      ),
      
      axis.text = element_text(
        color = "black",
        size = 11
      ),
      
      legend.position = "top",
      legend.text = element_text(size = 10),
      
      panel.border = element_rect(
        color = "black",
        fill = NA,
        linewidth = 0.5
      )
    )
}



p_H_M <- make_volcano_common(
  vol_H_M,
  labels_H_M,
  "Clinical vs Healthy"
)

p_H_SM <- make_volcano_common(
  vol_H_SM,
  labels_H_SM,
  "Subclinical vs Healthy"
)

p_SM_M <- make_volcano_common(
  vol_SM_M,
  labels_SM_M,
  "Clinical vs Subclinical"
)

volcano_final <- 
  p_H_M + p_H_SM + p_SM_M +
  plot_layout(ncol = 3)


volcano_final


volcano_final <- 
  p_H_M + p_H_SM + p_SM_M +
  plot_layout(ncol = 3) +
  plot_annotation(
    tag_levels = "A"
  )

volcano_final

ggsave(
  filename = "Figure_GSE201588_Known_miRNA_Volcano.tiff",
  plot = volcano_final,
  width = 12,
  height = 4.5,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

#volcano (repeat)


library(limma)
library(EnhancedVolcano)

# ============================================================
# 1. Define sample groups
# ============================================================

group <- factor(
  c(
    rep("Healthy", 7),
    rep("Clinical", 7),
    rep("Subclinical", 7)
  ),
  levels = c("Healthy", "Clinical", "Subclinical")
)

# Check group distribution
table(group)


# ============================================================
# 2. Log2 transform TPM expression
# ============================================================

expr_log2 <- log2(expr_mat + 1)


# ============================================================
# 3. Create design matrix
# ============================================================

design <- model.matrix(~0 + group)
colnames(design) <- levels(group)

design


# ============================================================
# 4. Fit limma model
# ============================================================

fit <- lmFit(expr_log2, design)


# ============================================================
# 5. Define all three contrasts
# ============================================================

contrast.matrix <- makeContrasts(
  Clinical_vs_Healthy = Clinical - Healthy,
  Subclinical_vs_Healthy = Subclinical - Healthy,
  Clinical_vs_Subclinical = Clinical - Subclinical,
  levels = design
)

contrast.matrix


# ============================================================
# 6. Fit contrasts + empirical Bayes moderation
# ============================================================

fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)


# ============================================================
# 7. Extract results
# ============================================================

results_clinical_vs_healthy <- topTable(
  fit2,
  coef = "Clinical_vs_Healthy",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

results_subclinical_vs_healthy <- topTable(
  fit2,
  coef = "Subclinical_vs_Healthy",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)

results_clinical_vs_sub <- topTable(
  fit2,
  coef = "Clinical_vs_Subclinical",
  number = Inf,
  adjust.method = "BH",
  sort.by = "P"
)


# ============================================================
# 8. Check number of FDR-significant miRNAs
# ============================================================

sum(
  results_clinical_vs_healthy$adj.P.Val < 0.05,
  na.rm = TRUE
)

sum(
  results_subclinical_vs_healthy$adj.P.Val < 0.05,
  na.rm = TRUE
)

sum(
  results_clinical_vs_sub$adj.P.Val < 0.05,
  na.rm = TRUE
)


# ============================================================
# 9. Check candidate miRNAs using |log2FC| >= 1
# ============================================================

subset(
  results_clinical_vs_healthy,
  abs(logFC) >= 1
)

subset(
  results_subclinical_vs_healthy,
  abs(logFC) >= 1
)

subset(
  results_clinical_vs_sub,
  abs(logFC) >= 1
)


# ============================================================
# 10. Volcano plots
# ============================================================

EnhancedVolcano(
  results_clinical_vs_healthy,
  lab = rownames(results_clinical_vs_healthy),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Clinical Mastitis vs Healthy",
  subtitle = "Bovine milk EV miRNAs",
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"adjusted P-value"),
  pointSize = 2.0,
  labSize = 3.0,
  max.overlaps = 10
)


EnhancedVolcano(
  results_subclinical_vs_healthy,
  lab = rownames(results_subclinical_vs_healthy),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Subclinical Mastitis vs Healthy",
  subtitle = "Bovine milk EV miRNAs",
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"adjusted P-value"),
  pointSize = 2.0,
  labSize = 3.0,
  max.overlaps = 10
)


EnhancedVolcano(
  results_clinical_vs_sub,
  lab = rownames(results_clinical_vs_sub),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Clinical Mastitis vs Subclinical Mastitis",
  subtitle = "Bovine milk EV miRNAs",
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"adjusted P-value"),
  pointSize = 2.0,
  labSize = 3.0,
  max.overlaps = 10
)


# ============================================================
# 11. Combine all three volcano plots into one figure
# ============================================================

library(patchwork)

# -----------------------------
# Panel A
# -----------------------------

pA <- EnhancedVolcano(
  results_clinical_vs_healthy,
  lab = rownames(results_clinical_vs_healthy),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Clinical Mastitis vs Healthy",
  subtitle = "EnhancedVolcano",
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"adjusted P-value"),
  pointSize = 2.0,
  labSize = 3.0,
  max.overlaps = 10
)

# -----------------------------
# Panel B
# -----------------------------

pB <- EnhancedVolcano(
  results_subclinical_vs_healthy,
  lab = rownames(results_subclinical_vs_healthy),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Subclinical Mastitis vs Healthy",
  subtitle = "EnhancedVolcano",
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"adjusted P-value"),
  pointSize = 2.0,
  labSize = 3.0,
  max.overlaps = 10
)

# -----------------------------
# Panel C
# -----------------------------

pC <- EnhancedVolcano(
  results_clinical_vs_sub,
  lab = rownames(results_clinical_vs_sub),
  x = "logFC",
  y = "adj.P.Val",
  pCutoff = 0.05,
  FCcutoff = 1,
  title = "Clinical Mastitis vs Subclinical Mastitis",
  subtitle = "EnhancedVolcano",
  xlab = expression(Log[2]~"fold change"),
  ylab = expression(-Log[10]~"adjusted P-value"),
  pointSize = 2.0,
  labSize = 3.0,
  max.overlaps = 10
)

# ============================================================
# 12. Combine A, B and C horizontally
# ============================================================

combined_plot <- (pA | pB | pC) +
  plot_annotation(
    tag_levels = "A"
  )

# Display combined figure
combined_plot

ggsave(
  "Figure_3_Mastitis_EV_miRNA_Volcano.tiff",
  combined_plot,
  width = 18,
  height = 5.5,
  units = "in",
  dpi = 600,
  compression = "lzw"
)


#Create a combined ranking of all 126 miRNAs

# ============================================================
# 11. Create a combined differential-expression ranking
# ============================================================

# Make sure miRNA names are stored as a column
res_CH <- results_clinical_vs_healthy
res_SH <- results_subclinical_vs_healthy
res_CS <- results_clinical_vs_sub

res_CH$miRNA <- rownames(res_CH)
res_SH$miRNA <- rownames(res_SH)
res_CS$miRNA <- rownames(res_CS)


# Keep relevant columns
res_CH2 <- res_CH[, c("miRNA", "logFC", "P.Value", "adj.P.Val")]
res_SH2 <- res_SH[, c("miRNA", "logFC", "P.Value", "adj.P.Val")]
res_CS2 <- res_CS[, c("miRNA", "logFC", "P.Value", "adj.P.Val")]


# Rename columns according to comparison
colnames(res_CH2)[2:4] <- c(
  "logFC_CH",
  "P_CH",
  "FDR_CH"
)

colnames(res_SH2)[2:4] <- c(
  "logFC_SH",
  "P_SH",
  "FDR_SH"
)

colnames(res_CS2)[2:4] <- c(
  "logFC_CS",
  "P_CS",
  "FDR_CS"
)


# Merge all three comparisons
combined_DE <- merge(
  res_CH2,
  res_SH2,
  by = "miRNA"
)

combined_DE <- merge(
  combined_DE,
  res_CS2,
  by = "miRNA"
)


# Check
dim(combined_DE)
head(combined_DE)


colnames(combined_DE)

colnames(results_clinical_vs_healthy)
colnames(results_subclinical_vs_healthy)
colnames(results_clinical_vs_sub)

# ============================================================
# Recreate combined differential-expression table
# ============================================================

# Clinical vs Healthy
res_CH <- results_clinical_vs_healthy

res_CH$miRNA <- rownames(res_CH)

res_CH2 <- res_CH[, c(
  "miRNA",
  "logFC",
  "P.Value",
  "adj.P.Val"
)]

colnames(res_CH2) <- c(
  "miRNA",
  "logFC_CH",
  "P_CH",
  "FDR_CH"
)


# Subclinical vs Healthy
res_SH <- results_subclinical_vs_healthy

res_SH$miRNA <- rownames(res_SH)

res_SH2 <- res_SH[, c(
  "miRNA",
  "logFC",
  "P.Value",
  "adj.P.Val"
)]

colnames(res_SH2) <- c(
  "miRNA",
  "logFC_SH",
  "P_SH",
  "FDR_SH"
)


# Clinical vs Subclinical
res_CS <- results_clinical_vs_sub

res_CS$miRNA <- rownames(res_CS)

res_CS2 <- res_CS[, c(
  "miRNA",
  "logFC",
  "P.Value",
  "adj.P.Val"
)]

colnames(res_CS2) <- c(
  "miRNA",
  "logFC_CS",
  "P_CS",
  "FDR_CS"
)


# ============================================================
# Merge all three comparisons
# ============================================================

combined_DE <- merge(
  res_CH2,
  res_SH2,
  by = "miRNA"
)

combined_DE <- merge(
  combined_DE,
  res_CS2,
  by = "miRNA"
)


# Check column names
colnames(combined_DE)

# Check dimensions
dim(combined_DE)

# View first few rows
head(combined_DE)


# ============================================================
# Calculate minimum FDR across the three comparisons
# ============================================================

combined_DE$min_FDR <- apply(
  combined_DE[, c(
    "FDR_CH",
    "FDR_SH",
    "FDR_CS"
  )],
  1,
  min,
  na.rm = TRUE
)

head(
  combined_DE[, c(
    "miRNA",
    "FDR_CH",
    "FDR_SH",
    "FDR_CS",
    "min_FDR"
  )]
)

# ============================================================
# Maximum absolute log2 fold change
# ============================================================

combined_DE$max_abs_logFC <- apply(
  abs(
    combined_DE[, c(
      "logFC_CH",
      "logFC_SH",
      "logFC_CS"
    )]
  ),
  1,
  max,
  na.rm = TRUE
)

combined_DE$min_P <- apply(
  combined_DE[, c(
    "P_CH",
    "P_SH",
    "P_CS"
  )],
  1,
  min,
  na.rm = TRUE
)

# ============================================================
# Select top 20 miRNAs
# ============================================================

combined_DE <- combined_DE[
  order(
    combined_DE$min_FDR,
    -combined_DE$max_abs_logFC
  ),
]

top20_DE <- combined_DE[1:20, ]

top20_DE[, c(
  "miRNA",
  "min_FDR",
  "max_abs_logFC",
  "min_P"
)]


top20_DE[
  top20_DE$miRNA == "bta-miR-21-5p",
]

# ============================================================
# Extract top 20 from ORIGINAL expression matrix
# ============================================================

top20_miRNA_names <- top20_DE$miRNA

heatmap_data_new <- expr_log2[
  top20_miRNA_names,
  ,
  drop = FALSE
]

dim(heatmap_data_new)

# Row-wise Z-score
heatmap_z_new <- t(
  scale(
    t(heatmap_data_new)
  )
)

dim(heatmap_z_new)

top20_DE[, c(
  "miRNA",
  "logFC_CH",
  "FDR_CH",
  "logFC_SH",
  "FDR_SH",
  "logFC_CS",
  "FDR_CS",
  "min_FDR",
  "max_abs_logFC"
)]


top20_DE[top20_DE$miRNA == "bta-miR-21-5p", ]

# ============================================================
# Sample annotation
# ============================================================

annotation_col <- data.frame(
  Group = group
)

rownames(annotation_col) <- colnames(heatmap_z_new)

# Rename groups for the figure
annotation_col$Group <- factor(
  annotation_col$Group,
  levels = c(
    "Healthy",
    "Clinical",
    "Subclinical"
  ),
  labels = c(
    "H",
    "M",
    "SM"
  )
)

annotation_col

table(annotation_col$Group)

# ============================================================
# Annotation colors
# ============================================================

annotation_colors <- list(
  Group = c(
    H = "#00C853",
    M = "#FF8A80",
    SM = "#64B5F6"
  )
)

# ============================================================
# NEW TOP-20 miRNA HEATMAP
# ============================================================

library(pheatmap)

pheatmap(
  heatmap_z_new,
  
  # Hierarchical clustering
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  
  # Clustering parameters
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  
  # Sample annotation
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  
  # Labels
  labels_row = rownames(heatmap_z_new),
  labels_col = colnames(heatmap_z_new),
  
  # Z-score color scale
  color = colorRampPalette(
    c(
      "#2166AC",
      "#F7F7F7",
      "#B2182B"
    )
  )(100),
  
  breaks = seq(-3, 3, length.out = 101),
  
  # Figure appearance
  border_color = "grey80",
  
  fontsize = 10,
  fontsize_row = 9,
  fontsize_col = 9,
  
  angle_col = 45,
  
  # Do not display numerical values inside cells
  display_numbers = FALSE,
  
  # Already Z-score transformed
  scale = "none",
  
  # No title inside the figure
  main = NULL,
  
  # Show annotation legend
  annotation_legend = TRUE
)

range(heatmap_z_new, na.rm = TRUE)

class(heatmap_z_new)

dim(heatmap_z_new)

print(range(heatmap_z_new, na.rm = TRUE))

sum(is.na(heatmap_z_new))


library(pheatmap)

# ============================================================
# Annotation colors
# ============================================================

annotation_colors <- list(
  Group = c(
    H = "#00C853",
    M = "#FF8A80",
    SM = "#64B5F6"
  )
)

# ============================================================
# Publication-quality heatmap
# ============================================================

pheatmap(
  heatmap_z_new,
  
  # Hierarchical clustering
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  
  # Sample annotation
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  
  # Labels
  labels_row = rownames(heatmap_z_new),
  labels_col = colnames(heatmap_z_new),
  
  # Z-score color scale
  color = colorRampPalette(
    c(
      "#2166AC",
      "#F7F7F7",
      "#B2182B"
    )
  )(100),
  
  breaks = seq(-4, 4, length.out = 101),
  
  # Appearance
  border_color = "grey80",
  
  fontsize = 10,
  fontsize_row = 9,
  fontsize_col = 9,
  
  angle_col = 45,
  
  # No numbers inside cells
  display_numbers = FALSE,
  
  # Data already Z-score transformed
  scale = "none",
  
  # Annotation legend
  annotation_legend = TRUE
)


annotation_col <- data.frame(
  Status = group
)

rownames(annotation_col) <- colnames(heatmap_z_new)

annotation_col$Status <- factor(
  annotation_col$Status,
  levels = c(
    "Healthy",
    "Clinical",
    "Subclinical"
  ),
  labels = c(
    "H",
    "M",
    "SM"
  )
)

annotation_colors <- list(
  Status = c(
    H = "#00C853",
    M = "#FF8A80",
    SM = "#64B5F6"
  )
)

# Create sample annotation
annotation_col <- data.frame(
  Status = group
)

rownames(annotation_col) <- colnames(heatmap_z_new)

annotation_col$Status <- factor(
  annotation_col$Status,
  levels = c("Healthy", "Clinical", "Subclinical"),
  labels = c("H", "M", "SM")
)

# Annotation colors
annotation_colors <- list(
  Status = c(
    H = "#00C853",
    M = "#FF8A80",
    SM = "#64B5F6"
  )
)

# Check annotation
annotation_col

library(pheatmap)

pheatmap(
  heatmap_z_new,
  
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  
  labels_row = rownames(heatmap_z_new),
  labels_col = colnames(heatmap_z_new),
  
  color = colorRampPalette(
    c(
      "#2166AC",
      "#F7F7F7",
      "#B2182B"
    )
  )(100),
  
  breaks = seq(-4, 4, length.out = 101),
  
  border_color = "grey80",
  
  fontsize = 10,
  fontsize_row = 9,
  fontsize_col = 9,
  
  angle_col = 45,
  
  display_numbers = FALSE,
  
  scale = "none",
  
  annotation_legend = TRUE
)

pheatmap(
  heatmap_z_new,
  annotation_col = annotation_col,
  annotation_colors = annotation_colors
)


heatmap_plot <- pheatmap(
  heatmap_z_new,
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  labels_row = rownames(heatmap_z_new),
  labels_col = colnames(heatmap_z_new),
  color = colorRampPalette(
    c("#2166AC", "#F7F7F7", "#B2182B")
  )(100),
  breaks = seq(-4, 4, length.out = 101),
  border_color = "grey80",
  fontsize = 10,
  fontsize_row = 9,
  fontsize_col = 9,
  angle_col = 45,
  display_numbers = FALSE,
  scale = "none",
  annotation_legend = TRUE
)

print(heatmap_plot)

dev.cur()

dev.off()

dev.list()

dev.off()

dev.list()

library(pheatmap)

pheatmap(
  heatmap_z_new,
  
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  
  labels_row = rownames(heatmap_z_new),
  labels_col = colnames(heatmap_z_new),
  
  color = colorRampPalette(
    c("#2166AC", "#F7F7F7", "#B2182B")
  )(100),
  
  breaks = seq(-4, 4, length.out = 101),
  
  border_color = "grey80",
  
  fontsize = 10,
  fontsize_row = 9,
  fontsize_col = 9,
  
  angle_col = 45,
  
  display_numbers = FALSE,
  
  scale = "none",
  
  annotation_legend = TRUE
)

# ============================================================
# SAVE TOP-20 miRNA HEATMAP AS HIGH-QUALITY TIFF
# ============================================================

library(pheatmap)

tiff(
  filename = "GSE201588_Top20_miRNA_Heatmap.tiff",
  width = 10,
  height = 8,
  units = "in",
  res = 600,
  compression = "lzw"
)

pheatmap(
  heatmap_z_new,
  
  # Hierarchical clustering
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  
  clustering_distance_rows = "euclidean",
  clustering_distance_cols = "euclidean",
  clustering_method = "complete",
  
  # Sample annotation
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  
  # Labels
  labels_row = rownames(heatmap_z_new),
  labels_col = colnames(heatmap_z_new),
  
  # Z-score color scale
  color = colorRampPalette(
    c("#2166AC", "#F7F7F7", "#B2182B")
  )(100),
  
  breaks = seq(-4, 4, length.out = 101),
  
  # Appearance
  border_color = "grey80",
  
  fontsize = 10,
  fontsize_row = 9,
  fontsize_col = 9,
  
  angle_col = 45,
  
  # No numbers inside cells
  display_numbers = FALSE,
  
  # Already Z-score transformed
  scale = "none",
  
  # Annotation legend
  annotation_legend = TRUE
)

dev.off()


rownames(heatmap_z_new)


#Prioritization of discovery-stage candidate miRNAs

# ============================================================
# GSE201588 TPM abundance for candidate miRNAs
# ============================================================

# Mean TPM across all 21 GSE201588 samples
gse_tpm_mean <- rowMeans(expr_mat, na.rm = TRUE)

# Convert to data frame
gse_tpm_df <- data.frame(
  bta_miRNA = names(gse_tpm_mean),
  GSE201588_TPM = as.numeric(gse_tpm_mean),
  stringsAsFactors = FALSE
)

# Check
head(gse_tpm_df)

# Check candidate miRNAs
gse_tpm_df[
  gse_tpm_df$bta_miRNA %in% c(
    "bta-miR-21-5p",
    "bta-miR-30a-5p",
    "bta-let-7a-5p",
    "bta-miR-1246",
    "bta-miR-99b",
    "bta-miR-19a",
    "bta-let-7b",
    "bta-miR-2484",
    "bta-miR-23a",
    "bta-miR-574"
  ),
]


# ============================================================
# Bovine-to-human miRNA mapping
# ============================================================

miRNA_mapping <- data.frame(
  
  hsa_miRNA = c(
    "hsa-miR-21-5p",
    "hsa-miR-30a-5p",
    "hsa-miR-30e-5p",
    "hsa-miR-92a",
    "hsa-miR-186",
    "hsa-miR-24-3p",
    "hsa-miR-27a-3p",
    "hsa-miR-26a",
    "hsa-miR-30a",
    "hsa-miR-30e",
    "hsa-miR-27b",
    "hsa-miR-574",
    "hsa-miR-7",
    "hsa-let-7b",
    "hsa-let-7i"
  ),
  
  bta_miRNA = c(
    "bta-miR-21-5p",
    "bta-miR-30a-5p",
    "bta-miR-30e-5p",
    "bta-miR-92a",
    "bta-miR-186",
    "bta-miR-24-3p",
    "bta-miR-27a-3p",
    "bta-miR-26a",
    "bta-miR-30a",
    "bta-miR-30e",
    "bta-miR-27b",
    "bta-miR-574",
    "bta-miR-7",
    "bta-let-7b",
    "bta-let-7i"
  ),
  
  stringsAsFactors = FALSE
)

miRNA_mapping


# Check expression matrix
dim(expr_mat)

# Check miRNA names
head(rownames(expr_mat))

# Check sample names
colnames(expr_mat)


# Identify which mapped bovine miRNAs are present in GSE201588
miRNA_mapping$bta_miRNA %in% rownames(expr_mat)

gse_tpm <- expr_mat[
  rownames(expr_mat) %in% miRNA_mapping$bta_miRNA,
  ,
  drop = FALSE
]

gse_tpm

gse_tpm_mean <- rowMeans(
  gse_tpm,
  na.rm = TRUE
)

gse_tpm_mean

gse_tpm_df <- data.frame(
  bta_miRNA = names(gse_tpm_mean),
  GSE201588_TPM = as.numeric(gse_tpm_mean),
  stringsAsFactors = FALSE
)

gse_tpm_df

miRNA_mapping_TPM <- merge(
  miRNA_mapping,
  gse_tpm_df,
  by = "bta_miRNA",
  all.x = TRUE
)

miRNA_mapping_TPM

miRNA_mapping_TPM[
  is.na(miRNA_mapping_TPM$GSE201588_TPM),
]


miRNA_mapping_TPM

summary(miRNA_mapping_TPM$GSE201588_TPM)

miRNA_mapping_TPM[
  miRNA_mapping_TPM$bta_miRNA == "bta-miR-21-5p",
]

miRNA_mapping_TPM[
  order(
    miRNA_mapping_TPM$GSE201588_TPM,
    decreasing = TRUE
  ),
]

miRNA_mapping_TPM$Bubble_TPM <- log2(
  miRNA_mapping_TPM$GSE201588_TPM + 1
)

miRNA_mapping_TPM[
  order(
    miRNA_mapping_TPM$Bubble_TPM,
    decreasing = TRUE
  ),
]

ls()

# Candidate score data
class(Candidate_score)
dim(Candidate_score)
colnames(Candidate_score)
head(Candidate_score)


# HR+ breast cancer target-count data
class(target_counts)
dim(target_counts)
colnames(target_counts)
head(target_counts)


# GSE201588 TPM data
class(gse_tpm_df)
dim(gse_tpm_df)
colnames(gse_tpm_df)
head(gse_tpm_df)

miRNA_mapping

gse_tpm_df

miRNA_mapping_TPM

miRNA_mapping_TPM[
  order(
    miRNA_mapping_TPM$GSE201588_TPM,
    decreasing = TRUE
  ),
]

Candidate_score

Candidate_score[
  order(Candidate_score$Candidate_Score, decreasing = TRUE),
]

target_counts

target_counts[
  order(target_counts$Target_Count, decreasing = TRUE),
]

class(target_counts)

dim(target_counts)

colnames(target_counts)

str(target_counts)

head(target_counts)


colnames(target_counts)

target_counts

names(target_counts)

dput(head(target_counts, 10))

colnames(Candidate_score)
head(Candidate_score)
str(Candidate_score)


colnames(gse_tpm_df)
gse_tpm_df


colnames(miRNA_mapping_TPM)
miRNA_mapping_TPM

target_counts <- target_counts[
  order(target_counts$HRBC_Targets, decreasing = TRUE),
]

target_counts

colnames(Candidate_score)
head(Candidate_score)
str(Candidate_score)

colnames(gse_tpm_df)
gse_tpm_df

colnames(miRNA_mapping_TPM)
miRNA_mapping_TPM

## ============================================================
# FINAL FIGURE 5 DATASET
# Candidate score + HR+BC targets + GSE201588 TPM
# ============================================================

# Start with the existing Candidate_score table
figure5_data <- Candidate_score

# Keep only candidates that have a bovine-to-human mapping
figure5_data <- figure5_data[
  figure5_data$mature_mirna_id %in% miRNA_mapping_TPM$hsa_miRNA,
]

# Add bovine miRNA identifier
figure5_data$bta_miRNA <- miRNA_mapping_TPM$bta_miRNA[
  match(
    figure5_data$mature_mirna_id,
    miRNA_mapping_TPM$hsa_miRNA
  )
]

# Add GSE201588 TPM
figure5_data$GSE201588_TPM <- miRNA_mapping_TPM$GSE201588_TPM[
  match(
    figure5_data$mature_mirna_id,
    miRNA_mapping_TPM$hsa_miRNA
  )
]

# Log-transformed TPM for visualization
figure5_data$Bubble_TPM <- log2(
  figure5_data$GSE201588_TPM + 1
)

# Check
figure5_data


colnames(figure5_data)

figure5_data[
  ,
  c(
    "bta_miRNA",
    "mature_mirna_id",
    "Candidate_Score",
    "HRBC_Targets",
    "Overall_Validation",
    "GSE201588_TPM",
    "Bubble_TPM"
  )
]

figure5_data[
  is.na(figure5_data$GSE201588_TPM),
  c(
    "bta_miRNA",
    "mature_mirna_id",
    "Candidate_Score",
    "HRBC_Targets"
  )
]


# ============================================================
# FINAL FIGURE 5 DATA
# ============================================================

figure5_final <- figure5_data[
  ,
  c(
    "bta_miRNA",
    "mature_mirna_id",
    "Candidate_Score",
    "HRBC_Targets",
    "Overall_Validation",
    "GSE201588_TPM",
    "Bubble_TPM"
  )
]

# Rename columns for easier plotting
colnames(figure5_final) <- c(
  "Bovine_miRNA",
  "Human_miRNA",
  "Candidate_Score",
  "HRBC_Targets",
  "Validation",
  "GSE201588_TPM",
  "Bubble_TPM"
)

# Sort by candidate score
figure5_final <- figure5_final[
  order(
    figure5_final$Candidate_Score,
    decreasing = TRUE
  ),
]

# Check final dataset
figure5_final

dim(figure5_final)

summary(figure5_final)

any(is.na(figure5_final))


figure5_final[
  ,
  c(
    "Bovine_miRNA",
    "Human_miRNA",
    "Candidate_Score",
    "HRBC_Targets",
    "GSE201588_TPM",
    "Validation"
  )
]

figure5_final


## ============================================================
# Clean dataset for Figure 5
# ============================================================

figure5_plot <- figure5_final

# Make validation a factor in a sensible order
figure5_plot$Validation <- factor(
  figure5_plot$Validation,
  levels = c(
    "Strong",
    "Partial",
    "Not Validated"
  )
)

# Create a readable label
figure5_plot$Label <- figure5_plot$Bovine_miRNA

# Check
figure5_plot

figure5_plot$Bubble_TPM

library(ggplot2)

# Order candidates by candidate score
figure5_plot$Bovine_miRNA <- factor(
  figure5_plot$Bovine_miRNA,
  levels = rev(figure5_plot$Bovine_miRNA)
)

p5A <- ggplot(
  figure5_plot,
  aes(
    x = Candidate_Score,
    y = Bovine_miRNA
  )
) +
  geom_point(
    size = 4
  ) +
  geom_text(
    aes(
      label = sprintf("%.2f", Candidate_Score)
    ),
    hjust = -0.3,
    size = 3.5
  ) +
  labs(
    x = "Integrated candidate score",
    y = NULL
  ) +
  theme_classic(base_size = 12) +
  theme(
    axis.text.y = element_text(
      size = 10
    ),
    axis.text.x = element_text(
      size = 10
    ),
    axis.title.x = element_text(
      size = 11
    ),
    plot.margin = margin(
      5.5, 25, 5.5, 5.5
    )
  ) +
  coord_cartesian(
    xlim = c(
      0,
      max(figure5_plot$Candidate_Score) + 0.7
    ),
    clip = "off"
  )

p5A


p5B <- ggplot(
  figure5_plot,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score
  )
) +
  geom_point(
    aes(
      size = Bubble_TPM,
      shape = Validation
    ),
    alpha = 0.85
  ) +
  geom_text(
    aes(
      label = Bovine_miRNA
    ),
    vjust = -1.0,
    size = 3.2
  ) +
  scale_size_continuous(
    name = expression(
      log[2]~"(GSE201588 TPM + 1)"
    ),
    range = c(
      3,
      11
    )
  ) +
  scale_shape_manual(
    values = c(
      "Strong" = 16,
      "Partial" = 17,
      "Not Validated" = 15
    ),
    name = "Validation"
  ) +
  labs(
    x = "HR+ breast cancer-associated target genes",
    y = "Integrated candidate score"
  ) +
  theme_classic(base_size = 12) +
  theme(
    axis.text = element_text(
      size = 10
    ),
    axis.title = element_text(
      size = 11
    ),
    legend.title = element_text(
      size = 10
    ),
    legend.text = element_text(
      size = 9
    )
  )

p5B

library(ggrepel)

p5B <- ggplot(
  figure5_plot,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score
  )
) +
  geom_point(
    aes(
      size = Bubble_TPM,
      shape = Validation
    ),
    alpha = 0.85
  ) +
  geom_text_repel(
    aes(
      label = Bovine_miRNA
    ),
    size = 3.2,
    max.overlaps = Inf
  ) +
  scale_size_continuous(
    name = expression(
      log[2]~"(GSE201588 TPM + 1)"
    ),
    range = c(3, 11)
  ) +
  scale_shape_manual(
    values = c(
      "Strong" = 16,
      "Partial" = 17,
      "Not Validated" = 15
    ),
    name = "Validation"
  ) +
  labs(
    x = "HR+ breast cancer-associated target genes",
    y = "Integrated candidate score"
  ) +
  theme_classic(base_size = 12)

p5B

library(ggplot2)
library(ggrepel)

# Make validation a factor in the desired order
figure5_final$Validation <- factor(
  figure5_final$Validation,
  levels = c("Strong", "Partial", "Not Validated")
)

# Figure 5B
p5B <- ggplot(
  figure5_final,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score
  )
) +
  
  # Points
  geom_point(
    aes(
      size = Bubble_TPM,
      shape = Validation
    ),
    color = "black",
    fill = "grey25",
    alpha = 0.9,
    stroke = 0.8
  ) +
  
  # Non-overlapping labels
  geom_text_repel(
    aes(
      label = Bovine_miRNA
    ),
    size = 3.5,
    
    # Important for crowded labels
    box.padding = 0.6,
    point.padding = 0.35,
    force = 2,
    force_pull = 0.5,
    
    # Allow labels to move in both directions
    direction = "both",
    
    # Keep all labels
    max.overlaps = Inf,
    
    # Draw connecting lines
    min.segment.length = 0,
    segment.color = "grey40",
    segment.size = 0.3,
    
    # Avoid labels being cut off
    xlim = c(-7, 47),
    ylim = c(0.4, 4.15)
  ) +
  
  # Bubble-size scale
  scale_size_continuous(
    name = expression(log[2]~"(GSE201588 TPM + 1)"),
    range = c(4, 12),
    breaks = c(7, 8, 9, 10, 11)
  ) +
  
  # Validation shapes
  scale_shape_manual(
    name = "Validation",
    values = c(
      "Strong" = 16,
      "Partial" = 17,
      "Not Validated" = 15
    )
  ) +
  
  # X-axis
  scale_x_continuous(
    name = "HR+ breast cancer-associated target genes",
    breaks = c(0, 10, 20, 30, 40),
    limits = c(-7, 47),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  
  # Y-axis
  scale_y_continuous(
    name = "Integrated candidate score",
    limits = c(0.4, 4.15),
    breaks = c(1, 2, 3, 4),
    expand = expansion(mult = c(0.01, 0.02))
  ) +
  
  theme_classic(base_size = 13) +
  
  theme(
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12),
    
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11),
    
    legend.position = "right",
    
    plot.margin = margin(
      10, 20, 10, 20
    )
  )

p5B





library(ggplot2)

# ---------------------------------------------------------
# Create manually positioned labels
# ---------------------------------------------------------

label_pos <- data.frame(
  
  Bovine_miRNA = c(
    "bta-miR-92a",
    "bta-miR-186",
    "bta-miR-30e-5p",
    "bta-miR-30a-5p",
    "bta-miR-21-5p",
    "bta-miR-26a",
    "bta-miR-27b",
    "bta-miR-574",
    "bta-miR-7",
    "bta-miR-27a-3p",
    "bta-miR-24-3p",
    "bta-let-7b",
    "bta-let-7i"
  ),
  
  x_label = c(
    -5.5,   # miR-92a
    1.5,   # miR-186
    13.0,   # miR-30e-5p
    35.0,   # miR-30a-5p
    35.0,   # miR-21-5p
    -5.5,   # miR-26a
    6.0,   # miR-27b
    -5.5,   # miR-574
    4.0,   # miR-7
    41.5,   # miR-27a-3p
    27.0,   # miR-24-3p
    -5.5,   # let-7b
    1.5    # let-7i
  ),
  
  y_label = c(
    3.15,   # miR-92a
    2.65,   # miR-186
    3.15,   # miR-30e-5p
    3.75,   # miR-30a-5p
    3.05,   # miR-21-5p
    2.20,   # miR-26a
    1.80,   # miR-27b
    1.70,   # miR-574
    1.25,   # miR-7
    1.55,   # miR-27a-3p
    1.15,   # miR-24-3p
    1.20,   # let-7b
    0.65    # let-7i
  ),
  
  stringsAsFactors = FALSE
)


# ---------------------------------------------------------
# Add actual point coordinates
# ---------------------------------------------------------

label_pos <- merge(
  label_pos,
  figure5_final[, c(
    "Bovine_miRNA",
    "HRBC_Targets",
    "Candidate_Score"
  )],
  by = "Bovine_miRNA"
)


# ---------------------------------------------------------
# Create label connector information
# ---------------------------------------------------------

label_pos$x_start <- label_pos$x_label
label_pos$y_start <- label_pos$y_label

label_pos$x_end <- label_pos$HRBC_Targets
label_pos$y_end <- label_pos$Candidate_Score


# ---------------------------------------------------------
# Figure 5B
# ---------------------------------------------------------

p5B <- ggplot(
  figure5_final,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score
  )
) +
  
  # -------------------------------------------------------
# Bubble points
# -------------------------------------------------------
geom_point(
  aes(
    size = Bubble_TPM,
    shape = Validation
  ),
  color = "black",
  fill = "grey25",
  alpha = 0.9,
  stroke = 0.8
) +
  
  # -------------------------------------------------------
# Connector lines
# -------------------------------------------------------
geom_segment(
  data = label_pos,
  aes(
    x = x_start,
    y = y_start,
    xend = x_end,
    yend = y_end
  ),
  inherit.aes = FALSE,
  color = "grey50",
  linewidth = 0.35
) +
  
  # -------------------------------------------------------
# Manually positioned labels
# -------------------------------------------------------
geom_text(
  data = label_pos,
  aes(
    x = x_label,
    y = y_label,
    label = Bovine_miRNA,
    hjust = ifelse(
      x_label < HRBC_Targets,
      1,
      0
    )
  ),
  inherit.aes = FALSE,
  size = 3.5
) +
  
  # -------------------------------------------------------
# Bubble size
# -------------------------------------------------------
scale_size_continuous(
  name = expression(
    log[2]~"(GSE201588 TPM + 1)"
  ),
  range = c(4, 12),
  breaks = c(7, 8, 9, 10, 11)
) +
  
  # -------------------------------------------------------
# Validation
# -------------------------------------------------------
scale_shape_manual(
  name = "Validation",
  values = c(
    "Strong" = 16,
    "Partial" = 17,
    "Not Validated" = 15
  )
) +
  
  # -------------------------------------------------------
# X-axis
# -------------------------------------------------------
scale_x_continuous(
  name = "HR+ breast cancer-associated target genes",
  breaks = c(0, 10, 20, 30, 40),
  limits = c(-7, 47),
  expand = expansion(mult = c(0.01, 0.02))
) +
  
  # -------------------------------------------------------
# Y-axis
# -------------------------------------------------------
scale_y_continuous(
  name = "Integrated candidate score",
  breaks = c(1, 2, 3, 4),
  limits = c(0.4, 4.2),
  expand = expansion(mult = c(0.01, 0.02))
) +
  
  # -------------------------------------------------------
# Theme
# -------------------------------------------------------
theme_classic(
  base_size = 13
) +
  
  theme(
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12),
    
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11),
    
    legend.position = "right",
    
    plot.margin = margin(
      10, 20, 10, 20
    )
  )

p5B


library(ggplot2)

# ---------------------------------------------------------
# MANUAL LABEL POSITIONS FOR FIGURE 5B
# ---------------------------------------------------------

label_pos <- data.frame(
  
  Bovine_miRNA = c(
    "bta-miR-92a",
    "bta-miR-186",
    "bta-miR-30e-5p",
    "bta-miR-30a-5p",
    "bta-miR-21-5p",
    "bta-miR-26a",
    "bta-miR-27b",
    "bta-miR-574",
    "bta-miR-7",
    "bta-miR-24-3p",
    "bta-miR-27a-3p",
    "bta-let-7b",
    "bta-let-7i"
  ),
  
  # X-position of label
  x_label = c(
    0.8,
    3.0,
    15.0,
    28.0,
    35.0,
    2.5,
    3.5,
    3.5,
    3.5,
    25.0,
    35.0,
    3.0,
    3.0
  ),
  
  # Y-position of label
  y_label = c(
    3.15,
    2.65,
    3.15,
    3.75,
    3.05,
    2.15,
    1.85,
    1.60,
    1.40,
    1.20,
    1.55,
    0.95,
    0.58
  ),
  
  stringsAsFactors = FALSE
)

label_pos <- merge(
  label_pos,
  figure5_final[, c(
    "Bovine_miRNA",
    "HRBC_Targets",
    "Candidate_Score"
  )],
  by = "Bovine_miRNA"
)

# Check the result
label_pos


# ---------------------------------------------------------
# FIGURE 5B
# ---------------------------------------------------------

p5B <- ggplot(
  figure5_final,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score
  )
) +
  
  # -------------------------------------------------------
# BUBBLE POINTS
# -------------------------------------------------------
geom_point(
  aes(
    size = Bubble_TPM,
    shape = Validation
  ),
  color = "black",
  fill = "grey20",
  alpha = 0.90,
  stroke = 0.8
) +
  
  # -------------------------------------------------------
# LEADER LINES
# -------------------------------------------------------
geom_segment(
  data = label_pos,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score,
    xend = x_label,
    yend = y_label
  ),
  inherit.aes = FALSE,
  linewidth = 0.30,
  color = "grey50"
) +
  
  # -------------------------------------------------------
# MIRNA LABELS
# -------------------------------------------------------
geom_text(
  data = label_pos,
  aes(
    x = x_label,
    y = y_label,
    label = Bovine_miRNA
  ),
  inherit.aes = FALSE,
  size = 3.5,
  color = "black"
) +
  
  # -------------------------------------------------------
# BUBBLE SIZE = GSE201588 TPM
# -------------------------------------------------------
scale_size_continuous(
  name = expression(
    log[2]~"(GSE201588 TPM + 1)"
  ),
  breaks = c(7, 8, 9, 10, 11),
  range = c(4, 12)
) +
  
  # -------------------------------------------------------
# VALIDATION SHAPE
# -------------------------------------------------------
scale_shape_manual(
  name = "Validation",
  values = c(
    "Strong" = 16,
    "Partial" = 17,
    "Not Validated" = 15
  )
) +
  
  # -------------------------------------------------------
# X-AXIS
# -------------------------------------------------------
scale_x_continuous(
  name = "HR+ breast cancer-associated target genes",
  breaks = c(0, 10, 20, 30, 40, 50),
  limits = c(-4, 50),
  expand = expansion(mult = c(0.01, 0.01))
) +
  
  # -------------------------------------------------------
# Y-AXIS
# -------------------------------------------------------
scale_y_continuous(
  name = "Integrated candidate score",
  breaks = c(1, 2, 3, 4),
  limits = c(0.4, 4.2),
  expand = expansion(mult = c(0.01, 0.02))
) +
  
  # -------------------------------------------------------
# PUBLICATION-STYLE THEME
# -------------------------------------------------------
theme_classic(
  base_size = 13
) +
  
  theme(
    axis.title.x = element_text(
      size = 14,
      margin = margin(t = 10)
    ),
    
    axis.title.y = element_text(
      size = 14,
      margin = margin(r = 10)
    ),
    
    axis.text = element_text(
      size = 12,
      color = "black"
    ),
    
    legend.title = element_text(
      size = 12
    ),
    
    legend.text = element_text(
      size = 11
    ),
    
    legend.position = "right",
    
    legend.key = element_blank(),
    
    plot.margin = margin(
      t = 10,
      r = 20,
      b = 10,
      l = 10
    )
  )

p5B


tiff(
  filename = "Figure_5B_HRBC_miRNA_prioritization.tiff",
  width = 12,
  height = 7,
  units = "in",
  res = 600,
  compression = "lzw"
)

print(p5B)

dev.off()


library(patchwork)

Figure5 <- p5A / p5B +
  plot_layout(
    ncol = 1,
    heights = c(1, 1.25)
  )


Figure5 <- (p5A / p5B) +
  plot_annotation(
    tag_levels = "A"
  ) &
  theme(
    plot.tag = element_text(
      size = 16,
      face = "bold"
    )
  )

ggsave(
  "Figure_5.tiff",
  Figure5,
  width = 14,
  height = 12,
  units = "in",
  dpi = 600,
  compression = "lzw"
)







save.image(".RData")
savehistory("My_R_History.Rhistory")

