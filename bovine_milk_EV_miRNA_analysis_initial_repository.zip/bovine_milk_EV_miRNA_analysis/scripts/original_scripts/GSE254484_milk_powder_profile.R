#script to visualisze gene expression data (GSE254484) France commericialized milk powder
# script "D:/SANCHIT ARORA/IIT BHU/Sanchit_PhD/Sanchit_PhD research work/In silico studies/Scripts"

#Step 1. Load required packages
library(dplyr)
library(ggplot2)
library(pheatmap)
library(corrplot)
library(tidyr)
library(ggrepel)

#Step 2. Read GSE254484 file

install.packages("readxl")
library(readxl)
GSE254484_dataset <- read_excel("GSE254484_dataset.xlsx")
View(GSE254484_dataset)

#Step 3. Check the dataset

dim(GSE254484_dataset)

colnames(GSE254484_dataset)

head(GSE254484_dataset)

str(GSE254484_dataset)

#Step 4. Rename columns and convert counts to numeric

GSE254484_dataset <- GSE254484_dataset %>%
  rename(
    miRNA = idx,
    Powder_TPM = counts
  )

# Convert Powder_TPM to numeric

GSE254484_dataset$Powder_TPM <-
  as.numeric(GSE254484_dataset$Powder_TPM)

# Check

str(GSE254484_dataset)

summary(GSE254484_dataset$Powder_TPM)

#Step 5. Keep only known miRNAs
GSE254484_known <- GSE254484_dataset %>%
  filter(!grepl("novel", miRNA))

dim(GSE254484_known)

#Step 6. Rank miRNAs
Powder_rank <- GSE254484_known %>%
  arrange(desc(Powder_TPM)) %>%
  mutate(
    Powder_Rank = row_number()
  )

head(Powder_rank)

#Step 7. Keep required columns
Powder_rank <- Powder_rank %>%
  select(
    miRNA,
    Powder_TPM,
    Powder_Rank
  )

#Step 8. Merge with Conservation Table
Validation_Table <-
  Conservation_Table %>%
  left_join(
    Powder_rank,
    by = "miRNA"
  )

dim(Validation_Table)

head(Validation_Table)

#Step 9. Presence / Absence analysis
Validation_Table <- Validation_Table %>%
  mutate(
    
    Presence = ifelse(
      is.na(Powder_TPM),
      "Absent",
      "Present"
    )
    
  )

table(Validation_Table$Presence)

#Step 10. Percentage retained
prop.table(
  table(Validation_Table$Presence)
)*100

#Step 11. Rank Difference
Validation_Table <- Validation_Table %>%
  mutate(
    
    Rank_Difference =
      abs(
        Mean_Rank -
          Powder_Rank
      )
    
  )

#Step 12. Expression Fold Change
Validation_Table <- Validation_Table %>%
  mutate(
    
    log2FC =
      log2(
        (Powder_TPM + 1) /
          (Mean_TPM + 1)
      )
    
  )

#Step 13. Processing Stability
Validation_Table <- Validation_Table %>%
  mutate(
    
    Processing_Stability = case_when(
      
      is.na(Powder_Rank)
      ~ "Not detected",
      
      Powder_Rank <=20
      ~ "Highly retained",
      
      Powder_Rank <=50
      ~ "Retained",
      
      TRUE
      ~ "Low retention"
      
    )
    
  )

#Step 14. Dataset for comparison
Validation_Data <-
  Validation_Table %>%
  filter(
    !is.na(Powder_Rank)
  )

#Step 15. Spearman Rank Correlation
cor.test(
  
  Validation_Data$Mean_Rank,
  
  Validation_Data$Powder_Rank,
  
  method="spearman"
)

#Step 16. Pearson Expression Correlation
cor.test(
  
  Validation_Data$Mean_TPM,
  
  Validation_Data$Powder_TPM,
  
  method="pearson"
)

#Step 17. Scatter Plot (Ranks)
ggplot(
  
  Validation_Data,
  
  aes(
    Mean_Rank,
    Powder_Rank
  )
  
)+
  
  geom_point(
    size=3,
    color="blue"
  )+
  
  geom_smooth(
    method="lm",
    se=FALSE,
    color="red"
  )+
  
  scale_x_reverse()+
  scale_y_reverse()+
  
  theme_bw()+
  
  labs(
    
    x="Core Healthy Mean Rank",
    
    y="Powder Rank"
    
  )

#Step 18. Scatter Plot (Expression)
ggplot(
  
  Validation_Data,
  
  aes(
    Mean_TPM,
    Powder_TPM
  )
  
)+
  
  geom_point(
    size=3,
    color="darkgreen"
  )+
  
  geom_smooth(
    method="lm",
    se=FALSE,
    color="red"
  )+
  
  scale_x_log10()+
  scale_y_log10()+
  
  theme_bw()+
  
  labs(
    
    x="Core Healthy Mean TPM",
    
    y="Powder TPM"
    
  )

#Step 19. Heatmap
Heatmap_Data <-
  Validation_Data %>%
  select(
    
    Mean_China,
    
    Mean_Switzerland,
    
    Mean_France,
    
    Powder_TPM
    
  )

# Rename columns with GSE IDs

colnames(Heatmap_Data) <- c(
  "GSE201588",
  "GSE149856",
  "GSE227559",
  "GSE254484"
)

rownames(Heatmap_Data) <-
  Validation_Data$miRNA

Heatmap_Data <-
  log2(Heatmap_Data + 1)

tiff(
  filename = "Heatmap_GSE254484.tiff",
  width = 8,
  height = 6,
  units = "in",
  res = 300,
  compression = "lzw"
)

pheatmap(
  
  Heatmap_Data,
  
  cluster_rows = TRUE,
  
  cluster_cols = FALSE,
  
  fontsize_row = 8,
  
  fontsize_col = 12,
  
  main = "Core Healthy Bovine Milk EV miRNAs Across GEO Datasets"
  
)

dev.off()

#save image
tiff(
  filename = "Heatmap_GSE254484.tiff",
  width = 8,
  height = 6,
  units = "in",
  res = 300,
  compression = "lzw"
)

pheatmap(
  Heatmap_Data,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  fontsize_row = 8,
  main = "Healthy Raw Milk vs Commercial Milk Powder"
)

dev.off()

#Step 20. Rank movement plot
library(ggplot2)

tiff(
  filename = "Rank_Movement_Plot.tiff",
  width = 8,
  height = 6,
  units = "in",
  res = 300,
  compression = "lzw"
)

ggplot(Validation_Data) +
  
  geom_segment(
    aes(
      x = Mean_Rank,
      xend = Powder_Rank,
      y = reorder(miRNA, Mean_Rank),
      yend = reorder(miRNA, Mean_Rank)
    ),
    colour = "grey70",
    linewidth = 0.8
  ) +
  
  geom_point(
    aes(
      Mean_Rank,
      reorder(miRNA, Mean_Rank)
    ),
    colour = "blue",
    size = 3
  ) +
  
  geom_point(
    aes(
      Powder_Rank,
      reorder(miRNA, Mean_Rank)
    ),
    colour = "red",
    size = 3
  ) +
  
  scale_x_reverse() +
  
  labs(
    title = "Rank Movement of Conserved miRNAs",
    x = "Rank",
    y = NULL
  ) +
  
  theme_bw() +
  
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 12, face = "bold"),
    axis.text = element_text(size = 9),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )

dev.off()

#Step 22. Bubble Plot
tiff(
  filename = "Bubble_Plot_GSE254484.tiff",
  width = 8,
  height = 6,
  units = "in",
  res = 300,
  compression = "lzw"
)

ggplot(
  Validation_Data,
  aes(
    x = Mean_Rank,
    y = Powder_Rank,
    size = Powder_TPM,
    colour = Powder_TPM
  )
) +
  
  geom_point(alpha = 0.8) +
  
  scale_x_reverse() +
  scale_y_reverse() +
  
  scale_size(range = c(3, 12)) +
  
  labs(
    title = "Bubble Plot of Conserved miRNAs",
    x = "Mean Rank (Discovery Datasets)",
    y = "Rank (GSE254484)",
    size = "Expression",
    colour = "Expression"
  ) +
  
  theme_bw() +
  
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 12, face = "bold"),
    axis.text = element_text(size = 10),
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )

dev.off()

#Step 23. Top Retained miRNAs
Top_retained <-
  Validation_Data %>%
  arrange(Powder_Rank) %>%
  slice(1:20)

Top_retained

write.csv(
  Top_retained,
  "Top20_Retained_miRNAs.csv",
  row.names = FALSE
)

#Figure for top retained 
ggplot(
  Top_retained,
  aes(
    reorder(miRNA, Powder_TPM),
    Powder_TPM
  )
)+
  
  geom_col(fill = "steelblue")+
  
  coord_flip()+
  
  theme_bw()+
  
  labs(
    title = "Top 20 Retained Conserved miRNAs",
    x = "",
    y = "Expression"
  )

#Step 24. Save Complete Validation Results
write.csv(
  Validation_Table,
  "GSE254484_Validation_Table.csv",
  row.names = FALSE
)

write.csv(
  Validation_Data,
  "GSE254484_Validated_miRNAs.csv",
  row.names = FALSE
)

write.csv(
  Top_retained,
  "Top20_Retained_miRNAs.csv",
  row.names = FALSE
)


#REVISED PLOTS

#STEP 1 — Check GSE254484 structure
library(dplyr)
library(tidyr)
library(ggplot2)
library(pheatmap)
library(gridExtra)

# ---------------------------------------------------------
# Check GSE254484
# ---------------------------------------------------------

class(GSE254484_dataset)
dim(GSE254484_dataset)
names(GSE254484_dataset)

head(GSE254484_dataset)


cross_13

sum(
  cross_13 %in% GSE254484_dataset$miRNA
)

GSE254484_dataset %>%
  filter(miRNA %in% cross_13)



#STEP 2 — Extract the 13 miRNAs from GSE254484
# ---------------------------------------------------------
# Extract 13 prioritised miRNAs from GSE254484
# ---------------------------------------------------------

GSE254484_13 <- GSE254484_dataset %>%
  filter(miRNA %in% cross_13)

# Check
nrow(GSE254484_13)

GSE254484_13


#STEP 3 — Identify powder sample columns
str(GSE254484_13)

numeric_cols <- names(
  GSE254484_13[
    sapply(GSE254484_13, is.numeric)
  ]
)

numeric_cols

# ---------------------------------------------------------
# Mean abundance in commercial milk powder
# ---------------------------------------------------------

GSE254484_13_mean <- GSE254484_13 %>%
  rowwise() %>%
  mutate(
    GSE254484_Mean = mean(
      c_across(all_of(numeric_cols)),
      na.rm = TRUE
    )
  ) %>%
  ungroup() %>%
  select(
    miRNA,
    GSE254484_Mean
  )

GSE254484_13_mean


#STEP 4 — Construct the final Figure 9 dataset


# ---------------------------------------------------------
# Figure 9 master dataset
# ---------------------------------------------------------

Fig9_data <- Fig8_data %>%
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE149856_processed_mean,
    GSE227559_Mean,
    HRBC_Targets,
    Candidate_Score,
    Combined_Expression,
    Overall_Validation
  ) %>%
  left_join(
    GSE254484_13_mean,
    by = "miRNA"
  )

# Check
nrow(Fig9_data)

colSums(is.na(Fig9_data))

Fig9_data



nrow(Fig9_data)

sum(is.na(Fig9_data$GSE254484_Mean))


#FIGURE 9A
#Abundance of prioritised healthy EV miRNAs in commercial milk powder

# =========================================================
# FIGURE 9A
# =========================================================

Fig9_A_data <- Fig9_data %>%
  mutate(
    log2_Powder_Expression =
      log2(GSE254484_Mean + 1)
  ) %>%
  arrange(
    desc(log2_Powder_Expression)
  ) %>%
  mutate(
    miRNA = factor(
      miRNA,
      levels = rev(miRNA)
    )
  )

p9A <- ggplot(
  Fig9_A_data,
  aes(
    x = log2_Powder_Expression,
    y = miRNA
  )
) +
  geom_segment(
    aes(
      x = 0,
      xend = log2_Powder_Expression,
      y = miRNA,
      yend = miRNA
    ),
    linewidth = 0.7
  ) +
  geom_point(
    size = 4
  ) +
  labs(
    title =
      "Abundance of prioritised healthy EV miRNAs in commercial milk powder",
    x = expression(log[2]~"(TPM + 1)"),
    y = NULL
  ) +
  theme_classic(
    base_size = 13
  ) +
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.text.y = element_text(
      color = "black"
    ),
    axis.title.x = element_text(
      face = "bold"
    )
  )

p9A


# =========================================================
# FIGURE 9B
# Healthy reference rank vs powder rank
# =========================================================

rank_reference <- Fig9_data %>%
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE149856_processed_mean,
    GSE227559_Mean,
    GSE254484_Mean
  ) %>%
  pivot_longer(
    cols = -miRNA,
    names_to = "Dataset",
    values_to = "Expression"
  ) %>%
  group_by(Dataset) %>%
  mutate(
    Rank = rank(
      -Expression,
      ties.method = "average"
    )
  ) %>%
  ungroup()


Healthy_rank <- rank_reference %>%
  filter(
    Dataset %in% c(
      "GSE201588_TPM_Mean",
      "GSE149856_processed_mean",
      "GSE227559_Mean"
    )
  ) %>%
  group_by(miRNA) %>%
  summarise(
    Healthy_Mean_Rank = mean(
      Rank,
      na.rm = TRUE
    ),
    .groups = "drop"
  )


Powder_rank <- rank_reference %>%
  filter(
    Dataset == "GSE254484_Mean"
  ) %>%
  select(
    miRNA,
    Powder_Rank = Rank
  )


Fig9_B_data <- Healthy_rank %>%
  left_join(
    Powder_rank,
    by = "miRNA"
  )

Fig9_B_data

#Calculate Spearman correlation
cor_test_9B <- cor.test(
  Fig9_B_data$Healthy_Mean_Rank,
  Fig9_B_data$Powder_Rank,
  method = "spearman",
  exact = FALSE
)

cor_test_9B

rho_9B <- unname(
  cor_test_9B$estimate
)

p_9B <- cor_test_9B$p.value

rho_9B
p_9B

#Plot Fig. 9B
p9B <- ggplot(
  Fig9_B_data,
  aes(
    x = Healthy_Mean_Rank,
    y = Powder_Rank
  )
) +
  geom_point(
    size = 3.5
  ) +
  geom_smooth(
    method = "lm",
    se = FALSE,
    linewidth = 0.8
  ) +
  geom_abline(
    slope = 1,
    intercept = 0,
    linetype = "dashed",
    linewidth = 0.7
  ) +
  annotate(
    "text",
    x = Inf,
    y = -Inf,
    hjust = 1.05,
    vjust = -0.5,
    label = paste0(
      "Spearman \u03c1 = ",
      round(rho_9B, 3),
      "\nP = ",
      format.pval(
        p_9B,
        digits = 3,
        eps = 1e-4
      )
    ),
    size = 4.5
  ) +
  scale_x_reverse() +
  scale_y_reverse() +
  labs(
    title =
      "Healthy reference rank versus commercial milk-powder rank",
    x =
      "Mean healthy-cohort rank (1 = highest)",
    y =
      "GSE254484 rank (1 = highest)"
  ) +
  theme_classic(
    base_size = 13
  ) +
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.title = element_text(
      face = "bold"
    )
  )

p9B



# =========================================================
# FIGURE 9C
# Rank movement
# =========================================================

Fig9_C_data <- Fig9_B_data %>%
  pivot_longer(
    cols = c(
      Healthy_Mean_Rank,
      Powder_Rank
    ),
    names_to = "Condition",
    values_to = "Rank"
  ) %>%
  mutate(
    Condition = recode(
      Condition,
      Healthy_Mean_Rank = "Healthy reference",
      Powder_Rank = "Commercial milk powder"
    )
  )



miRNA_rank_order <- Fig9_B_data %>%
  arrange(
    Healthy_Mean_Rank
  ) %>%
  pull(miRNA)

Fig9_C_data$miRNA <- factor(
  Fig9_C_data$miRNA,
  levels = rev(miRNA_rank_order)
)


p9C <- ggplot(
  Fig9_C_data,
  aes(
    x = Rank,
    y = miRNA,
    group = miRNA
  )
) +
  geom_line(
    linewidth = 0.8,
    alpha = 0.6
  ) +
  geom_point(
    size = 3.5
  ) +
  facet_wrap(
    ~ Condition,
    ncol = 2
  ) +
  scale_x_reverse(
    breaks = 1:13
  ) +
  labs(
    title =
      "Rank movement of prioritised healthy EV miRNAs",
    x =
      "Abundance rank (1 = highest)",
    y = NULL
  ) +
  theme_classic(
    base_size = 13
  ) +
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    strip.text = element_text(
      face = "bold"
    ),
    axis.title.x = element_text(
      face = "bold"
    )
  )

p9C


#an even better version
#For a true slope plot, don't facet. Put both endpoints on the same axis:

p9C <- ggplot(
  Fig9_C_data,
  aes(
    x = Condition,
    y = Rank,
    group = miRNA
  )
) +
  geom_line(
    linewidth = 0.7,
    alpha = 0.6
  ) +
  geom_point(
    size = 3
  ) +
  scale_y_reverse(
    breaks = 1:13
  ) +
  labs(
    title =
      "Rank movement of prioritised healthy EV miRNAs",
    x = NULL,
    y =
      "Abundance rank (1 = highest)"
  ) +
  theme_classic(
    base_size = 13
  ) +
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.title.y = element_text(
      face = "bold"
    ),
    axis.text.x = element_text(
      face = "bold"
    )
  )

p9C


# =========================================================
# FIGURE 9D
# Heatmap
# =========================================================

Fig9_D_raw <- Fig9_data %>%
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE149856_processed_mean,
    GSE227559_Mean,
    GSE254484_Mean
  )


Fig9_D_raw <- Fig9_D_raw %>%
  mutate(
    GSE201588_TPM_mean =
      log2(GSE201588_TPM_mean + 1),
    
    GSE227559_Mean =
      log2(GSE227559_Mean + 1),
    
    GSE254484_Mean =
      log2(GSE254484_Mean + 1)
  )


Fig9_D_matrix <- Fig9_D_raw %>%
  column_to_rownames("miRNA") %>%
  as.matrix()

library(tibble)


Fig9_D_z <- t(
  scale(
    t(Fig9_D_matrix)
  )
)

round(
  Fig9_D_z,
  2
)


#Order the heatmap by healthy reference rank
heatmap_order <- Fig9_B_data %>%
  arrange(
    Healthy_Mean_Rank
  ) %>%
  pull(miRNA)

Fig9_D_z <- Fig9_D_z[
  heatmap_order,
  ,
  drop = FALSE
]



p9D <- pheatmap(
  Fig9_D_z,
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  scale = "none",
  border_color = "grey70",
  display_numbers = FALSE,
  fontsize = 11,
  fontsize_row = 10,
  fontsize_col = 11,
  main =
    "Core healthy bovine milk EV miRNA signature across cohorts"
)

p9D


#STEP 5 — Save all Figure 9 data
# =========================================================
# SAVE COMPLETE FIGURE 9 DATA
# =========================================================

write.csv(
  Fig9_data,
  "Figure_9_Complete_13_miRNA_Data.csv",
  row.names = FALSE
)

write.csv(
  Fig9_A_data,
  "Figure_9A_Powder_Abundance_Data.csv",
  row.names = FALSE
)

write.csv(
  Fig9_B_data,
  "Figure_9B_Healthy_vs_Powder_Rank_Data.csv",
  row.names = FALSE
)

write.csv(
  Fig9_C_data,
  "Figure_9C_Rank_Movement_Data.csv",
  row.names = FALSE
)

write.csv(
  Fig9_D_raw,
  "Figure_9D_Heatmap_Raw_Data.csv",
  row.names = FALSE
)

write.csv(
  as.data.frame(Fig9_D_z),
  "Figure_9D_Heatmap_Zscore_Data.csv"
)


Fig9B_statistics <- data.frame(
  Spearman_rho = rho_9B,
  P_value = p_9B
)

write.csv(
  Fig9B_statistics,
  "Figure_9B_Spearman_Statistics.csv",
  row.names = FALSE
)


#STEP 6 — Save the four panels at 600 dpi
ggsave(
  "Figure_9A_Powder_Abundance_13_miRNAs.tiff",
  p9A,
  width = 9,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

ggsave(
  "Figure_9B_Healthy_vs_Powder_Rank.tiff",
  p9B,
  width = 7,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

ggsave(
  "Figure_9C_Rank_Movement.tiff",
  p9C,
  width = 8,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)


tiff(
  "Figure_9D_Core_Signature_Heatmap.tiff",
  width = 8,
  height = 7,
  units = "in",
  res = 600,
  compression = "lzw"
)

pheatmap(
  Fig9_D_z,
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  scale = "none",
  border_color = "grey70",
  display_numbers = FALSE,
  fontsize = 11,
  fontsize_row = 10,
  fontsize_col = 11,
  main =
    "Core healthy bovine milk EV miRNA signature across cohorts"
)

dev.off()


#To add miRNA names in Figure 9B and 9C.

#Figure 9B — Healthy reference rank vs GSE254484 rank

library(ggplot2)
library(ggrepel)

p9B <- ggplot(
  Fig9_B_data,
  aes(
    x = Healthy_Mean_Rank,
    y = Powder_Rank
  )
) +
  
  # Diagonal reference line
  geom_abline(
    slope = 1,
    intercept = 0,
    linetype = "dashed",
    linewidth = 0.7
  ) +
  
  # Points
  geom_point(
    size = 3.5
  ) +
  
  # miRNA labels
  geom_text_repel(
    aes(label = miRNA),
    size = 3.5,
    box.padding = 0.5,
    point.padding = 0.3,
    max.overlaps = Inf,
    min.segment.length = 0,
    segment.linewidth = 0.4
  ) +
  
  labs(
    title = "Healthy-reference rank versus commercial milk-powder rank",
    x = "Mean rank across healthy reference cohorts",
    y = "GSE254484 rank"
  ) +
  
  theme_classic(
    base_size = 13
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.title = element_text(
      face = "bold"
    )
  )

p9B



#Figure 9C — Rank movement

p9C <- ggplot(
  Fig9_C_data,
  aes(
    x = Cohort,
    y = Rank,
    group = miRNA
  )
) +
  
  geom_line(
    linewidth = 0.7,
    alpha = 0.6
  ) +
  
  geom_point(
    size = 3
  ) +
  
  facet_wrap(
    ~ miRNA,
    ncol = 4
  ) +
  
  scale_y_reverse() +
  
  labs(
    title = "Rank movement of prioritised healthy EV miRNAs",
    x = NULL,
    y = "Abundance rank (1 = highest)"
  ) +
  
  theme_classic(
    base_size = 12
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    strip.text = element_text(
      face = "bold",
      size = 10
    ),
    axis.title.y = element_text(
      face = "bold"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    )
  )

p9C



######## or

p9C <- ggplot(
  Fig9_C_data,
  aes(
    x = Rank,
    y = miRNA,
    group = miRNA
  )
) +
  
  geom_line(
    linewidth = 0.8,
    alpha = 0.6
  ) +
  
  geom_point(
    size = 3
  ) +
  
  scale_x_reverse(
    breaks = scales::pretty_breaks(n = 8)
  ) +
  
  labs(
    title = "Rank movement of prioritised healthy EV miRNAs",
    x = "Abundance rank (1 = highest)",
    y = NULL
  ) +
  
  theme_classic(
    base_size = 13
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.title.x = element_text(
      face = "bold"
    ),
    axis.text.y = element_text(
      color = "black",
      size = 10
    ),
    axis.text.x = element_text(
      color = "black"
    )
  )

p9C









save.image(".RData")
savehistory("My_R_History.Rhistory")











