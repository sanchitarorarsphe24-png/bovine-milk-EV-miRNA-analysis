#script to visualisze gene expression data (GSE149856) Switzerland
# script "D:/SANCHIT ARORA/IIT BHU/Sanchit_PhD/Sanchit_PhD research work/In silico studies/Scripts"


#Step 1.Download and inspect the processed file

#Step 2. Extract only known bovine miRNAs
# Load package
library(readxl)

#import the excel file
gse149856 <- read_excel("GSE149856_processedfile_edgeR_Saenz-de-Juano.xlsx")

#Inspect the data
head(gse149856)

dim(gse149856)

colnames(gse149856)

#Extract only known bovine miRNAs
known_miRNA <- gse149856[grepl("^bta-", gse149856$GeneID), ]

# or using dplyr
library(dplyr)

known_miRNA <- gse149856 %>%
  filter(grepl("^bta-", GeneID))

#check the result
#nuber of known miRNAs
nrow(known_miRNA)

head(known_miRNA)

head(known_miRNA$GeneID)

#Check if any novel miRNAs exist
sum(grepl("novel", gse149856$GeneID, ignore.case = TRUE))

#Save the filtered dataset
write.csv(
  known_miRNA,
  "GSE149856_Known_bta_miRNAs.csv",
  row.names = FALSE
)

#Verify that filtering worked
# Total miRNAs
nrow(gse149856)

# Known bovine miRNAs
nrow(known_miRNA)

# Any non-bta entries?
known_miRNA[!grepl("^bta-", known_miRNA$GeneID), ]



# Step 3. Validate only candidate miRNAs from GSE201588

#create final Top 20 candidate known miRNA list from GSE201588
candidate_miRNAs <- c(
  "bta-miR-21-5p",
  "bta-miR-30a-5p",
  "bta-miR-24-3p",
  "bta-let-7f",
  "bta-miR-92a",
  "bta-miR-26a",
  "bta-miR-30e-5p",
  "bta-miR-27b",
  "bta-miR-30d",
  "bta-miR-7",
  "bta-miR-23a",
  "bta-miR-425-5p",
  "bta-let-7b",
  "bta-let-7i",
  "bta-let-7a-5p",
  "bta-miR-574",
  "bta-let-7g",
  "bta-miR-27a-3p",
  "bta-miR-182",
  "bta-miR-186"
)

#Check whether these miRNAs exist in GSE149856
candidate_miRNAs %in% known_miRNA$GeneID

#Identify missing miRNAs (if any)
setdiff(candidate_miRNAs, known_miRNA$GeneID)

#Extract only candidate miRNAs
candidate_validation <- known_miRNA[
  known_miRNA$GeneID %in% candidate_miRNAs,
]
# Or using dplyr
library(dplyr)

candidate_validation <- known_miRNA %>%
  filter(GeneID %in% candidate_miRNAs)

#Check the extracted data
dim(candidate_validation)

candidate_validation

head(candidate_validation)

#Preserve the same order as our candidate list
#To keep the same ranking as GSE201588:

candidate_validation <- candidate_validation[
  match(candidate_miRNAs,
        candidate_validation$GeneID),
]

candidate_validation$GeneID

#Save the validation dataset
write.csv(
  candidate_validation,
  "Candidate_miRNAs_GSE149856.csv",
  row.names = FALSE
)

#Verify the extracted miRNAs
candidate_validation$GeneID

#Simply remove the missing miRNA from the validation list which shown as NA
candidate_validation <- candidate_validation[!is.na(candidate_validation$GeneID), ]

candidate_validation$GeneID

#Save the validation dataset
write.csv(
  candidate_validation,
  file = "Candidate_miRNAs_GSE149856_Validated.csv",
  row.names = FALSE
)


#STEP 4A. Expression Heatmap

# Load packages
library(pheatmap)
library(RColorBrewer)

#Set miRNA names as row names
candidate_validation <- known_miRNA %>%
  filter(GeneID %in% candidate_miRNAs)

candidate_validation <- candidate_validation[
  match(candidate_miRNAs, candidate_validation$GeneID),
]

candidate_validation <- candidate_validation[!is.na(candidate_validation$GeneID), ]

candidate_validation <- as.data.frame(candidate_validation)

rownames(candidate_validation) <- candidate_validation$GeneID

candidate_validation$GeneID <- NULL

head(candidate_validation)

#Create sample group annotation
# Convert to data frame (if not already)
candidate_validation <- as.data.frame(candidate_validation)

# Get sample names
sample_names <- colnames(candidate_validation)

# Assign groups based on sample names
group_labels <- ifelse(grepl("_H", sample_names), "Healthy",
                       ifelse(grepl("_C", sample_names), "High_SCC",
                              "Low_SCC"))

# Create annotation dataframe
sample_group <- data.frame(
  Group = factor(group_labels,
                 levels = c("Healthy", "High_SCC", "Low_SCC"))
)

rownames(sample_group) <- sample_names

sample_group

table(sample_group$Group)


#Reorder the samples
healthy_cols <- rownames(sample_group)[sample_group$Group == "Healthy"]
high_cols    <- rownames(sample_group)[sample_group$Group == "High_SCC"]
low_cols     <- rownames(sample_group)[sample_group$Group == "Low_SCC"]

candidate_validation <- candidate_validation[, c(healthy_cols,
                                                 high_cols,
                                                 low_cols)]

sample_group <- sample_group[c(healthy_cols,
                               high_cols,
                               low_cols), , drop = FALSE]
table(sample_group$Group)

#Z-score normalization
heatmap_matrix <- t(scale(t(as.matrix(candidate_validation))))

heatmap_matrix[is.na(heatmap_matrix)] <- 0

#Annotation colors
annotation_colors <- list(
  Group = c(
    Healthy = "#4DAF4A",
    High_SCC = "#E41A1C",
    Low_SCC = "#377EB8"
  )
)

#Heatmap colors
heat_colors <- colorRampPalette(
  c("navy", "white", "firebrick3")
)(100)

#Draw the heatmap
library(pheatmap)

pheatmap(
  heatmap_matrix,
  color = heat_colors,
  annotation_col = sample_group,
  annotation_colors = annotation_colors,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  show_rownames = TRUE,
  show_colnames = TRUE,
  fontsize_row = 10,
  fontsize_col = 8,
  border_color = NA,
  scale = "none",
  main = "Validation of Candidate miRNAs in GSE149856"
)


#Step 4B Expression Heatmap
#Extract only Healthy and High_SCC samples
# Healthy samples
healthy_cols <- grep("_H", colnames(candidate_validation), value = TRUE)

# High_SCC samples
high_cols <- grep("_C", colnames(candidate_validation), value = TRUE)

# Expression matrix (Healthy + High_SCC only)
candidate_validation_HC <- candidate_validation[, c(healthy_cols, high_cols)]

dim(candidate_validation_HC)

#Create sample annotation
sample_group_HC <- data.frame(
  Group = factor(
    c(rep("Healthy", length(healthy_cols)),
      rep("High_SCC", length(high_cols))),
    levels = c("Healthy", "High_SCC")
  )
)

rownames(sample_group_HC) <- colnames(candidate_validation_HC)

sample_group_HC

table(sample_group_HC$Group)

#Z-score normalization
heatmap_matrix_HC <- t(
  scale(
    t(as.matrix(candidate_validation_HC))
  )
)

heatmap_matrix_HC[is.na(heatmap_matrix_HC)] <- 0

#Annotation colors
annotation_colors_HC <- list(
  Group = c(
    Healthy = "#4DAF4A",
    High_SCC = "#E41A1C"
  )
)

#Heatmap colors
heat_colors <- colorRampPalette(
  c("navy", "white", "firebrick3")
)(100)

#Generate the publication-quality heatmap
library(pheatmap)

pheatmap(
  heatmap_matrix_HC,
  
  color = heat_colors,
  
  annotation_col = sample_group_HC,
  
  annotation_colors = annotation_colors_HC,
  
  cluster_rows = TRUE,
  
  cluster_cols = FALSE,
  
  show_rownames = TRUE,
  
  show_colnames = TRUE,
  
  fontsize_row = 10,
  
  fontsize_col = 9,
  
  border_color = NA,
  
  scale = "none",
  
  main = "Validation of Candidate miRNAs (Healthy vs High_SCC)"
)


#STEP 5 BOXPLOT

#load packages
library(ggplot2)

#Create Healthy vs High_SCC dataset
# Healthy samples
healthy_cols <- grep("_H", colnames(candidate_validation), value = TRUE)

# High SCC samples
high_cols <- grep("_C", colnames(candidate_validation), value = TRUE)

# Expression matrix
candidate_validation_HC <- candidate_validation[, c(healthy_cols, high_cols)]


#Create sample information
sample_group_HC <- data.frame(
  
  Sample = colnames(candidate_validation_HC),
  
  Group = factor(
    c(rep("Healthy", length(healthy_cols)),
      rep("High_SCC", length(high_cols))),
    levels = c("Healthy","High_SCC")
  )
  
)

#Function for plotting
plot_miRNA <- function(miRNA_name){
  
  expr <- as.numeric(candidate_validation_HC[miRNA_name, ])
  
  plot_data <- data.frame(
    
    Expression = expr,
    
    Group = sample_group_HC$Group
    
  )
  
  p <- ggplot(plot_data,
              
              aes(Group,
                  Expression,
                  fill = Group)) +
    
    geom_boxplot(
      width = 0.60,
      alpha = 0.80,
      outlier.shape = NA
    ) +
    
    geom_jitter(
      width = 0.12,
      size = 2
    ) +
    
    scale_fill_manual(values=c(
      Healthy="#4DAF4A",
      High_SCC="#E41A1C"
    )) +
    
    labs(
      title = miRNA_name,
      x = "",
      y = "Normalized Expression"
    ) +
    
    theme_classic(base_size = 14) +
    
    theme(
      
      legend.position = "none",
      
      plot.title = element_text(
        face="bold",
        hjust=0.5
      )
      
    )
  
  return(p)
  
}

#Automatically detect all 19 candidate miRNAs
candidate_list <- rownames(candidate_validation_HC)

candidate_list


#Generate and save all 19 boxplots
for(miRNA in candidate_list){
  
  p <- plot_miRNA(miRNA)
  
  file_name <- paste0(
    gsub("[/ ]","_",miRNA),
    "_Boxplot.tiff"
  )
  
  ggsave(
    
    filename = file_name,
    
    plot = p,
    
    width = 4,
    
    height = 5,
    
    dpi = 600,
    
    compression = "lzw"
    
  )
  
}

#STEP 6. CANDIDATE VALIDATION TABLE

#Create the discovery summary (SM vs H)
library(dplyr)

discovery_summary <- data.frame(
  miRNA = rownames(results_H_SM_known),
  logFC = results_H_SM_known$logFC,
  stringsAsFactors = FALSE
)

#Keep only the 19 candidate miRNAs
candidate_list <- rownames(candidate_validation)

discovery_summary <- discovery_summary %>%
  filter(miRNA %in% candidate_list)

#Determine discovery direction
#Since the comparison is SM vs Healthy:
#logFC > 0 = Higher in SM
#logFC < 0 = Higher in Healthy

discovery_summary$Discovery <- ifelse(
  discovery_summary$logFC > 0,
  "High",
  "Low"
)

#Calculate validation mean expression
validation_summary <- data.frame(
  
  miRNA = rownames(candidate_validation_HC),
  
  Healthy_Mean = rowMeans(
    candidate_validation_HC[, healthy_cols]
  ),
  
  HighSCC_Mean = rowMeans(
    candidate_validation_HC[, high_cols]
  ),
  
  stringsAsFactors = FALSE
  
)

#Determine validation direction
validation_summary$Validation <- ifelse(
  validation_summary$HighSCC_Mean >
    validation_summary$Healthy_Mean,
  "High",
  "Low"
)

#Merge discovery and validation
candidate_validation_table <- merge(
  
  discovery_summary[, c("miRNA","Discovery")],
  
  validation_summary[, c("miRNA","Validation")],
  
  by = "miRNA"
  
)

#Determine consistency
candidate_validation_table$Consistent <- ifelse(
  
  candidate_validation_table$Discovery ==
    candidate_validation_table$Validation,
  
  "\u2713",
  
  "\u2717"
  
)

#Restore the original miRNA order
candidate_validation_table <- candidate_validation_table[
  match(candidate_list,
        candidate_validation_table$miRNA),
]

#View the final table
candidate_validation_table

#Count validated candidates
table(candidate_validation_table$Consistent)

#Calculate validation percentage
validation_rate <- round(
  
  sum(candidate_validation_table$Consistent == "\u2713") /
    nrow(candidate_validation_table) * 100,
  
  1
  
)

validation_rate

#Save the table
write.csv(

candidate_validation_table,

"Candidate_Validation_Table_GSE201588_GSE149856.csv",

row.names = FALSE

)


#Recreate the candidate validation table (corrected log FC from GSE201588)
results_H_SM$miRNA <- rownames(results_H_SM)

discovery_summary <- results_H_SM %>%
  dplyr::filter(miRNA %in% rownames(candidate_validation_HC)) %>%
  dplyr::select(miRNA, logFC, adj.P.Val)

#Create a direction column. Because your contrast is H − SM:
#logFC < 0 → Higher in SM
#logFC > 0 → Higher in H

discovery_summary$Discovery <- ifelse(
  discovery_summary$logFC < 0,
  "Higher in SM",
  "Higher in H"
)

#Validation dataset

validation_summary <- data.frame(
  miRNA = rownames(candidate_validation_HC),
  Healthy_Mean = rowMeans(candidate_validation_HC[, healthy_cols]),
  HighSCC_Mean = rowMeans(candidate_validation_HC[, high_cols])
)

validation_summary$Validation <- ifelse(
  validation_summary$HighSCC_Mean > validation_summary$Healthy_Mean,
  "Higher in High_SCC",
  "Higher in Healthy"
)

#Merge the two
candidate_validation_table <- merge(
  discovery_summary,
  validation_summary[, c("miRNA", "Validation")],
  by = "miRNA"
)

#Check consistency
candidate_validation_table$Consistent <- ifelse(
  (candidate_validation_table$Discovery == "Higher in SM" &
     candidate_validation_table$Validation == "Higher in High_SCC") |
    (candidate_validation_table$Discovery == "Higher in H" &
       candidate_validation_table$Validation == "Higher in Healthy"),
  "✓",
  "✗"
)


#Save the final table
write.csv(
  candidate_validation_table,
  "Candidate_Validation_Table.csv",
  row.names = FALSE
)

#Comparison Purpose

#Healthy vs High_SCC External validation of GSE201588
#Low_SCC vs High_SCC Internal validation within infected cows

#1. Create sample groups
healthy_cols <- grep("_H", colnames(candidate_validation), value = TRUE)

high_cols <- grep("_C", colnames(candidate_validation), value = TRUE)

low_cols <- grep("_L", colnames(candidate_validation), value = TRUE)


length(healthy_cols)
length(high_cols)
length(low_cols)

#2. Mean expression
validation_summary <- data.frame(
  
  miRNA = rownames(candidate_validation),
  
  Healthy =
    rowMeans(candidate_validation[, healthy_cols]),
  
  Low_SCC =
    rowMeans(candidate_validation[, low_cols]),
  
  High_SCC =
    rowMeans(candidate_validation[, high_cols])
  
)

#3. External validation
#(Healthy vs High SCC)
validation_summary$H_vs_High <-
  ifelse(
    
    validation_summary$High_SCC >
      validation_summary$Healthy,
    
    "Higher in High_SCC",
    
    "Higher in Healthy"
    
  )

#4. Internal validation
#(Low SCC vs High SCC)

validation_summary$Low_vs_High <-
  ifelse(
    
    validation_summary$High_SCC >
      validation_summary$Low_SCC,
    
    "Higher in High_SCC",
    
    "Higher in Low_SCC"
    
  )

#5. Discovery
results_H_SM$miRNA <- rownames(results_H_SM)

discovery_summary <-
  results_H_SM %>%
  dplyr::filter(miRNA %in% rownames(candidate_validation)) %>%
  dplyr::select(miRNA,logFC,adj.P.Val)

discovery_summary$Discovery <-
  ifelse(
    
    discovery_summary$logFC < 0,
    
    "Higher in SM",
    
    "Higher in Healthy"
    
  )

#6. Merge
candidate_validation_table <-
  merge(
    discovery_summary,
    validation_summary,
    by="miRNA"
  )

#7. External validation
candidate_validation_table$External_Validation <-
  ifelse(
    
    (candidate_validation_table$Discovery=="Higher in SM" &
       candidate_validation_table$H_vs_High=="Higher in High_SCC") |
      
      (candidate_validation_table$Discovery=="Higher in Healthy" &
         candidate_validation_table$H_vs_High=="Higher in Healthy"),
    
    "✓","✗"
    
  )

#8. Internal validation
candidate_validation_table$Internal_Validation <-
  ifelse(
    
    (candidate_validation_table$Discovery=="Higher in SM" &
       candidate_validation_table$Low_vs_High=="Higher in High_SCC") |
      
      (candidate_validation_table$Discovery=="Higher in Healthy" &
         candidate_validation_table$Low_vs_High=="Higher in Low_SCC"),
    
    "✓","✗"
    
  )

#9.Overall validation
candidate_validation_table$Overall_Validation <-
  ifelse(
    
    candidate_validation_table$External_Validation=="✓" &
      candidate_validation_table$Internal_Validation=="✓",
    
    "Strong",
    
    ifelse(
      
      candidate_validation_table$External_Validation=="✓" |
        candidate_validation_table$Internal_Validation=="✓",
      
      "Partial",
      
      "Not Validated"
      
    )
    
  )


View(candidate_validation_table)

candidate_validation_table

table(candidate_validation_table$Overall_Validation)


subset(candidate_validation_table,
       Overall_Validation == "Strong")

subset(candidate_validation_table,
       Overall_Validation == "Partial")


subset(candidate_validation_table,
       Overall_Validation == "Not Validated")


write.csv(candidate_validation_table,
          "Candidate_Validation_Final.csv",
          row.names = FALSE)

#Step 7. Venn Diagram: Top abundant miRNAs
#Get mean TPM for GSE201588 (China)
#Use our original TPM matrix (expr_mat), not the log2-transformed matrix.

#Extract only known bovine miRNAs
known_expr <- expr_mat[
  grepl("^bta-", rownames(expr_mat)) &
    !grepl("novel", rownames(expr_mat), ignore.case = TRUE),
]

known_expr <- expr_mat[
  grepl("^bta-", data.merged$miRNA) &
    !grepl("novel", data.merged$miRNA, ignore.case = TRUE),
]

#Check the number of known miRNAs
dim(known_expr)

rownames(known_expr)

#Calculate mean TPM
mean_GSE201588 <- rowMeans(known_expr)

#Rank the miRNAs
ranked_miRNAs <- sort(mean_GSE201588, decreasing = TRUE)

head(ranked_miRNAs)

#Extract the Top 20 abundant miRNAs
top20_China <- names(ranked_miRNAs)[1:20]

top20_China


#Save the Top 20
Top20_China <- data.frame(
  miRNA = top20_China,
  Mean_TPM = ranked_miRNAs[1:20]
)

write.csv(
  Top20_China,
  "Top20_Known_bta_miRNAs_GSE201588.csv",
  row.names = FALSE
)

#Compare with GSE149856
colnames(gse149856)


#Set miRNA names as row names
# Convert tibble to data.frame
gse149856_df <- as.data.frame(gse149856)

# Set miRNA names as row names
rownames(gse149856_df) <- gse149856_df$GeneID

# Remove the GeneID column
expr_swiss <- gse149856_df[, -1]

# Convert all expression values to numeric
expr_swiss[] <- lapply(expr_swiss, as.numeric)

# Check dimensions
dim(expr_swiss)


# Mean expression
mean_Switzerland <- rowMeans(expr_swiss, na.rm = TRUE)

# Rank miRNAs
rank_Switzerland <- sort(mean_Switzerland, decreasing = TRUE)

# Top 20 miRNAs
top20_Switzerland <- names(rank_Switzerland)[1:20]

top20_Switzerland


#Then compare with China:
overlap <- intersect(top20_China, top20_Switzerland)

overlap

length(overlap)

#generate the Venn diagram:
install.packages("VennDiagram")

library(VennDiagram)
library(grid)
library(futile.logger)

venn.plot <- venn.diagram(
  x = list(
    GSE201588 = top20_China,
    GSE149856 = top20_Switzerland
  ),
  filename = NULL,
  fill = c("steelblue", "tomato"),
  alpha = 0.5,
  cex = 1.5,
  cat.cex = 1.4,
  cat.fontface = "bold"
)

grid.newpage()
grid.draw(venn.plot)


top20_GSE201588 <- top20_China
top20_GSE149856 <- top20_Switzerland

#Step 8. Rank Correlation

#Find common miRNAs
ls()

head(ranked_miRNAs)

rank_China <- ranked_miRNAs

common_miRNAs <- intersect(names(rank_China),
                           names(rank_Switzerland))

length(common_miRNAs)

#Create the comparison table
rank_table <- data.frame(
  miRNA = common_miRNAs,
  GSE201588 = rank_China[common_miRNAs],
  GSE149856 = rank_Switzerland[common_miRNAs]
)

head(rank_table)

rank_table$Rank_GSE201588 <- rank(
  -rank_table$GSE201588,
  ties.method = "average"
)

rank_table$Rank_GSE149856 <- rank(
  -rank_table$GSE149856,
  ties.method = "average"
)


rank_table <- rank_table[order(rank_table$Rank_GSE201588), ]

head(rank_table)

spearman_result <- cor.test(
  rank_table$Rank_GSE201588,
  rank_table$Rank_GSE149856,
  method = "spearman"
)

spearman_result

rho <- unname(spearman_result$estimate)
pvalue <- spearman_result$p.value

cat("Spearman rho =", round(rho, 3), "\n")
cat("P-value =", signif(pvalue, 3), "\n")


#figure of the above data
library(ggplot2)

ggplot(rank_table,
       aes(x = Rank_GSE201588,
           y = Rank_GSE149856)) +
  geom_point(size = 3, color = "steelblue") +
  geom_smooth(method = "lm", se = FALSE, color = "red") +
  annotate("text",
           x = max(rank_table$Rank_GSE201588) * 0.65,
           y = max(rank_table$Rank_GSE149856) * 0.15,
           label = paste0(
             "Spearman \u03C1 = ", round(rho, 3),
             "\nP = ", signif(pvalue, 3)
           ),
           hjust = 0,
           size = 5) +
  labs(
    title = "Spearman Rank Correlation of Common miRNAs",
    x = "Rank in GSE201588",
    y = "Rank in GSE149856"
  ) +
  theme_classic(base_size = 14)


#Step 9. Candidate Validation Score

#Create China expression table
China_expr <- data.frame(
  miRNA = names(mean_GSE201588),
  Mean_TPM_China = as.numeric(mean_GSE201588)
)

#Create Switzerland expression table
Swiss_expr <- data.frame(
  miRNA = names(mean_Switzerland),
  Mean_Expression_Switzerland = as.numeric(mean_Switzerland)
)

#Create HR+BC target count table
head(target_counts)

ls()

head(target_counts_known)

str(target_counts_known)


#Create a bovine-to-human mapping

library(dplyr)
library(stringr)

miRNA_map <- data.frame(
  bta_miRNA = names(mean_GSE201588)
) %>%
  mutate(
    hsa_miRNA = str_replace(bta_miRNA, "^bta-", "hsa-")
  )

head(miRNA_map)

#Convert the China expression table
China_expr_hsa <- merge(
  miRNA_map,
  China_expr,
  by.x = "bta_miRNA",
  by.y = "miRNA"
)

China_expr_hsa <- China_expr_hsa |>
  select(
    hsa_miRNA,
    Mean_TPM_China
  )

colnames(China_expr_hsa)[1] <- "mature_mirna_id"

#Convert the Switzerland expression table
Swiss_expr_hsa <- merge(
  miRNA_map,
  Swiss_expr,
  by.x = "bta_miRNA",
  by.y = "miRNA"
)

Swiss_expr_hsa <- Swiss_expr_hsa |>
  select(
    hsa_miRNA,
    Mean_Expression_Switzerland
  )

colnames(Swiss_expr_hsa)[1] <- "mature_mirna_id"

#Merge with the HR+BC target counts
Candidate_score <- merge(
  China_expr_hsa,
  Swiss_expr_hsa,
  by = "mature_mirna_id",
  all = TRUE
)

Candidate_score <- merge(
  Candidate_score,
  target_counts,
  by = "mature_mirna_id",
  all.x = TRUE
)

#Merge the validation information
validation_hsa <- merge(
  miRNA_map,
  candidate_validation_table,
  by.x = "bta_miRNA",
  by.y = "miRNA"
)

validation_hsa <- validation_hsa |>
  select(
    hsa_miRNA,
    Discovery,
    External_Validation,
    Internal_Validation,
    Overall_Validation
  )

colnames(validation_hsa)[1] <- "mature_mirna_id"


Candidate_score <- merge(
  Candidate_score,
  validation_hsa,
  by = "mature_mirna_id",
  all.x = TRUE
)

#Replace missing target counts with 0
Candidate_score$HRBC_Targets[is.na(Candidate_score$HRBC_Targets)] <- 0

#Add Literature Support column
Candidate_score$Literature_Support <- NA

#Create a Candidate Score
Candidate_score$Validation_Score <- ifelse(
  Candidate_score$Overall_Validation == "Strong", 2,
  ifelse(
    Candidate_score$Overall_Validation == "Partial",
    1,
    0
  )
)

#Normalize expression values
Candidate_score$China_norm <-
  Candidate_score$Mean_TPM_China /
  max(Candidate_score$Mean_TPM_China, na.rm = TRUE)

Candidate_score$Swiss_norm <-
  Candidate_score$Mean_Expression_Switzerland /
  max(Candidate_score$Mean_Expression_Switzerland, na.rm = TRUE)

Candidate_score$Target_norm <-
  Candidate_score$HRBC_Targets /
  max(Candidate_score$HRBC_Targets, na.rm = TRUE)

#Overall Candidate Score
Candidate_score$Candidate_Score <-
  Candidate_score$China_norm +
  Candidate_score$Swiss_norm +
  Candidate_score$Target_norm +
  Candidate_score$Validation_Score

#Rank the candidates
Candidate_score <- Candidate_score[
  order(-Candidate_score$Candidate_Score),
]

#View the top candidates
head(Candidate_score, 20)

write.csv(
  Candidate_score,
  "Candidate_Validation_Score.csv",
  row.names = FALSE
)











#Starting again from scratch

library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(ggplot2)
library(pheatmap)
library(RColorBrewer)
library(VennDiagram)
library(grid)
library(patchwork)
library(futile.logger)

#Import GSE149856
gse149856 <- read_excel("GSE149856_processedfile_edgeR_Saenz-de-Juano.xlsx")

gse149856 <- as.data.frame(gse149856)

dim(gse149856)
colnames(gse149856)

head(gse149856)

str(gse149856)

#Extract known bovine miRNAs
known_miRNA <- gse149856 %>%
  filter(
    grepl("^bta-", GeneID),
    !grepl("novel", GeneID, ignore.case = TRUE)
  )

nrow(known_miRNA)
head(known_miRNA$GeneID)

#Use your final GSE201588 candidate list
candidate_miRNAs <- c(
  "bta-miR-30a-5p",
  "bta-miR-30e-5p",
  "bta-miR-92a",
  "bta-miR-186",
  "bta-miR-21-5p",
  "bta-miR-26a",
  "bta-miR-27b",
  "bta-miR-574",
  "bta-miR-7",
  "bta-miR-27a-3p",
  "bta-miR-24-3p",
  "bta-let-7b",
  "bta-let-7i"
)

candidate_miRNAs %in% known_miRNA$GeneID

setdiff(candidate_miRNAs, known_miRNA$GeneID)

#Extract candidates from GSE149856
candidate_validation <- known_miRNA %>%
  filter(GeneID %in% candidate_miRNAs)

candidate_validation <- candidate_validation[
  match(candidate_miRNAs, candidate_validation$GeneID),
]

candidate_validation <- candidate_validation[
  !is.na(candidate_validation$GeneID),
]

rownames(candidate_validation) <- candidate_validation$GeneID

candidate_validation$GeneID <- NULL

candidate_validation <- as.data.frame(candidate_validation)

dim(candidate_validation)

rownames(candidate_validation)

#Identify Healthy and High-SCC samples
healthy_cols <- grep(
  "_H",
  colnames(candidate_validation),
  value = TRUE
)

high_cols <- grep(
  "_C",
  colnames(candidate_validation),
  value = TRUE
)

low_cols <- grep(
  "_L",
  colnames(candidate_validation),
  value = TRUE
)

length(healthy_cols)
length(high_cols)
length(low_cols)

healthy_cols
high_cols
low_cols

#Create the Healthy vs High-SCC matrix
candidate_HC <- candidate_validation[
  ,
  c(healthy_cols, high_cols),
  drop = FALSE
]

dim(candidate_HC)

#Publication-quality heatmap
heatmap_matrix <- t(
  scale(
    t(
      as.matrix(candidate_HC)
    )
  )
)

heatmap_matrix[is.na(heatmap_matrix)] <- 0


sample_annotation <- data.frame(
  Group = factor(
    c(
      rep("Healthy", length(healthy_cols)),
      rep("High_SCC", length(high_cols))
    ),
    levels = c("Healthy", "High_SCC")
  )
)

rownames(sample_annotation) <- colnames(candidate_HC)

annotation_colors <- list(
  Group = c(
    Healthy = "#4DAF4A",
    High_SCC = "#E41A1C"
  )
)


pheatmap(
  heatmap_matrix,
  
  color = colorRampPalette(
    c("#2166AC", "white", "#B2182B")
  )(100),
  
  annotation_col = sample_annotation,
  annotation_colors = annotation_colors,
  
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  
  show_rownames = TRUE,
  show_colnames = TRUE,
  
  fontsize_row = 10,
  fontsize_col = 8,
  
  border_color = NA,
  
  main = "Independent validation of discovery-stage miRNAs"
)

#Calculate mean expression in Healthy and High-SCC
validation_summary <- data.frame(
  
  miRNA = rownames(candidate_HC),
  
  Healthy_Mean =
    rowMeans(
      candidate_HC[, healthy_cols, drop = FALSE],
      na.rm = TRUE
    ),
  
  HighSCC_Mean =
    rowMeans(
      candidate_HC[, high_cols, drop = FALSE],
      na.rm = TRUE
    )
  
)

validation_summary

#Determine validation direction
validation_summary <- validation_summary %>%
  mutate(
    
    Validation_Direction = case_when(
      
      HighSCC_Mean > Healthy_Mean ~
        "Higher in High-SCC",
      
      HighSCC_Mean < Healthy_Mean ~
        "Higher in Healthy",
      
      TRUE ~
        "Equal"
      
    )
    
  )

validation_summary

#Add the GSE201588 discovery direction
results_H_SM$miRNA <- rownames(results_H_SM)

discovery_summary <- results_H_SM %>%
  
  filter(
    miRNA %in% candidate_miRNAs
  ) %>%
  
  select(
    miRNA,
    logFC,
    adj.P.Val
  )

discovery_summary <- discovery_summary %>%
  
  mutate(
    
    Discovery_Direction = case_when(
      
      logFC < 0 ~
        "Higher in SM",
      
      logFC > 0 ~
        "Higher in Healthy",
      
      TRUE ~
        "Equal"
      
    )
    
  )


#Convert the validation direction to the discovery terminology
validation_summary <- validation_summary %>%
  
  mutate(
    
    Validation_Direction_Comparable = case_when(
      
      Validation_Direction ==
        "Higher in High-SCC" ~
        "Higher in SM",
      
      Validation_Direction ==
        "Higher in Healthy" ~
        "Higher in Healthy",
      
      TRUE ~ "Equal"
      
    )
    
  )

#Determine cross-cohort consistency
cross_cohort <- merge(
  
  discovery_summary,
  
  validation_summary,
  
  by.x = "miRNA",
  
  by.y = "miRNA"
  
)

cross_cohort$Direction_Consistent <- ifelse(
  
  cross_cohort$Discovery_Direction ==
    cross_cohort$Validation_Direction_Comparable,
  
  "Yes",
  
  "No"
  
)

cross_cohort

write.csv(
  cross_cohort,
  "GSE201588_GSE149856_Cross_Cohort_Consistency.csv",
  row.names = FALSE
)

#Calculate validation percentage
validation_rate <- mean(
  cross_cohort$Direction_Consistent == "Yes"
) * 100

validation_rate

#Add statistical testing for Healthy vs High-SCC
validation_stats <- lapply(
  rownames(candidate_HC),
  function(miRNA) {
    
    expr <- as.numeric(
      candidate_HC[miRNA, ]
    )
    
    group <- factor(
      c(
        rep("Healthy", length(healthy_cols)),
        rep("High_SCC", length(high_cols))
      )
    )
    
    test <- wilcox.test(
      expr ~ group,
      exact = FALSE
    )
    
    data.frame(
      miRNA = miRNA,
      p_value = test$p.value
    )
  }
) %>%
  
  bind_rows()

validation_stats$FDR <- p.adjust(
  validation_stats$p_value,
  method = "BH"
)

validation_stats

write.csv(
  validation_stats,
  "GSE201588_GSE149856_validation_stats.csv",
  row.names = FALSE
)

#Combine everything into your final validation table
final_validation <- cross_cohort %>%
  
  left_join(
    validation_stats,
    by = "miRNA"
  )

final_validation

write.csv(
  final_validation,
  "GSE201588_GSE149856_final_validation.csv",
  row.names = FALSE
)

#Add candidate score from GSE201588
Candidate_score

candidate_evidence <- Candidate_score %>%
  
  select(
    mature_mirna_id,
    Candidate_Score,
    HRBC_Targets
  )

colnames(candidate_evidence)[1] <- "miRNA"

candidate_evidence$miRNA <-
  str_replace(
    candidate_evidence$miRNA,
    "^hsa-",
    "bta-"
  )

final_validation <- final_validation %>%
  
  left_join(
    candidate_evidence,
    by = "miRNA"
  )

#Add GSE201588 and GSE149856 abundance
china_expression <- data.frame(
  
  miRNA = names(mean_GSE201588),
  
  GSE201588_TPM =
    as.numeric(mean_GSE201588)
  
)

swiss_expression <- data.frame(
  
  miRNA = names(mean_Switzerland),
  
  GSE149856_expression =
    as.numeric(mean_Switzerland)
  
)

final_validation <- final_validation %>%
  
  left_join(
    china_expression,
    by = "miRNA"
  ) %>%
  
  left_join(
    swiss_expression,
    by = "miRNA"
  )

#Final validation table
final_validation <- final_validation %>%
  
  select(
    miRNA,
    
    logFC,
    adj.P.Val,
    Discovery_Direction,
    
    Healthy_Mean,
    HighSCC_Mean,
    Validation_Direction,
    
    p_value,
    FDR,
    
    Direction_Consistent,
    
    GSE201588_TPM,
    GSE149856_expression,
    
    Candidate_Score,
    HRBC_Targets
  )

final_validation

write.csv(
  final_validation,
  "GSE149856_Cross_Cohort_Validation_Final.csv",
  row.names = FALSE
)

#Venn diagram — revised
#I would not use a Venn diagram of arbitrary top-20 abundant miRNAs as your strongest validation figure.

#Instead, use:
#GSE201588 prioritized candidates
#versus
#Candidates detected in GSE149856


discovery_set <- candidate_miRNAs

validation_set <- intersect(
  candidate_miRNAs,
  rownames(candidate_validation)
)

length(discovery_set)
length(validation_set)

venn.plot <- venn.diagram(
  
  x = list(
    
    GSE201588_Discovery =
      discovery_set,
    
    GSE149856_Detected =
      validation_set
    
  ),
  
  filename = NULL,
  
  fill = c(
    "#377EB8",
    "#E41A1C"
  ),
  
  alpha = 0.55,
  
  cex = 1.5,
  
  cat.cex = 1.3,
  
  cat.fontface = "bold",
  
  margin = 0.1
  
)

grid.newpage()
grid.draw(venn.plot)


#Rank correlation — improving my previous analysis
rank_data <- final_validation %>%
  
  select(
    miRNA,
    GSE201588_TPM,
    GSE149856_expression
  ) %>%
  
  filter(
    !is.na(GSE201588_TPM),
    !is.na(GSE149856_expression)
  )

rank_data$Rank_GSE201588 <- rank(
  -rank_data$GSE201588_TPM,
  ties.method = "average"
)

rank_data$Rank_GSE149856 <- rank(
  -rank_data$GSE149856_expression,
  ties.method = "average"
)


spearman_test <- cor.test(
  
  rank_data$GSE201588_TPM,
  
  rank_data$GSE149856_expression,
  
  method = "spearman",
  
  exact = FALSE
  
)

spearman_test

#Rank correlation plot

rho <- unname(
  spearman_test$estimate
)

pval <- spearman_test$p.value

rank_plot <- ggplot(
  rank_data,
  
  aes(
    x = GSE201588_TPM,
    y = GSE149856_expression
  )
) +
  
  geom_point(
    size = 3.5,
    alpha = 0.85
  ) +
  
  geom_smooth(
    method = "lm",
    se = TRUE,
    linewidth = 0.8
  ) +
  
  geom_text(
    aes(label = miRNA),
    vjust = -0.6,
    size = 3
  ) +
  
  annotate(
    "text",
    
    x = Inf,
    y = -Inf,
    
    label = paste0(
      "Spearman \u03C1 = ",
      round(rho, 3),
      "\nP = ",
      signif(pval, 3)
    ),
    
    hjust = 1.05,
    vjust = -0.5,
    
    size = 4
  ) +
  
  scale_x_log10() +
  
  scale_y_log10() +
  
  labs(
    
    x = "GSE201588 mean expression (TPM)",
    
    y = "GSE149856 mean expression",
    
    title =
      "Cross-cohort abundance concordance"
    
  ) +
  
  theme_classic(
    base_size = 14
  )

rank_plot


#Better candidate validation plot (Discovery expression vs validation expression)
ggplot(
  final_validation,
  
  aes(
    x = GSE201588_TPM,
    y = GSE149856_expression
  )
) +
  
  geom_point(
    aes(
      size = Candidate_Score
    ),
    
    alpha = 0.85
  ) +
  
  geom_text(
    aes(
      label = miRNA
    ),
    
    vjust = -0.7,
    
    size = 3
  ) +
  
  scale_x_log10() +
  
  scale_y_log10() +
  
  labs(
    
    x = "GSE201588 mean TPM",
    
    y = "GSE149856 mean expression",
    
    size = "Candidate score"
    
  ) +
  
  theme_classic(
    base_size = 14
  )


#Most important: final validated candidates

validated_candidates <- final_validation %>%
  
  filter(
    Direction_Consistent == "Yes"
  ) %>%
  
  arrange(
    desc(Candidate_Score)
  )


validated_candidates

write.csv(
  validated_candidates,
  "validated_candidates.csv",
  row.names = FALSE
)

validated_candidates_strict <- final_validation %>%
  
  filter(
    Direction_Consistent == "Yes",
    FDR < 0.05
  ) %>%
  
  arrange(
    desc(Candidate_Score)
  )

#Final ranked validation plot

plot_data <- final_validation %>%
  
  arrange(
    Candidate_Score
  ) %>%
  
  mutate(
    miRNA = factor(
      miRNA,
      levels = miRNA
    )
  )

ggplot(
  plot_data,
  
  aes(
    x = miRNA,
    y = Candidate_Score,
    fill = Direction_Consistent
  )
) +
  
  geom_col(
    width = 0.7
  ) +
  
  coord_flip() +
  
  scale_fill_manual(
    values = c(
      "Yes" = "#2E8B57",
      "No" = "#BDBDBD"
    )
  ) +
  
  labs(
    
    x = NULL,
    
    y = "Candidate Score",
    
    fill = "Direction\nconcordance"
    
  ) +
  
  theme_classic(
    base_size = 14
  ) +
  
  theme(
    legend.position = "right"
  )


#Revised bubble plot 

# ============================================================
#CROSS-COHORT CANDIDATE miRNAs
# ============================================================

library(dplyr)
library(ggplot2)
library(ggrepel)

# Check cross-cohort table
head(cross_cohort)
colnames(cross_cohort)

# Extract the 13 cross-cohort miRNAs
cross_cohort_miRNAs <- unique(cross_cohort$miRNA)

length(cross_cohort_miRNAs)

cross_cohort_miRNAs

# ============================================================
# EXTRACT 13 CROSS-COHORT CANDIDATES
# USING EXISTING bta-miRNA IDENTIFIERS
# ============================================================

cross_candidate_score <- Candidate_score %>%
  filter(
    bta_miRNA %in% cross_cohort_miRNAs
  )

# Check number of candidates
nrow(cross_candidate_score)

# View candidates
cross_candidate_score[, c(
  "bta_miRNA",
  "mature_mirna_id",
  "Mean_TPM_China",
  "Mean_Expression_Switzerland",
  "HRBC_Targets",
  "Candidate_Score",
  "Overall_Validation"
)]

cross_candidate_score$bta_miRNA

setdiff(
  cross_cohort_miRNAs,
  cross_candidate_score$bta_miRNA
)

#Add direction concordance
cross_direction <- cross_cohort %>%
  dplyr::select(
    miRNA,
    Direction_Consistent
  )

cross_candidate_score <- cross_candidate_score %>%
  dplyr::left_join(
    cross_direction,
    by = c("bta_miRNA" = "miRNA")
  )

cross_candidate_score[, c(
  "bta_miRNA",
  "Candidate_Score",
  "Direction_Consistent"
)]


table(cross_candidate_score$Direction_Consistent,
      useNA = "ifany")

sum(is.na(cross_candidate_score$Direction_Consistent))

#Calculate combined expression

cross_candidate_score$Combined_Expression <-
  cross_candidate_score$China_norm +
  cross_candidate_score$Swiss_norm

cross_candidate_score[, c(
  "bta_miRNA",
  "China_norm",
  "Swiss_norm",
  "Combined_Expression"
)]

#Arrange according to Candidate Score
cross_candidate_score <- cross_candidate_score %>%
  dplyr::arrange(
    dplyr::desc(Candidate_Score)
  )

cross_candidate_score[, c(
  "bta_miRNA",
  "Candidate_Score"
)]

#Plot
library(ggplot2)
library(ggrepel)

p_cross_bubble <- ggplot(
  cross_candidate_score,
  aes(
    x = HRBC_Targets,
    y = Candidate_Score,
    size = Combined_Expression,
    fill = Direction_Consistent
  )
) +
  
  geom_point(
    shape = 21,
    color = "black",
    alpha = 0.85,
    stroke = 0.5
  ) +
  
  geom_text_repel(
    aes(
      label = bta_miRNA
    ),
    size = 3.5,
    color = "black",
    box.padding = 0.45,
    point.padding = 0.25,
    force = 1.5,
    max.overlaps = Inf,
    seed = 123
  ) +
  
  scale_fill_manual(
    values = c(
      "Yes" = "#2E8B57",
      "No" = "#BDBDBD"
    ),
    name = "Direction\nconcordance"
  ) +
  
  scale_size_continuous(
    range = c(3, 11),
    name = "Combined\nexpression"
  ) +
  
  labs(
    x = "HR+BC Target Count",
    y = "Integrated Candidate Score"
  ) +
  
  theme_classic(
    base_size = 14
  ) +
  
  theme(
    axis.title = element_text(
      face = "bold"
    ),
    
    axis.text = element_text(
      color = "black"
    ),
    
    legend.title = element_text(
      face = "bold"
    ),
    
    legend.position = "right",
    
    plot.margin = margin(
      10, 25, 10, 10
    )
  )

# Display plot
p_cross_bubble

ggsave(
  filename = "13_Cross_Cohort_Candidate_Bubble.tiff",
  plot = p_cross_bubble,
  width = 10,
  height = 7,
  units = "in",
  dpi = 600,
  compression = "lzw"
)



save.image(".RData")
savehistory("My_R_History.Rhistory")
