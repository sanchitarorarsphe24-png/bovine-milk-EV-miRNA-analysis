#script to visualisze gene expression data (GSE227559) France
# script "D:/SANCHIT ARORA/IIT BHU/Sanchit_PhD/Sanchit_PhD research work/In silico studies/Scripts"

#Download and inspect the processed file

#STEP 1: Read GSE227559
library(GEOquery)

install.packages("readxl")
library(readxl)

gse227559 <- read_xlsx("GSE227559_Processed_data.xlsx")

class(gse227559)

dim(gse227559)

head(gse227559)

colnames(gse227559)

#Step 2. Expression matrix
#Remove the first two rows
library(dplyr)

france <- gse227559[-c(1,2), ]

head(france)

#Rename the columns correctly
colnames(france)[1:2] <- c("miRNA","Sequence")

colnames(france)

#Remove the Sequence column
expr_france <- france[,-2]

#Make miRNA names the row names
expr_france <- as.data.frame(expr_france)

rownames(expr_france) <- expr_france$miRNA

expr_france$miRNA <- NULL

#Convert everything to numeric
expr_france[] <- lapply(expr_france, as.numeric)

#Check the matrix
dim(expr_france)

head(expr_france)

#Calculate mean expression
mean_france <- rowMeans(expr_france)

#Create dataframe
France_expr <- data.frame(
  miRNA = rownames(expr_france),
  Mean_France = mean_france
)

#Top 20
library(dplyr)

top20_France <- France_expr %>%
  arrange(desc(Mean_France)) %>%
  slice(1:20)

top20_France

#To keep only bovine samples
colnames(expr_france)

gse227559[2, ]

sample_names <- as.character(unlist(gse227559[2, ]))
sample_names

colnames(gse227559) <- sample_names

france <- gse227559[-c(1,2), ]

colnames(france)

expr_france <- france[, c("Name", "B1", "B2", "B3", "B62", "B20")]

expr_france <- as.data.frame(expr_france)

rownames(expr_france) <- expr_france$Name

expr_france$Name <- NULL

expr_france[] <- lapply(expr_france, as.numeric)

dim(expr_france)

#Step 3. View samples names
#View the column names (sample IDs)
colnames(expr_france)

#Count the number of samples
ncol(expr_france)

#Print each sample name
for(i in colnames(expr_france)){
  print(i)
}

#Verify that these are bovine samples only
grep("^B", colnames(expr_france), value = TRUE)

#Step 4: Calculate the mean miRNA expression across the five bovine samples.
#Step 4.1: Calculate the mean expression
mean_france <- rowMeans(expr_france, na.rm = TRUE)

#Step 4.2: Create a summary data frame
France_expr <- data.frame(
  miRNA = rownames(expr_france),
  Mean_France = mean_france,
  row.names = NULL
)

#Step 4.3: Verify the results
dim(France_expr)

#Step 4.4: View the first few rows
head(France_expr)

#Step 4.5: Check the highest expressed miRNAs
France_expr <- France_expr[order(-France_expr$Mean_France), ]

head(France_expr, 10)

library(dplyr)

top10_France <- France_expr %>%
  arrange(desc(Mean_France)) %>%
  slice(1:10)

top10_France

#STEP 5. Calculate Top Abundant miRNAs for all Healthy Cohorts
#STEP 5.1 China – Healthy Known miRNAs Only

#Extract Healthy Samples
Healthy_China <- expr_mat[, c("H1","H2","H3","H4","H5","H6","H9")]

#Calculate Mean Expression
Mean_China <- rowMeans(Healthy_China, na.rm = TRUE)

#Create Mean Expression Table
China_expr <- data.frame(
  miRNA = rownames(Healthy_China),
  Mean_China = Mean_China,
  row.names = NULL
)

#Remove Novel miRNAs
library(dplyr)

China_expr_known <- China_expr %>%
  filter(!grepl("novel", miRNA, ignore.case = TRUE))

#Sort by Mean Expression
China_expr_known <- China_expr_known %>%
  arrange(desc(Mean_China))

#Extract Top 10 Known miRNAs
top10_China <- China_expr_known %>%
  slice(1:10)

top10_China

#Check how many known miRNAs are present
grep("^bta-", China_expr$miRNA, value = TRUE)

#Keep only known miRNAs
China_expr_known <- China_expr %>%
  filter(grepl("^bta-", miRNA))

China_expr_known <- China_expr_known %>%
  arrange(desc(Mean_China))

#Top 10 Known miRNAs
top10_China <- China_expr_known %>%
  slice(1:10)

top10_China

write.csv(top10_China,
          "Top10_Known_Healthy_China_miRNAs.csv",
          row.names = FALSE)

#Publication-quality Horizontal Bar Plot
library(ggplot2)

top10_China$miRNA <- factor(
  top10_China$miRNA,
  levels = rev(top10_China$miRNA)
)

ggplot(top10_China,
       aes(x = miRNA,
           y = Mean_China)) +
  
  geom_col(fill = "steelblue") +
  
  coord_flip() +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs in Healthy Chinese Bovine Milk EVs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#or
#Lollipop Plot
library(ggplot2)

ggplot(top10_China,
       aes(x = reorder(miRNA, Mean_China),
           y = Mean_China)) +
  
  geom_segment(
    aes(xend = miRNA,
        y = 0,
        yend = Mean_China),
    color = "grey60"
  ) +
  
  geom_point(
    size = 4,
    color = "firebrick"
  ) +
  
  coord_flip() +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs in Healthy Chinese Bovine Milk EVs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#STEP 5.2: Switzerland – Top 20 Known Healthy miRNAs
#5.2.1 Extract Healthy Samples
Healthy_Switzerland <- expr_swiss[, c(
  "C6_H2",
  "C5_H1",
  "C4_H3",
  "C5_H5",
  "C5_H2",
  "C6_H6",
  "C6_H1",
  "C4_H1",
  "C4_H2"
)]

#5.2.2 Calculate Mean TPM
Mean_Switzerland <- rowMeans(
  Healthy_Switzerland,
  na.rm = TRUE
)

#5.2.3 Create Expression Table
Switzerland_expr <- data.frame(
  miRNA = rownames(Healthy_Switzerland),
  Mean_Switzerland = Mean_Switzerland,
  row.names = NULL
)

#5.2.4 Keep Only Known miRNAs
library(dplyr)

Switzerland_expr_known <- Switzerland_expr %>%
  filter(grepl("^bta-", miRNA))

#5.2.5 Arrange
Switzerland_expr_known <- Switzerland_expr_known %>%
  arrange(desc(Mean_Switzerland))

#5.2.6 Top 10
top10_Switzerland <- Switzerland_expr_known %>%
  slice(1:10)

top10_Switzerland

#5.2.7 Save
install.packages("openxlsx")
library(openxlsx)

write.xlsx(
  top10_Switzerland,
  "Top10_Known_Healthy_Switzerland_miRNAs.xlsx",
  rowNames=FALSE
)

#Horizontal Bar Plot (Switzerland)
library(ggplot2)

top10_Switzerland$miRNA <- factor(
  top10_Switzerland$miRNA,
  levels = rev(top10_Switzerland$miRNA)
)

ggplot(top10_Switzerland,
       aes(x = miRNA,
           y = Mean_Switzerland)) +
  
  geom_col(fill = "steelblue") +
  
  coord_flip() +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs in Healthy Swiss Bovine Milk EVs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#Lollipop Plot (Switzerland)
ggplot(top10_Switzerland,
       aes(x = reorder(miRNA, Mean_Switzerland),
           y = Mean_Switzerland)) +
  
  geom_segment(
    aes(xend = miRNA,
        y = 0,
        yend = Mean_Switzerland),
    color = "grey60"
  ) +
  
  geom_point(
    size = 4,
    color = "firebrick"
  ) +
  
  coord_flip() +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs in Healthy Swiss Bovine Milk EVs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#STEP 5.3 France – Known miRNAs
#Since all five samples are healthy:
France_expr_known <- France_expr %>%
  filter(grepl("^bta-", miRNA))

#Arrange
France_expr_known <- France_expr_known %>%
  arrange(desc(Mean_France))

#Top10
top10_France <- France_expr_known %>%
  slice(1:10)

top10_France

#Save
write.xlsx(
  top10_France,
  "Top10_Known_Healthy_France_miRNAs.xlsx",
  rowNames=FALSE
)

#France Bar Plot
library(ggplot2)

top10_France$miRNA <- factor(
  top10_France$miRNA,
  levels = rev(top10_France$miRNA)
)

ggplot(top10_France,
       aes(x = miRNA,
           y = Mean_France)) +
  
  geom_col(fill = "steelblue") +
  
  coord_flip() +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs in Healthy French Bovine Milk EVs",
    x = "Known miRNA",
    y = "Mean TPM"
  )

#France Lollipop Plot
ggplot(top10_France,
       aes(x = reorder(miRNA, Mean_France),
           y = Mean_France)) +
  
  geom_segment(
    aes(
      xend = miRNA,
      y = 0,
      yend = Mean_France
    ),
    color = "grey60"
  ) +
  
  geom_point(
    size = 4,
    color = "firebrick"
  ) +
  
  coord_flip() +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs in Healthy French Bovine Milk EVs",
    x = "Known miRNA",
    y = "Mean TPM"
  )


#STEP 6: Create Top 10 miRNA vectors
China_top <- top10_China$miRNA

Switzerland_top <- top10_Switzerland$miRNA

France_top <- top10_France$miRNA

#Verify that each vector contains 10 miRNAs:
length(China_top)

length(Switzerland_top)

length(France_top)


#STEP 7: Three-way Venn Diagram
library(VennDiagram)
library(grid)
library(futile.logger)


venn.plot <- venn.diagram(
  
  x = list(
    
    GSE201588 = China_top,
    
    GSE149856 = Switzerland_top,
    
    GSE227559 = France_top
    
  ),
  
  filename = NULL,
  
  fill = c("#E64B35", "#4DBBD5", "#00A087"),
  
  alpha = 0.6,
  
  cex = 1.5,
  
  fontface = "bold",
  
  cat.cex = 1.4,
  
  cat.fontface = "bold",
  
  cat.col = c("#E64B35", "#4DBBD5", "#00A087"),
  
  margin = 0.1
  
)

grid.draw(venn.plot)

tiff(
  "ThreeWay_Top10_Known_miRNAs_Venn_GSE.tiff",
  width = 8,
  height = 8,
  units = "in",
  res = 600,
  compression = "lzw"
)

grid.draw(venn.plot)

dev.off()


#STEP 8: Identify Common Top 10 miRNAs
Common_Known <- Reduce(
  intersect,
  list(
    China_top,
    Switzerland_top,
    France_top
  )
)

#Display the common miRNAs:
Common_Known

length(Common_Known)

#Save the Common miRNAs
write.csv(
  data.frame(miRNA = Common_Known),
  "Common_Top10_Known_Healthy_miRNAs.csv",
  row.names = FALSE
)

#Pairwise Comparison
#China vs Switzerland
China_Swiss <- intersect(China_top, Switzerland_top)

China_Swiss

length(China_Swiss)

#China vs France
China_France <- intersect(China_top, France_top)

China_France

length(China_France)

#Switzerland vs France
Swiss_France <- intersect(Switzerland_top, France_top)

Swiss_France

length(Swiss_France)


#Combine the Top 10 datasets (china, switz, france)
library(dplyr)

library(dplyr)

China_plot <- top10_China %>%
  mutate(Dataset = "GSE201588") %>%
  rename(Mean_TPM = Mean_China)

Switzerland_plot <- top10_Switzerland %>%
  mutate(Dataset = "GSE149856") %>%
  rename(Mean_TPM = Mean_Switzerland)

France_plot <- top10_France %>%
  mutate(Dataset = "GSE227559") %>%
  rename(Mean_TPM = Mean_France)

combined_top10 <- bind_rows(
  China_plot,
  Switzerland_plot,
  France_plot
)

#Combined Lollipop Plot
library(ggplot2)

ggplot(combined_top10,
       aes(x = reorder(miRNA, Mean_TPM),
           y = Mean_TPM,
           colour = Dataset)) +
  
  geom_segment(
    aes(
      xend = miRNA,
      y = 0,
      yend = Mean_TPM
    ),
    linewidth = 0.7,
    alpha = 0.6
  ) +
  
  geom_point(size = 3.5) +
  
  coord_flip() +
  
  facet_wrap(~Dataset, scales = "free_y") +
  
  theme_classic(base_size = 14) +
  
  labs(
    title = "Top 10 Known miRNAs Across Healthy Bovine Milk EV Datasets",
    x = "Known miRNA",
    y = "Mean TPM"
  ) +
  
  theme(
    strip.text = element_text(face = "bold", size = 14),
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.text = element_text(size = 11),
    axis.title = element_text(face = "bold"),
    legend.position = "none"
  )


#For confirming the results of (Top 10 combined healthy miRNAs)

#First, check the actual TPM ranges
summary(top10_China$Mean_China)

summary(top10_Switzerland$Mean_Switzerland)

summary(top10_France$Mean_France)

max(top10_China$Mean_China)

max(top10_Switzerland$Mean_Switzerland)

max(top10_France$Mean_France)

#Second, verify that the renaming worked correctly

head(China_plot)

head(Switzerland_plot)

head(France_plot)

#Third, inspect the combined data
str(combined_top10)

summary(combined_top10$Mean_TPM)

aggregate(Mean_TPM ~ Dataset,
          combined_top10,
          max)

#Step 7: Add log2-transformed TPM (repeating again to get more clear data in lolipop plot)
library(dplyr)

China_plot <- top10_China %>%
  mutate(
    Dataset = "GSE201588",
    Mean_TPM = Mean_China,
    Log2_TPM = log2(Mean_China + 1)
  ) %>%
  select(miRNA, Mean_TPM, Log2_TPM, Dataset)

Switzerland_plot <- top10_Switzerland %>%
  mutate(
    Dataset = "GSE149856",
    Mean_TPM = Mean_Switzerland,
    Log2_TPM = log2(Mean_Switzerland + 1)
  ) %>%
  select(miRNA, Mean_TPM, Log2_TPM, Dataset)

France_plot <- top10_France %>%
  mutate(
    Dataset = "GSE227559",
    Mean_TPM = Mean_France,
    Log2_TPM = log2(Mean_France + 1)
  ) %>%
  select(miRNA, Mean_TPM, Log2_TPM, Dataset)

combined_top10 <- bind_rows(
  China_plot,
  Switzerland_plot,
  France_plot
)

#Check the transformed values
summary(combined_top10$Log2_TPM)

head(combined_top10)

#Combined Top 10 Lollipop Plot (log2 TPM)
library(ggplot2)

ggplot(combined_top10,
       aes(x = reorder(miRNA, Log2_TPM),
           y = Log2_TPM,
           colour = Dataset)) +
  
  geom_segment(
    aes(
      xend = miRNA,
      y = 0,
      yend = Log2_TPM
    ),
    linewidth = 0.7,
    alpha = 0.7
  ) +
  
  geom_point(size = 3.8) +
  
  coord_flip() +
  
  facet_wrap(~Dataset, scales = "free_y") +
  
  labs(
    title = "Top 10 Known miRNAs Across Healthy Bovine Milk EV Datasets",
    x = "Known miRNA",
    y = expression(log[2]*"(Mean TPM + 1)")
  ) +
  
  theme_classic(base_size = 14) +
  
  theme(
    strip.text = element_text(face = "bold", size = 14),
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.text = element_text(size = 11),
    axis.title = element_text(face = "bold"),
    legend.position = "none"
  )

#Step 7.1 from highest to lowest expression within that dataset.
#Install and load tidytext
install.packages("tidytext")
library(tidytext)

#Reorder miRNAs within each dataset
combined_top10 <- combined_top10 %>%
  mutate(miRNA = reorder_within(miRNA, Log2_TPM, Dataset))

#Plot
library(ggplot2)

ggplot(combined_top10,
       aes(x = miRNA,
           y = Log2_TPM,
           colour = Dataset)) +
  
  geom_segment(aes(xend = miRNA,
                   y = 0,
                   yend = Log2_TPM),
               linewidth = 0.7,
               alpha = 0.7) +
  
  geom_point(size = 3.8) +
  
  coord_flip() +
  
  scale_x_reordered() +
  
  facet_wrap(~Dataset, scales = "free_y") +
  
  labs(
    title = "Top 10 Known miRNAs Across Healthy Bovine Milk EV Datasets",
    x = "Known miRNA",
    y = expression(log[2]*"(Mean TPM + 1)")
  ) +
  
  theme_classic(base_size = 14) +
  
  theme(
    strip.text = element_text(face = "bold", size = 14),
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.text = element_text(size = 11),
    axis.title = element_text(face = "bold"),
    legend.position = "none"
  )

#STEP 9.Create rank tables for each dataset
#China (GSE201588)
library(dplyr)

China_rank <- China_expr_known %>%
  arrange(desc(Mean_China)) %>%
  mutate(China_Rank = row_number()) %>%
  select(miRNA, China_Rank)

#Switzerland (GSE149856)
Switzerland_rank <- Switzerland_expr_known %>%
  arrange(desc(Mean_Switzerland)) %>%
  mutate(Switzerland_Rank = row_number()) %>%
  select(miRNA, Switzerland_Rank)

#France (GSE227559)
France_rank <- France_expr_known %>%
  arrange(desc(Mean_France)) %>%
  mutate(France_Rank = row_number()) %>%
  select(miRNA, France_Rank)

#Merge the rank tables
library(dplyr)

Rank_Comparison <- full_join(China_rank, Switzerland_rank,
                             by = "miRNA") %>%
  full_join(France_rank,
            by = "miRNA")

#Keep only the common Top 10 miRNAs
Rank_Comparison_Common <- Rank_Comparison %>%
  filter(miRNA %in% Common_Known)

#Arrange the table
Rank_Comparison_Common <- Rank_Comparison_Common %>%
  mutate(
    Mean_Rank = rowMeans(
      select(., China_Rank,
             Switzerland_Rank,
             France_Rank),
      na.rm = TRUE
    )
  ) %>%
  arrange(Mean_Rank)

#View the table
Rank_Comparison_Common

write.csv(
  Rank_Comparison_Common,
  "Rank_Comparison_Common_Healthy_miRNAs.csv",
  row.names = FALSE
)

#goal is to compare the ranking of all Top 10 miRNAs from every dataset, then don't use Common_Known.
#Step 1
All_Top10 <- union(China_top, Switzerland_top)
All_Top10 <- union(All_Top10, France_top)

length(All_Top10)

All_Top10


Rank_Comparison_Top10 <- Rank_Comparison %>%
  filter(miRNA %in% All_Top10)

Rank_Comparison_Top10 <- Rank_Comparison_Top10 %>%
  mutate(
    Mean_Rank = rowMeans(
      select(., China_Rank,
             Switzerland_Rank,
             France_Rank),
      na.rm = TRUE
    )
  ) %>%
  arrange(Mean_Rank)

write.csv(
  Rank_Comparison_Top10,
  "Rank_Comparison_Top10_AllDatasets.csv",
  row.names = FALSE
)

#STEP 10. Pairwise Spearman Correlation
#Merge the three datasets by miRNA

library(dplyr)

Correlation_Data <- China_expr_known %>%
  full_join(Switzerland_expr_known, by = "miRNA") %>%
  full_join(France_expr_known, by = "miRNA")

#Replace missing values
Correlation_Data[is.na(Correlation_Data)] <- 0

#Check the merged table
head(Correlation_Data)

dim(Correlation_Data)

#China vs Switzerland
China_Switzerland <- cor.test(
  Correlation_Data$Mean_China,
  Correlation_Data$Mean_Switzerland,
  method = "spearman"
)

China_Switzerland

#China vs France
China_France <- cor.test(
  Correlation_Data$Mean_China,
  Correlation_Data$Mean_France,
  method = "spearman"
)

China_France

#Switzerland vs France
Switzerland_France <- cor.test(
  Correlation_Data$Mean_Switzerland,
  Correlation_Data$Mean_France,
  method = "spearman"
)

Switzerland_France

#Extract rho and p-value
Spearman_Results <- data.frame(
  
  Comparison = c(
    "China vs Switzerland",
    "China vs France",
    "Switzerland vs France"
  ),
  
  Spearman_rho = c(
    China_Switzerland$estimate,
    China_France$estimate,
    Switzerland_France$estimate
  ),
  
  P_value = c(
    China_Switzerland$p.value,
    China_France$p.value,
    Switzerland_France$p.value
  )
  
)

Spearman_Results

write.csv(
  Spearman_Results,
  "Pairwise_Spearman_Correlation.csv",
  row.names = FALSE
)

#verify
nrow(Correlation_Data)

sum(Correlation_Data$Mean_China > 0)
sum(Correlation_Data$Mean_Switzerland > 0)
sum(Correlation_Data$Mean_France > 0)

sum(
  Correlation_Data$Mean_China > 0 &
    Correlation_Data$Mean_Switzerland > 0 &
    Correlation_Data$Mean_France > 0
)

Correlation_Common <- Correlation_Data %>%
  filter(
    Mean_China > 0 &
      Mean_Switzerland > 0 &
      Mean_France > 0
  )

cor.test(
  Correlation_Common$Mean_China,
  Correlation_Common$Mean_Switzerland,
  method = "spearman"
)

cor.test(
  Correlation_Common$Mean_China,
  Correlation_Common$Mean_France,
  method = "spearman"
)

cor.test(
  Correlation_Common$Mean_Switzerland,
  Correlation_Common$Mean_France,
  method = "spearman"
)

head(Correlation_Data, 20)

View(Correlation_Data)

#Store the results
China_Switzerland <- cor.test(
  Correlation_Common$Mean_China,
  Correlation_Common$Mean_Switzerland,
  method = "spearman"
)

China_France <- cor.test(
  Correlation_Common$Mean_China,
  Correlation_Common$Mean_France,
  method = "spearman"
)

Switzerland_France <- cor.test(
  Correlation_Common$Mean_Switzerland,
  Correlation_Common$Mean_France,
  method = "spearman"
)

#Create a summary table
Spearman_Results <- data.frame(
  Comparison = c(
    "China vs Switzerland",
    "China vs France",
    "Switzerland vs France"
  ),
  
  Spearman_rho = c(
    unname(China_Switzerland$estimate),
    unname(China_France$estimate),
    unname(Switzerland_France$estimate)
  ),
  
  P_value = c(
    China_Switzerland$p.value,
    China_France$p.value,
    Switzerland_France$p.value
  )
)

Spearman_Results

write.csv(
  Spearman_Results,
  "Pairwise_Spearman_Correlation_Common_miRNAs.csv",
  row.names = FALSE
)

nrow(Correlation_Data)

nrow(Correlation_Common)


#Correlation Heatmap
library(corrplot)

cor_matrix <- matrix(
  c(
    1.000000000, 0.193864412, 0.153971107,
    0.193864412, 1.000000000, 0.756259733,
    0.153971107, 0.756259733, 1.000000000
  ),
  nrow = 3,
  byrow = TRUE
)

rownames(cor_matrix) <- c(
  "GSE201588",
  "GSE149856",
  "GSE227559"
)

colnames(cor_matrix) <- c(
  "GSE201588",
  "GSE149856",
  "GSE227559"
)

library(corrplot)

corrplot(
  cor_matrix,
  method = "color",
  type = "upper",
  addCoef.col = "black",
  number.cex = 1.2,
  tl.col = "black",
  tl.srt = 45,
  tl.cex = 1.2,
  col = colorRampPalette(
    c("blue","white","red")
  )(200),
  mar = c(1,1,2,1),
  title = "Pairwise Spearman Correlation of Healthy Milk EV miRNA Profiles"
)

#Network Plot
library(igraph)

edges <- data.frame(
  
  from=c(
    "GSE201588",
    "GSE201588",
    "GSE149856"
  ),
  
  to=c(
    "GSE149856",
    "GSE227559",
    "GSE227559"
  ),
  
  weight=c(
    0.193864412,
    0.153971107,
    0.756259733
  )
  
)

g <- graph_from_data_frame(edges)

plot(
  
  g,
  
  edge.width=E(g)$weight*12,
  
  edge.label=round(E(g)$weight,3),
  
  vertex.size=45,
  
  vertex.color="skyblue",
  
  vertex.frame.color="black",
  
  vertex.label.cex=1.1,
  
  vertex.label.color="black",
  
  layout=layout_in_circle(g)
  
)

#Pairwise Scatter Plots
Scatter_Data <- Correlation_Data

Scatter_Data$China <- log2(
  Scatter_Data$Mean_China+1
)

Scatter_Data$Switzerland <- log2(
  Scatter_Data$Mean_Switzerland+1
)

Scatter_Data$France <- log2(
  Scatter_Data$Mean_France+1
)

library(ggplot2)

#China vs Switzerland
ggplot(
  Scatter_Data,
  aes(China,Switzerland)
)+
  
  geom_point(
    alpha=0.6,
    size=2,
    color="steelblue"
  )+
  
  geom_smooth(
    method="lm",
    color="red",
    se=FALSE
  )+
  
  annotate(
    "text",
    x=Inf,
    y=Inf,
    label="ρ = 0.194\nP = 6.37e-04",
    hjust=1.1,
    vjust=1.5,
    size=5
  )+
  
  labs(
    
    x="GSE201588\nlog2(Mean TPM+1)",
    
    y="GSE149856\nlog2(Mean TPM+1)",
    
    title="GSE201588 vs GSE149856"
    
  )+
  
  theme_bw(base_size=14)

#China vs France
ggplot(
  Scatter_Data,
  aes(China,France)
)+
  
  geom_point(
    alpha=0.6,
    size=2,
    color="steelblue"
  )+
  
  geom_smooth(
    method="lm",
    color="red",
    se=FALSE
  )+
  
  annotate(
    "text",
    x=Inf,
    y=Inf,
    label="ρ = 0.154\nP = 6.87e-03",
    hjust=1.1,
    vjust=1.5,
    size=5
  )+
  
  labs(
    
    x="GSE201588\nlog2(Mean TPM+1)",
    
    y="GSE227559\nlog2(Mean TPM+1)",
    
    title="GSE201588 vs GSE227559"
    
  )+
  
  theme_bw(base_size=14)


#Switzerland vs France
ggplot(
  Scatter_Data,
  aes(Switzerland,France)
)+
  
  geom_point(
    alpha=0.6,
    size=2,
    color="steelblue"
  )+
  
  geom_smooth(
    method="lm",
    color="red",
    se=FALSE
  )+
  
  annotate(
    "text",
    x=Inf,
    y=Inf,
    label="ρ = 0.756\nP = 3.85e-58",
    hjust=1.1,
    vjust=1.5,
    size=5
  )+
  
  labs(
    
    x="GSE149856\nlog2(Mean TPM+1)",
    
    y="GSE227559\nlog2(Mean TPM+1)",
    
    title="GSE149856 vs GSE227559"
    
  )+
  
  theme_bw(base_size=14)

#Scatter plots
#China vs Switzerland
library(ggplot2)

ggplot(
  Correlation_Data,
  aes(
    x = Mean_China,
    y = Mean_Switzerland
  )
) +
  geom_point(size = 2.5, alpha = 0.7) +
  scale_x_log10() +
  scale_y_log10() +
  theme_classic(base_size = 14) +
  labs(
    title = "China vs Switzerland",
    x = "China Mean TPM",
    y = "Switzerland Mean TPM"
  )

#Step 11. Conservation Analysis
#Merge the three rank tables
Conservation_Table <- China_rank %>%
  inner_join(
    Switzerland_rank,
    by = "miRNA"
  ) %>%
  inner_join(
    France_rank,
    by = "miRNA"
  )

#Calculate mean rank
Conservation_Table <- Conservation_Table %>%
  mutate(
    Mean_Rank = rowMeans(
      select(
        .,
        China_Rank,
        Switzerland_Rank,
        France_Rank
      )
    )
  )

#Calculate rank variation
Conservation_Table <- Conservation_Table %>%
  mutate(
    Rank_SD = apply(
      select(
        .,
        China_Rank,
        Switzerland_Rank,
        France_Rank
      ),
      1,
      sd
    )
  )

#Classify conservation
Conservation_Table <- Conservation_Table %>%
  mutate(
    Interpretation = case_when(
      
      Mean_Rank <= 10 &
        Rank_SD <= 2
      ~ "Highly Conserved",
      
      Mean_Rank <= 30 &
        Rank_SD <= 5
      ~ "Conserved",
      
      TRUE
      ~ "Variable"
      
    )
  )

#Arrange the table
Conservation_Table <- Conservation_Table %>%
  arrange(Mean_Rank)

#View results
Conservation_Table

write.csv(
  Conservation_Table,
  "Conserved_Healthy_Bovine_Milk_EV_miRNAs.csv",
  row.names = FALSE
)

#Plot the top conserved miRNAs
library(ggplot2)

Top20_Conserved <- Conservation_Table %>%
  slice_min(
    Mean_Rank,
    n = 20
  )

ggplot(
  Top20_Conserved,
  aes(
    x = reorder(miRNA, Mean_Rank),
    y = Mean_Rank,
    fill = Interpretation
  )) +
  
  geom_col() +
  
  coord_flip() +
  
  theme_bw(base_size = 14) +
  
  labs(
    x = "miRNA",
    y = "Mean Rank",
    title = "Top Conserved Healthy Bovine Milk EV miRNAs"
  )

#Or

#Merge rank and expression data
library(dplyr)

Conservation_Table <- China_rank %>%
  inner_join(
    Switzerland_rank,
    by = "miRNA"
  ) %>%
  inner_join(
    France_rank,
    by = "miRNA"
  ) %>%
  inner_join(
    China_expr_known,
    by = "miRNA"
  ) %>%
  inner_join(
    Switzerland_expr_known,
    by = "miRNA"
  ) %>%
  inner_join(
    France_expr_known,
    by = "miRNA"
  )

#Calculate mean rank
Conservation_Table <- Conservation_Table %>%
  mutate(
    Mean_Rank = rowMeans(
      select(
        .,
        China_Rank,
        Switzerland_Rank,
        France_Rank
      )
    )
  )

#Calculate rank variation
Conservation_Table <- Conservation_Table %>%
  mutate(
    Rank_SD = apply(
      select(
        .,
        China_Rank,
        Switzerland_Rank,
        France_Rank
      ),
      1,
      sd
    )
  )

#Calculate mean TPM
Conservation_Table <- Conservation_Table %>%
  mutate(
    Mean_TPM = rowMeans(
      select(
        .,
        Mean_China,
        Mean_Switzerland,
        Mean_France
      )
    )
  )

#Calculate expression variation
Conservation_Table <- Conservation_Table %>%
  mutate(
    TPM_SD = apply(
      select(
        .,
        Mean_China,
        Mean_Switzerland,
        Mean_France
      ),
      1,
      sd
    )
  )

#Calculate coefficient of variation (CV)
Conservation_Table <- Conservation_Table %>%
  mutate(
    TPM_CV = (TPM_SD / Mean_TPM) * 100
  )

#Classify conservation
Conservation_Table <- Conservation_Table %>%
  mutate(
    Interpretation = case_when(
      
      Mean_Rank <= 10 &
        Rank_SD <= 2 &
        TPM_CV <= 30
      ~ "Highly Conserved",
      
      Mean_Rank <= 30 &
        Rank_SD <= 5 &
        TPM_CV <= 50
      ~ "Conserved",
      
      TRUE
      ~ "Variable"
      
    )
  )

#Arrange by conservation
Conservation_Table <- Conservation_Table %>%
  arrange(
    Mean_Rank,
    TPM_CV
  )

#Select the final columns
Conservation_Table <- Conservation_Table %>%
  select(
    miRNA,
    China_Rank,
    Switzerland_Rank,
    France_Rank,
    Mean_China,
    Mean_Switzerland,
    Mean_France,
    Mean_Rank,
    Rank_SD,
    Mean_TPM,
    TPM_SD,
    TPM_CV,
    Interpretation
  )

#View the results
head(Conservation_Table)

write.csv(
  Conservation_Table,
  "Core_Healthy_Bovine_Milk_EV_miRNA_Signature.csv",
  row.names = FALSE
)



#REVISED PLOTS
library(dplyr)
library(tidyr)
library(ggplot2)
library(pheatmap)
library(ggrepel)


#STEP 1 — Confirm our 13 candidates

cross_13

length(cross_13)
cross_13

#STEP 2 — Create the three-cohort master table
# =========================================================
# STEP 2 — CREATE MASTER 13-miRNA TABLE
# =========================================================

cross13_score <- Candidate_score %>%
  filter(bta_miRNA %in% cross_13) %>%
  select(
    bta_miRNA,
    Mean_TPM_China,
    Mean_Expression_Switzerland,
    HRBC_Targets,
    Candidate_Score,
    Combined_Expression,
    Overall_Validation
  ) %>%
  rename(
    miRNA = bta_miRNA,
    GSE201588_TPM_mean = Mean_TPM_China,
    GSE149856_processed_mean = Mean_Expression_Switzerland
  )

# Check
nrow(cross13_score)
cross13_score

# =========================================================
# GSE227559 — CREATE 13-CANDIDATE DATASET
# =========================================================

library(dplyr)

# ---------------------------------------------------------
# STEP 2A — Clean GSE227559
# ---------------------------------------------------------

gse227559_clean <- gse227559 %>%
  filter(
    !is.na(Name),
    Name != "Name"
  )

# ---------------------------------------------------------
# STEP 2B — Define the five healthy B samples
# ---------------------------------------------------------

B_samples <- c(
  "B1",
  "B2",
  "B3",
  "B20",
  "B62"
)

# Check that all five samples exist
B_samples %in% names(gse227559_clean)


# ---------------------------------------------------------
# STEP 2C — Extract Name, Sequence and B samples
# ---------------------------------------------------------

gse227559_B <- gse227559_clean %>%
  select(
    Name,
    Sequence,
    all_of(B_samples)
  )

# Convert B-sample expression values to numeric
gse227559_B <- gse227559_B %>%
  mutate(
    across(
      all_of(B_samples),
      ~ as.numeric(.)
    )
  )

# Check
dim(gse227559_B)
names(gse227559_B)
head(gse227559_B)


## ---------------------------------------------------------
# STEP 2D — Extract the 13 pre-specified candidates
# ---------------------------------------------------------

GSE227559_13 <- gse227559_B %>%
  filter(
    Name %in% cross_13
  )

# Check
nrow(GSE227559_13)

GSE227559_13 %>%
  select(
    Name,
    Sequence,
    all_of(B_samples)
  )

#STEP 3 — Calculate mean TPM
# =========================================================
# STEP 3 — MEAN TPM FOR THE 13 CANDIDATES
# =========================================================

GSE227559_13_mean <- GSE227559_13 %>%
  rowwise() %>%
  mutate(
    GSE227559_Mean = mean(
      c_across(all_of(B_samples)),
      na.rm = TRUE
    )
  ) %>%
  ungroup() %>%
  select(
    miRNA = Name,
    GSE227559_Mean
  )

# Check
GSE227559_13_mean

nrow(GSE227559_13_mean)

sum(is.na(GSE227559_13_mean$GSE227559_Mean))


#STEP 4 — Create the three-cohort table
# =========================================================
# STEP 4 — THREE-COHORT MASTER TABLE
# =========================================================

Fig8_data <- cross13_score %>%
  left_join(
    GSE227559_13_mean,
    by = "miRNA"
  )

# Check
nrow(Fig8_data)

Fig8_data %>%
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE149856_processed_mean,
    GSE227559_Mean,
    HRBC_Targets,
    Candidate_Score
  )

cross_13

GSE227559_13$Name

setdiff(cross_13, GSE227559_13$Name)

setdiff(GSE227559_13$Name, cross_13)

# =========================================================
# STEP 4 — ADD GSE227559 DATA
# =========================================================

Fig8_data <- cross13_score %>%
  left_join(
    GSE227559_13_mean,
    by = "miRNA"
  )

# Check
nrow(Fig8_data)

names(Fig8_data)


Fig8_data %>%
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE149856_processed_mean,
    GSE227559_Mean,
    HRBC_Targets,
    Candidate_Score,
    Combined_Expression,
    Overall_Validation
  )

# =========================================================
# STEP 5 — FINAL DATA TRANSFORMATION
# =========================================================

Fig8_data <- Fig8_data %>%
  mutate(
    
    # GSE201588 = TPM
    GSE201588_log2 =
      log2(GSE201588_TPM_mean + 1),
    
    # GSE149856 = processed values
    # DO NOT apply log2 again
    GSE149856_processed =
      GSE149856_processed_mean,
    
    # GSE227559 = TPM
    GSE227559_log2 =
      log2(GSE227559_Mean + 1)
    
  )

Fig8_data %>%
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE201588_log2,
    GSE149856_processed_mean,
    GSE149856_processed,
    GSE227559_Mean,
    GSE227559_log2
  )

# Number of candidates
nrow(Fig8_data)

# Missing GSE227559 values
sum(is.na(Fig8_data$GSE227559_Mean))

# Check that all 13 candidates are retained
setdiff(
  cross_13,
  Fig8_data$miRNA
)

#Figure 8A — GSE227559 abundance of the 13 candidates
# =========================================================
# FIGURE 8A
# Independent evaluation of the 13 cross-cohort candidates
# =========================================================

library(ggplot2)
library(dplyr)
library(tidyr)
library(ggrepel)
library(pheatmap)
library(patchwork)

# Arrange candidates according to Candidate Score
Fig8_A_data <- Fig8_data %>%
  arrange(desc(Candidate_Score)) %>%
  mutate(
    miRNA = factor(
      miRNA,
      levels = rev(miRNA)
    )
  )

# Plot
p8A <- ggplot(
  Fig8_A_data,
  aes(
    x = GSE227559_log2,
    y = miRNA
  )
) +
  
  geom_segment(
    aes(
      x = 0,
      xend = GSE227559_log2,
      y = miRNA,
      yend = miRNA
    ),
    linewidth = 0.7
  ) +
  
  geom_point(
    aes(size = Candidate_Score),
    shape = 21,
    fill = "black",
    color = "black"
  ) +
  
  scale_size_continuous(
    range = c(3, 8),
    name = "Candidate\nscore"
  ) +
  
  labs(
    title = "Independent evaluation of the 13 cross-cohort candidates",
    x = expression(log[2]~"(mean TPM + 1)"),
    y = NULL
  ) +
  
  theme_classic(
    base_size = 13
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.text.y = element_text(
      color = "black"
    ),
    axis.text.x = element_text(
      color = "black"
    ),
    axis.title.x = element_text(
      face = "bold"
    ),
    legend.title = element_text(
      face = "bold"
    )
  )

p8A



#Figure 8B — Three-cohort abundance comparison
# =========================================================
# FIGURE 8B
# Three-cohort abundance comparison
# =========================================================

Fig8_B_data <- Fig8_data %>%
  select(
    miRNA,
    GSE201588_log2,
    GSE149856_processed,
    GSE227559_log2
  ) %>%
  
  pivot_longer(
    cols = c(
      GSE201588_log2,
      GSE149856_processed,
      GSE227559_log2
    ),
    names_to = "Dataset",
    values_to = "Expression"
  ) %>%
  
  mutate(
    Dataset = recode(
      Dataset,
      GSE201588_log2 = "GSE201588",
      GSE149856_processed = "GSE149856",
      GSE227559_log2 = "GSE227559"
    )
  )


Fig8_B_data$Dataset <- factor(
  Fig8_B_data$Dataset,
  levels = c(
    "GSE201588",
    "GSE149856",
    "GSE227559"
  )
)

miRNA_order <- Fig8_data %>%
  arrange(Candidate_Score) %>%
  pull(miRNA)

Fig8_B_data$miRNA <- factor(
  Fig8_B_data$miRNA,
  levels = miRNA_order
)


p8B <- ggplot(
  Fig8_B_data,
  aes(
    x = Dataset,
    y = Expression,
    group = miRNA
  )
) +
  
  geom_line(
    linewidth = 0.6,
    alpha = 0.45
  ) +
  
  geom_point(
    size = 2.8
  ) +
  
  facet_wrap(
    ~ miRNA,
    scales = "free_y",
    ncol = 4
  ) +
  
  labs(
    title = "Cross-cohort abundance of the 13 prioritised miRNAs",
    x = NULL,
    y = "Dataset-specific expression scale"
  ) +
  
  theme_classic(
    base_size = 12
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    strip.text = element_text(
      face = "bold"
    ),
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    ),
    axis.title.y = element_text(
      face = "bold"
    )
  )

p8B


#Figure 8C — Spearman correlation
# =========================================================
# FIGURE 8C
# Spearman correlation of the 13 candidates
# =========================================================

cor_data_13 <- Fig8_data %>%
  select(
    GSE201588 = GSE201588_log2,
    GSE149856 = GSE149856_processed,
    GSE227559 = GSE227559_log2
  )

# Calculate Spearman correlation
cor_mat_13 <- cor(
  cor_data_13,
  method = "spearman",
  use = "pairwise.complete.obs"
)

# View correlation matrix
round(
  cor_mat_13,
  3
)


p8C <- pheatmap(
  cor_mat_13,
  
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  
  display_numbers = TRUE,
  number_format = "%.2f",
  
  fontsize = 12,
  fontsize_number = 12,
  
  border_color = NA,
  
  main = "Cross-cohort correlation of the 13 prioritised miRNAs"
)

p8C


#Figure 8D — Cross-cohort rank stability
# =========================================================
# FIGURE 8D
# Cross-cohort abundance rank stability
# =========================================================

rank_data <- Fig8_data %>%
  select(
    miRNA,
    GSE201588_log2,
    GSE149856_processed,
    GSE227559_log2
  ) %>%
  
  pivot_longer(
    cols = c(
      GSE201588_log2,
      GSE149856_processed,
      GSE227559_log2
    ),
    names_to = "Dataset",
    values_to = "Expression"
  ) %>%
  
  group_by(Dataset) %>%
  
  mutate(
    Rank = rank(
      -Expression,
      ties.method = "average"
    )
  ) %>%
  
  ungroup()


rank_data <- rank_data %>%
  mutate(
    Dataset = recode(
      Dataset,
      GSE201588_log2 = "GSE201588",
      GSE149856_processed = "GSE149856",
      GSE227559_log2 = "GSE227559"
    )
  )


rank_order <- rank_data %>%
  group_by(miRNA) %>%
  summarise(
    Mean_Rank = mean(
      Rank,
      na.rm = TRUE
    ),
    .groups = "drop"
  ) %>%
  arrange(Mean_Rank) %>%
  pull(miRNA)

rank_data$miRNA <- factor(
  rank_data$miRNA,
  levels = rev(rank_order)
)


p8D <- ggplot(
  rank_data,
  aes(
    x = Rank,
    y = miRNA,
    group = miRNA
  )
) +
  
  geom_line(
    linewidth = 0.7,
    alpha = 0.6
  ) +
  
  geom_point(
    size = 3
  ) +
  
  scale_x_reverse(
    breaks = 1:13
  ) +
  
  labs(
    title = "Relative abundance rank stability across healthy EV cohorts",
    x = "Within-cohort abundance rank",
    y = NULL
  ) +
  
  theme_classic(
    base_size = 13
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5
    ),
    axis.title.x = element_text(
      face = "bold"
    ),
    axis.text.y = element_text(
      color = "black"
    )
  )

p8D

#Step 5 — Combine A–D into final Figure 8
# =========================================================
# FINAL FIGURE 8
# =========================================================

Figure8_final <- 
  (p8A + p8B) /
  (p8C + p8D)

Figure8_final

#Step 6 — Save the four panels as 600-dpi TIFF
ggsave(
  "Figure_8A_GSE227559_13_candidates.tiff",
  p8A,
  width = 7,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

ggsave(
  "Figure_8B_Three_Cohort_13_Candidates.tiff",
  p8B,
  width = 10,
  height = 8,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

tiff(
  "Figure_8C_13_Candidate_Spearman_Correlation.tiff",
  width = 7,
  height = 6,
  units = "in",
  res = 600,
  compression = "lzw"
)

pheatmap(
  cor_mat_13,
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  display_numbers = TRUE,
  number_format = "%.2f",
  fontsize = 12,
  fontsize_number = 12,
  border_color = NA,
  main = "Cross-cohort correlation of the 13 prioritised miRNAs"
)

dev.off()


ggsave(
  "Figure_8D_13_Candidate_Rank_Stability.tiff",
  p8D,
  width = 8,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

ggsave(
  "Figure_8_Final_13_Cohort_Validation.tiff",
  Figure8_final,
  width = 14,
  height = 12,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

#Step 8 — Save all underlying data
write.csv(
  Fig8_data,
  "Figure_8_Complete_13_Candidate_Data.csv",
  row.names = FALSE
)

write.csv(
  Fig8_A_data,
  "Figure_8A_GSE227559_Data.csv",
  row.names = FALSE
)

write.csv(
  Fig8_B_data,
  "Figure_8B_Three_Cohort_Data.csv",
  row.names = FALSE
)

write.csv(
  cor_mat_13,
  "Figure_8C_Spearman_Correlation_Matrix.csv"
)

write.csv(
  rank_data,
  "Figure_8D_Rank_Stability_Data.csv",
  row.names = FALSE
)

#Step 9 — Calculate and save the actual Spearman tests

# =========================================================
# PAIRWISE SPEARMAN TESTS
# =========================================================

test_201588_149856 <- cor.test(
  Fig8_data$GSE201588_log2,
  Fig8_data$GSE149856_processed,
  method = "spearman",
  exact = FALSE
)

test_201588_227559 <- cor.test(
  Fig8_data$GSE201588_log2,
  Fig8_data$GSE227559_log2,
  method = "spearman",
  exact = FALSE
)

test_149856_227559 <- cor.test(
  Fig8_data$GSE149856_processed,
  Fig8_data$GSE227559_log2,
  method = "spearman",
  exact = FALSE
)


Spearman_results_13 <- data.frame(
  
  Comparison = c(
    "GSE201588 vs GSE149856",
    "GSE201588 vs GSE227559",
    "GSE149856 vs GSE227559"
  ),
  
  Spearman_rho = c(
    unname(test_201588_149856$estimate),
    unname(test_201588_227559$estimate),
    unname(test_149856_227559$estimate)
  ),
  
  P_value = c(
    test_201588_149856$p.value,
    test_201588_227559$p.value,
    test_149856_227559$p.value
  )
)

Spearman_results_13

write.csv(
  Spearman_results_13,
  "Figure_8C_Spearman_Test_Results.csv",
  row.names = FALSE
)


cat(
  "Candidates =", nrow(Fig8_data), "\n",
  "GSE201588 missing =", sum(is.na(Fig8_data$GSE201588_log2)), "\n",
  "GSE149856 missing =", sum(is.na(Fig8_data$GSE149856_processed)), "\n",
  "GSE227559 missing =", sum(is.na(Fig8_data$GSE227559_log2)), "\n"
)



# =========================================================
# FIGURE 8A — REVISED
# Independent abundance assessment of the 13
# pre-specified cross-cohort candidates in GSE227559
# =========================================================

library(dplyr)
library(ggplot2)

# ---------------------------------------------------------
# Prepare Figure 8A data
# ---------------------------------------------------------

Fig8_A_data <- Fig8_data %>%
  select(
    miRNA,
    GSE227559_Mean,
    Candidate_Score
  ) %>%
  arrange(Candidate_Score) %>%
  mutate(
    miRNA = factor(
      miRNA,
      levels = miRNA
    )
  )

# Check
Fig8_A_data

# Confirm exactly 13 candidates
nrow(Fig8_A_data)

# Check missing GSE227559 values
sum(is.na(Fig8_A_data$GSE227559_Mean))


# ---------------------------------------------------------
# Generate Figure 8A
# ---------------------------------------------------------

p8A <- ggplot(
  Fig8_A_data,
  aes(
    x = GSE227559_Mean,
    y = miRNA
  )
) +
  
  # Horizontal abundance line
  geom_segment(
    aes(
      x = 0,
      xend = GSE227559_Mean,
      y = miRNA,
      yend = miRNA
    ),
    linewidth = 0.7,
    color = "grey40"
  ) +
  
  # Equal-size points for every candidate
  geom_point(
    size = 4,
    shape = 21,
    fill = "black",
    color = "black",
    stroke = 0.5
  ) +
  
  labs(
    title = "Independent abundance assessment of the 13 prioritised miRNAs",
    x = expression(log[2] * "(mean TPM + 1)"),
    y = NULL
  ) +
  
  theme_classic(
    base_size = 14
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 15
    ),
    
    axis.title.x = element_text(
      face = "bold",
      size = 14
    ),
    
    axis.text.x = element_text(
      color = "black",
      size = 12
    ),
    
    axis.text.y = element_text(
      color = "black",
      size = 12
    ),
    
    axis.line = element_line(
      linewidth = 0.6,
      color = "black"
    ),
    
    plot.margin = margin(
      10, 15, 10, 10
    )
  )

# Display
p8A

# =========================================================
# SAVE FIGURE 8A
# =========================================================

ggsave(
  filename = "Figure_8A_Independent_13_Candidate_Abundance.tiff",
  plot = p8A,
  width = 9,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

write.csv(
  Fig8_A_data,
  "Figure_8A_Data_13_Candidates_GSE227559.csv",
  row.names = FALSE
)

Fig8_A_data %>%
  select(
    miRNA,
    GSE227559_Mean
  )


# =========================================================
# FIGURE 8A — FINAL REVISED VERSION
# Independent abundance assessment of the 13 prioritised
# miRNAs in GSE227559
# =========================================================

library(dplyr)
library(ggplot2)

# ---------------------------------------------------------
# Prepare Figure 8A data
# ---------------------------------------------------------

Fig8_A_data <- Fig8_data %>%
  select(
    miRNA,
    GSE227559_Mean,
    Candidate_Score
  ) %>%
  mutate(
    log2_GSE227559_Mean = log2(GSE227559_Mean + 1)
  ) %>%
  arrange(Candidate_Score) %>%
  mutate(
    miRNA = factor(
      miRNA,
      levels = miRNA
    )
  )

# ---------------------------------------------------------
# Check transformation
# ---------------------------------------------------------

Fig8_A_data %>%
  select(
    miRNA,
    GSE227559_Mean,
    log2_GSE227559_Mean,
    Candidate_Score
  )

# Check range
range(
  Fig8_A_data$GSE227559_Mean,
  na.rm = TRUE
)

range(
  Fig8_A_data$log2_GSE227559_Mean,
  na.rm = TRUE
)

# Confirm 13 candidates
nrow(Fig8_A_data)

# Check missing values
sum(
  is.na(Fig8_A_data$log2_GSE227559_Mean)
)


# =========================================================
# Generate Figure 8A
# =========================================================

p8A <- ggplot(
  Fig8_A_data,
  aes(
    x = log2_GSE227559_Mean,
    y = miRNA
  )
) +
  
  # Horizontal abundance line
  geom_segment(
    aes(
      x = 0,
      xend = log2_GSE227559_Mean,
      y = miRNA,
      yend = miRNA
    ),
    linewidth = 0.7
  ) +
  
  # Equal-size points
  geom_point(
    size = 4,
    shape = 21,
    fill = "black",
    color = "black",
    stroke = 0.5
  ) +
  
  labs(
    title = "Independent abundance assessment of the 13 prioritised miRNAs",
    x = expression(log[2] * "(mean TPM + 1)"),
    y = NULL
  ) +
  
  theme_classic(
    base_size = 14
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 15
    ),
    
    axis.title.x = element_text(
      face = "bold",
      size = 14
    ),
    
    axis.text.x = element_text(
      color = "black",
      size = 12
    ),
    
    axis.text.y = element_text(
      color = "black",
      size = 12
    ),
    
    axis.line = element_line(
      linewidth = 0.6
    ),
    
    plot.margin = margin(
      10, 15, 10, 10
    )
  )

# Display
p8A

ggsave(
  filename = "Figure_8A_Independent_13_Candidate_Abundance_FINAL.tiff",
  plot = p8A,
  width = 9,
  height = 6,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

## =========================================================
# FIGURE 8D — REVISED
# Dataset-specific abundance rank of the 13 prioritised miRNAs
# =========================================================

# =========================================================
# FIGURE 8D — REVISED FINAL VERSION
# Within-cohort abundance rank of the 13 prioritised miRNAs
# =========================================================

library(dplyr)
library(tidyr)
library(ggplot2)

# ---------------------------------------------------------
# STEP 1 — Check the actual Fig8_data columns
# ---------------------------------------------------------

names(Fig8_data)

nrow(Fig8_data)


# ---------------------------------------------------------
# STEP 2 — Calculate within-cohort abundance ranks
# ---------------------------------------------------------

rank_data <- Fig8_data %>%
  
  select(
    miRNA,
    GSE201588_TPM_mean,
    GSE149856_processed_mean,
    GSE227559_Mean
  ) %>%
  
  pivot_longer(
    cols = c(
      GSE201588_TPM_mean,
      GSE149856_processed_mean,
      GSE227559_Mean
    ),
    names_to = "Dataset",
    values_to = "Mean_Expression"
  ) %>%
  
  mutate(
    Dataset = recode(
      Dataset,
      GSE201588_TPM_mean = "GSE201588",
      GSE149856_processed_mean = "GSE149856",
      GSE227559_Mean = "GSE227559"
    )
  ) %>%
  
  group_by(Dataset) %>%
  
  mutate(
    Rank = rank(
      -Mean_Expression,
      ties.method = "average"
    )
  ) %>%
  
  ungroup()


#STEP 3 — Check the calculated ranks

rank_data %>%
  arrange(Dataset, Rank) %>%
  select(
    Dataset,
    miRNA,
    Mean_Expression,
    Rank
  )

nrow(rank_data)

table(rank_data$Dataset)



# ---------------------------------------------------------
# STEP 4 — Common miRNA ordering
# ---------------------------------------------------------

rank_order <- rank_data %>%
  
  group_by(miRNA) %>%
  
  summarise(
    Mean_Rank = mean(
      Rank,
      na.rm = TRUE
    ),
    .groups = "drop"
  ) %>%
  
  arrange(Mean_Rank) %>%
  
  pull(miRNA)

rank_order


rank_data <- rank_data %>%
  
  mutate(
    miRNA = factor(
      miRNA,
      levels = rev(rank_order)
    ),
    
    Dataset = factor(
      Dataset,
      levels = c(
        "GSE201588",
        "GSE149856",
        "GSE227559"
      )
    )
  )


## =========================================================
# FIGURE 8D
# Dataset-specific within-cohort abundance rank
# =========================================================

p8D <- ggplot(
  rank_data,
  aes(
    x = Rank,
    y = miRNA
  )
) +
  
  geom_segment(
    aes(
      x = 1,
      xend = Rank,
      y = miRNA,
      yend = miRNA
    ),
    linewidth = 0.6
  ) +
  
  geom_point(
    size = 3.5,
    shape = 21,
    fill = "black",
    color = "black",
    stroke = 0.5
  ) +
  
  facet_wrap(
    ~ Dataset,
    nrow = 1
  ) +
  
  scale_x_reverse(
    limits = c(13, 1),
    breaks = 1:13
  ) +
  
  labs(
    title = "Within-cohort abundance rank of the 13 prioritised miRNAs",
    x = "Abundance rank (1 = highest)",
    y = NULL
  ) +
  
  theme_classic(
    base_size = 13
  ) +
  
  theme(
    plot.title = element_text(
      face = "bold",
      hjust = 0.5,
      size = 15
    ),
    
    strip.text = element_text(
      face = "bold",
      size = 13
    ),
    
    strip.background = element_rect(
      fill = "white",
      color = "black",
      linewidth = 0.6
    ),
    
    axis.title.x = element_text(
      face = "bold",
      size = 13
    ),
    
    axis.text.x = element_text(
      color = "black",
      size = 10
    ),
    
    axis.text.y = element_text(
      color = "black",
      size = 10
    ),
    
    panel.spacing = unit(
      1.2,
      "lines"
    ),
    
    plot.margin = margin(
      10, 10, 10, 10
    )
  )

p8D


# =========================================================
# SAVE FIGURE 8D
# =========================================================

ggsave(
  filename = "Figure_8D_Within_Cohort_Abundance_Rank_FINAL.tiff",
  plot = p8D,
  width = 11,
  height = 6.5,
  units = "in",
  dpi = 600,
  compression = "lzw"
)

# =========================================================
# SAVE FIGURE 8D DATA
# =========================================================

write.csv(
  rank_data,
  "Figure_8D_Within_Cohort_Abundance_Rank_FINAL.csv",
  row.names = FALSE
)










save.image(".RData")
savehistory("My_R_History.Rhistory")
