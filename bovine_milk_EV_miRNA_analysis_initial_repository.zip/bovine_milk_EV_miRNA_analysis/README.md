# Bovine milk extracellular-vesicle miRNA analysis

This repository contains the four R scripts supplied for the multi-cohort bovine milk EV-associated miRNA study.

## Study datasets

- **GSE201588** — discovery cohort (China)
- **GSE149856** — independent validation cohort (Switzerland)
- **GSE227559** — healthy bovine milk EV conservation cohort (France)
- **GSE254484** — commercial milk-powder EV miRNA profile

The scripts analyse publicly available GEO-derived data. The repository currently contains the supplied R scripts; it does **not** contain the underlying GEO processed-data spreadsheets or other source data files.

## Repository structure

```text
bovine_milk_EV_miRNA_analysis/
├── README.md
├── CODE_AUDIT.md
└── scripts/
    └── original_scripts/
        ├── GSE201588_discovery_visualisation.R
        ├── GSE149856_validation_visualisation.R
        ├── GSE227559_healthy_conservation.R
        └── GSE254484_milk_powder_profile.R
```

## Before running the scripts

1. Download the relevant processed files from NCBI GEO using the accession numbers above, or obtain the exact processed spreadsheets used in the analysis.
2. Place the input files in a local `data/` directory and update file paths in the scripts as needed.
3. Install the required R packages listed in `CODE_AUDIT.md`.
4. Run the scripts in an R session with the required input data and intermediate objects available.

**Important reproducibility note:** These are the original supplied scripts, preserved without substantive edits. Some sections use objects created interactively in RStudio or in earlier script sections. Consequently, the scripts should not yet be described as a fully standalone, one-click workflow. The scripts need a reproducibility pass (explicit input paths, object creation, package/version recording, and removal of session-specific dependencies) before final public release.

## Data availability

The source datasets are publicly available through NCBI Gene Expression Omnibus:

- https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE201588
- https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE149856
- https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE227559
- https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE254484

The commercial milk-powder profile analysed in GSE254484 is sample **GSM8043025**.

## Citation

Please cite the original GEO studies associated with the accession numbers above, as well as the manuscript describing this integrative analysis.
